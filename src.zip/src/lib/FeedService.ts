import { supabase } from './supabase';
import {
  FeedPost,
  PostComment,
  PostReaction,
  ReactionEmoji,
  PostType,
  DEFAULT_MURAL_POINTS,
  MuralPointsConfig,
} from '../types';

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function extractYouTubeId(url: string): string {
  const match = url.match(/(?:youtu\.be\/|watch\?v=|embed\/)([\\w-]{11})/);
  return match?.[1] ?? '';
}

function buildSpotifyEmbedUrl(uriOrUrl: string): string {
  // Aceita: spotify:track:ID  ou  https://open.spotify.com/track/ID
  const trackMatch = uriOrUrl.match(/track[/:]([A-Za-z0-9]+)/);
  const playlistMatch = uriOrUrl.match(/playlist[/:]([A-Za-z0-9]+)/);
  if (trackMatch) return `https://open.spotify.com/embed/track/${trackMatch[1]}?utm_source=generator&theme=0`;
  if (playlistMatch) return `https://open.spotify.com/embed/playlist/${playlistMatch[1]}?utm_source=generator&theme=0`;
  return '';
}

// Mapeia snake_case do banco para camelCase do frontend
function mapPost(raw: Record<string, unknown>): FeedPost {
  return {
    id:                    raw.id as string,
    authorId:              raw.author_id as string,
    groupId:               raw.group_id as string | undefined,  // TEXT no banco
    postType:              raw.post_type as PostType,
    caption:               raw.caption as string | undefined,
    imageUrl:              raw.image_url as string | undefined,
    imagePath:             raw.image_path as string | undefined,
    verseRef:              raw.verse_ref as string | undefined,
    verseText:             raw.verse_text as string | undefined,
    verseBookId:           raw.verse_book_id as string | undefined,
    verseChapter:          raw.verse_chapter as number | undefined,
    verseNumber:           raw.verse_number as number | undefined,
    studyTitle:            raw.study_title as string | undefined,
    studyBody:             raw.study_body as string | undefined,
    videoUrl:              raw.video_url as string | undefined,
    videoThumbnail:        raw.video_thumbnail as string | undefined,
    videoTitle:            raw.video_title as string | undefined,
    videoId:               raw.video_id as string | undefined,
    spotifyUri:            raw.spotify_uri as string | undefined,
    spotifyUrl:            raw.spotify_url as string | undefined,
    spotifyTitle:          raw.spotify_title as string | undefined,
    spotifyArtist:         raw.spotify_artist as string | undefined,
    spotifyCover:          raw.spotify_cover as string | undefined,
    spotifyEmbedUrl:       raw.spotify_uri ? buildSpotifyEmbedUrl(raw.spotify_uri as string) : undefined,
    achievementKey:        raw.achievement_key as string | undefined,
    achievementLabel:      raw.achievement_label as string | undefined,
    achievementIcon:       raw.achievement_icon as string | undefined,
    duelId:                raw.duel_id as string | undefined,
    duelOpponentName:      raw.duel_opponent_name as string | undefined,
    duelOpponentGroupName: raw.duel_opponent_group_name as string | undefined,
    duelScore:             raw.duel_score as string | undefined,
    participationId:       raw.participation_id as string | undefined,
    activityTitle:         raw.activity_title as string | undefined,
    isPinned:              (raw.is_pinned as boolean) ?? false,
    visibility:            (raw.visibility as 'public' | 'group_only') ?? 'public',
    created_at:            raw.created_at as string,
    author:                raw.profiles as FeedPost['author'],
    groupName:             (raw.groups as { name?: string })?.name,
    commentCount:          (raw.comment_count as number) ?? 0,
  };
}

// ─── FEED SERVICE ─────────────────────────────────────────────────────────────

export class FeedService {

  // ── Posts ──────────────────────────────────────────────────────────────────

  static async getPosts(
    page = 0,
    filter: string = 'all',
    pageSize = 15
  ): Promise<FeedPost[]> {
    const from = page * pageSize;
    const to   = from + pageSize - 1;

    // 1. Fetch basic posts and comment count (comment_count has a formal FK relationship)
    let query = supabase
      .from('feed_posts')
      .select(`
        *,
        comment_count:post_comments(count)
      `)
      .order('is_pinned', { ascending: false })
      .order('created_at', { ascending: false })
      .range(from, to);

    if (filter.startsWith('type:')) {
      const type = filter.replace('type:', '');
      query = query.eq('post_type', type);
    } else if (filter !== 'all' && filter !== 'my_group') {
      // assume it's a specific group_id
      query = query.eq('group_id', filter);
    }

    const { data: posts, error } = await query;
    if (error) { console.error('[FeedService.getPosts]', error); return []; }
    if (!posts || posts.length === 0) return [];

    // 2. Client-Side Join: Fetch unique authors and groups
    const authorIds = [...new Set(posts.map(p => p.author_id))];
    const groupIds  = [...new Set(posts.map(p => p.group_id).filter(Boolean))];

    const [profilesRes, groupsRes] = await Promise.all([
      supabase
        .from('profiles')
        .select('id, name, avatar_url, totalPoints, groupId:"groupId"')
        .in('id', authorIds),
      groupIds.length > 0
        ? supabase.from('groups').select('id, name').in('id', groupIds)
        : Promise.resolve({ data: [] })
    ]);

    const profileMap = new Map<string, any>();
    profilesRes.data?.forEach(p => profileMap.set(p.id, p));

    const groupMap = new Map<string, string>();
    groupsRes.data?.forEach(g => groupMap.set(g.id, g.name));

    // 3. Map everything together
    return posts.map(raw => mapPost({
      ...raw,
      profiles: profileMap.get(raw.author_id),
      groups: raw.group_id ? { name: groupMap.get(raw.group_id) } : null,
      comment_count: raw.comment_count?.[0]?.count ?? 0
    }));
  }

  static async createPost(payload: Partial<FeedPost>): Promise<FeedPost | null> {
    const insert: Record<string, unknown> = {
      author_id:              payload.authorId,
      group_id:               payload.groupId ?? null,
      post_type:              payload.postType,
      caption:                payload.caption ?? null,
      image_url:              payload.imageUrl ?? null,
      image_path:             payload.imagePath ?? null,
      verse_ref:              payload.verseRef ?? null,
      verse_text:             payload.verseText ?? null,
      verse_book_id:          payload.verseBookId ?? null,
      verse_chapter:          payload.verseChapter ?? null,
      verse_number:           payload.verseNumber ?? null,
      study_title:            payload.studyTitle ?? null,
      study_body:             payload.studyBody ?? null,
      video_url:              payload.videoUrl ?? null,
      video_thumbnail:        payload.videoThumbnail ?? null,
      video_title:            payload.videoTitle ?? null,
      video_id:               payload.videoId ?? null,
      spotify_uri:            payload.spotifyUri ?? null,
      spotify_url:            payload.spotifyUrl ?? null,
      spotify_title:          payload.spotifyTitle ?? null,
      spotify_artist:         payload.spotifyArtist ?? null,
      spotify_cover:          payload.spotifyCover ?? null,
      achievement_key:        payload.achievementKey ?? null,
      achievement_label:      payload.achievementLabel ?? null,
      achievement_icon:       payload.achievementIcon ?? null,
      duel_id:                payload.duelId ?? null,
      duel_opponent_name:     payload.duelOpponentName ?? null,
      duel_opponent_group_name: payload.duelOpponentGroupName ?? null,
      duel_score:             payload.duelScore ?? null,
      participation_id:       payload.participationId ?? null,
      activity_title:         payload.activityTitle ?? null,
      visibility:             payload.visibility ?? 'public',
    };

    const { data, error } = await supabase
      .from('feed_posts')
      .insert(insert)
      .select('*')
      .single();

    if (error) { console.error('[FeedService.createPost]', error); return null; }
    return mapPost(data);
  }

  static async deletePost(postId: string, imagePath?: string): Promise<void> {
    if (imagePath) {
      await supabase.storage.from('feed-media').remove([imagePath]);
    }
    await supabase.from('feed_posts').delete().eq('id', postId);
  }

  static async pinPost(postId: string, pinned: boolean): Promise<void> {
    await supabase.from('feed_posts').update({ is_pinned: pinned }).eq('id', postId);
  }

  // ── Reacoes ───────────────────────────────────────────────────────────────

  static async getReactions(postId: string): Promise<PostReaction[]> {
    const { data } = await supabase
      .from('post_reactions')
      .select('*')
      .eq('post_id', postId);
    return (data ?? []).map(r => ({
      id:      r.id,
      postId:  r.post_id,
      userId:  r.user_id,
      emoji:   r.emoji as ReactionEmoji,
    }));
  }

  static async toggleReaction(
    postId: string,
    userId: string,
    emoji: ReactionEmoji
  ): Promise<'added' | 'removed'> {
    const { data: existing } = await supabase
      .from('post_reactions')
      .select('id')
      .eq('post_id', postId)
      .eq('user_id', userId)
      .eq('emoji', emoji)
      .maybeSingle();

    if (existing) {
      await supabase.from('post_reactions').delete().eq('id', existing.id);
      return 'removed';
    } else {
      await supabase.from('post_reactions').insert({ post_id: postId, user_id: userId, emoji });
      return 'added';
    }
  }

  // ── Comentarios ───────────────────────────────────────────────────────────

  static async getComments(postId: string): Promise<PostComment[]> {
    const { data } = await supabase
      .from('post_comments')
      .select('*, profiles:author_id ( name, avatar_url )')
      .eq('post_id', postId)
      .order('created_at', { ascending: true });

    return (data ?? []).map(c => ({
      id:        c.id,
      postId:    c.post_id,
      authorId:  c.author_id,
      content:   c.content,
      created_at: c.created_at,
      author:    c.profiles as PostComment['author'],
    }));
  }

  static async addComment(
    postId: string,
    authorId: string,
    content: string
  ): Promise<PostComment | null> {
    const { data, error } = await supabase
      .from('post_comments')
      .insert({ post_id: postId, author_id: authorId, content })
      .select('*, profiles:author_id ( name, avatar_url )')
      .single();

    if (error) { console.error('[FeedService.addComment]', error); return null; }
    return {
      id:        data.id,
      postId:    data.post_id,
      authorId:  data.author_id,
      content:   data.content,
      created_at: data.created_at,
      author:    data.profiles as PostComment['author'],
    };
  }

  static async deleteComment(commentId: string): Promise<void> {
    await supabase.from('post_comments').delete().eq('id', commentId);
  }

  // ── Upload de Foto ────────────────────────────────────────────────────────

  static async uploadPhoto(
    file: File,
    userId: string
  ): Promise<{ url: string; path: string } | null> {
    const ALLOWED = ['image/jpeg', 'image/png', 'image/webp'];
    const MAX_SIZE = 5 * 1024 * 1024; // 5MB

    if (!ALLOWED.includes(file.type)) {
      throw new Error('Formato invalido. Use JPG, PNG ou WebP.');
    }
    if (file.size > MAX_SIZE) {
      throw new Error('Imagem muito grande. Maximo 5MB.');
    }

    const ext  = file.name.split('.').pop() ?? 'jpg';
    const path = `${userId}/${crypto.randomUUID()}.${ext}`;

    const { error } = await supabase.storage
      .from('feed-media')
      .upload(path, file, { cacheControl: '3600', upsert: false, contentType: file.type });

    if (error) { console.error('[FeedService.uploadPhoto]', error); return null; }

    const { data: urlData } = supabase.storage.from('feed-media').getPublicUrl(path);
    return { url: urlData.publicUrl, path };
  }

  // ── Spotify ───────────────────────────────────────────────────────────────

  static buildSpotifyEmbedUrl = buildSpotifyEmbedUrl;

  static extractSpotifyMeta(uriOrUrl: string): { type: 'track' | 'playlist' | null; id: string } {
    const trackMatch    = uriOrUrl.match(/track[/:]([A-Za-z0-9]+)/);
    const playlistMatch = uriOrUrl.match(/playlist[/:]([A-Za-z0-9]+)/);
    if (trackMatch)    return { type: 'track',    id: trackMatch[1] };
    if (playlistMatch) return { type: 'playlist', id: playlistMatch[1] };
    return { type: null, id: '' };
  }

  // ── YouTube ───────────────────────────────────────────────────────────────

  static extractYouTubeId = extractYouTubeId;

  static buildYouTubeEmbedUrl(videoId: string, autoplay = true): string {
    return `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=${autoplay ? 1 : 0}&rel=0`;
  }

  // ── Auto-posts (chamados por outros modulos) ──────────────────────────────

  static async autoPostAchievement(
    userId: string,
    groupId: string | undefined,
    achievementKey: string,
    achievementLabel: string,
    achievementIcon: string,
    shareOptIn = true
  ): Promise<void> {
    if (!shareOptIn) return;
    await FeedService.createPost({
      authorId:         userId,
      groupId:          groupId,
      postType:         'achievement',
      achievementKey,
      achievementLabel,
      achievementIcon,
      caption:          `Conquistei: ${achievementLabel}! ${achievementIcon}`,
      visibility:       'public',
    });
  }

  static async autoPostDuelVictory(
    winnerId: string,
    winnerGroupId: string | undefined,
    duelId: string,
    opponentName: string,
    opponentGroupName: string,
    score: string,
    shareOptIn = true
  ): Promise<void> {
    if (!shareOptIn) return;
    await FeedService.createPost({
      authorId:              winnerId,
      groupId:               winnerGroupId,
      postType:              'duel_victory',
      duelId,
      duelOpponentName:      opponentName,
      duelOpponentGroupName: opponentGroupName,
      duelScore:             score,
      caption:               `Venci o Duelo Biblico! ${score} contra ${opponentName} da ${opponentGroupName}. ⚔️`,
      visibility:            'public',
    });
  }

  static async shareActivityProof(
    userId: string,
    groupId: string | undefined,
    participationId: string,
    activityTitle: string,
    proofUrl?: string
  ): Promise<void> {
    await FeedService.createPost({
      authorId:        userId,
      groupId:         groupId,
      postType:        'activity_proof',
      participationId,
      activityTitle,
      imageUrl:        proofUrl,
      caption:         `Completei a atividade: ${activityTitle}! ✅`,
      visibility:      'public',
    });
  }

  static async autoPostNewMember(
    newMemberId: string,
    groupId: string | undefined,
    memberName: string
  ): Promise<void> {
    await FeedService.createPost({
      authorId:   newMemberId,
      groupId:    groupId,
      postType:   'new_member',
      caption:    `O guerreiro ${memberName} foi aprovado na Arena!`,
      visibility: 'public',
    });
  }

  static async autoPostGroupUpdate(
    adminId: string,
    groupId: string,
    updateType: 'name' | 'logo',
    newValue: string
  ): Promise<void> {
    await FeedService.createPost({
      authorId:   adminId,
      groupId:    groupId,
      postType:   'group_update',
      caption:    updateType === 'name' ? newValue : 'Nosso brasão foi forjado novamente!',
      imageUrl:   updateType === 'logo' ? newValue : undefined,
      visibility: 'public',
    });
  }

  // ── Pontuacao do Mural ────────────────────────────────────────────────────

  static async grantPostXP(
    userId: string,
    groupId: string | undefined,
    postType: PostType,
    config: MuralPointsConfig = DEFAULT_MURAL_POINTS
  ): Promise<void> {
    const points = postType === 'bible_study' ? config.studyPoints : config.postPoints;
    if (points <= 0) return;
    const reason = postType === 'bible_study' ? 'mural_study' : 'mural_post';
    await supabase.from('point_logs').insert({
      '"userId"':  userId,
      '"groupId"': groupId ?? null,
      points,
      reason,
    });
    await supabase
      .from('profiles')
      .update({ totalPoints: supabase.rpc('increment', { x: points }) as unknown as number })
      .eq('id', userId);
  }

  static async grantCommentXP(
    userId: string,
    groupId: string | undefined,
    config: MuralPointsConfig = DEFAULT_MURAL_POINTS
  ): Promise<void> {
    if (config.commentPoints <= 0) return;
    const today = new Date().toISOString().split('T')[0];
    const { count } = await supabase
      .from('point_logs')
      .select('*', { count: 'exact', head: true })
      .eq('"userId"', userId)
      .eq('reason', 'mural_comment')
      .gte('created_at', `${today}T00:00:00Z`);

    if ((count ?? 0) >= config.commentMaxDaily) return;

    await supabase.from('point_logs').insert({
      '"userId"':  userId,
      '"groupId"': groupId ?? null,
      points:   config.commentPoints,
      reason:   'mural_comment',
    });
  }
}
