import { supabase } from './supabase';
import { NotificationType } from '../types';

export const NotificationService = {
  /**
   * Envia uma notificação para um usuário específico
   */
  async send(userId: string, type: NotificationType, title: string, content: string, link?: string) {
    try {
      const { error } = await supabase.from('notifications').insert({
        user_id: userId,
        type,
        title,
        content,
        link,
        read: false
      });
      if (error) throw error;
    } catch (err) {
      console.error('Error sending notification:', err);
    }
  },

  /**
   * Notifica todos os Administradores do sistema
   */
  async notifyAdmins(type: NotificationType, title: string, content: string, link?: string) {
    try {
      const { data: admins } = await supabase
        .from('profiles')
        .select('id')
        .eq('role', 'admin');
      
      if (admins) {
        const notifications = admins.map(admin => ({
          user_id: admin.id,
          type,
          title,
          content,
          link,
          read: false
        }));
        await supabase.from('notifications').insert(notifications);
      }
    } catch (err) {
      console.error('Error notifying admins:', err);
    }
  },

  /**
   * Notifica o Líder de um grupo específico
   */
  async notifyGroupLeader(groupId: string, type: NotificationType, title: string, content: string, link?: string) {
    try {
      // Busca o líder do grupo
      const { data: group } = await supabase
        .from('groups')
        .select('leaderId')
        .eq('id', groupId)
        .single();
      
      if (group?.leaderId) {
        await this.send(group.leaderId, type, title, content, link);
      }
    } catch (err) {
      console.error('Error notifying group leader:', err);
    }
  },

  /**
   * Notifica tanto o Admin quanto o Líder do grupo sobre uma ação de membro
   */
  async notifyStaff(groupId: string | undefined, type: NotificationType, title: string, content: string, link?: string) {
    // Notifica admin
    await this.notifyAdmins(type, title, content, link);
    // Notifica líder se houver grupo
    if (groupId) {
      await this.notifyGroupLeader(groupId, type, title, content, link);
    }
  },

  /**
   * Notifica todos os usuários do sistema
   */
  async notifyAll(type: NotificationType, title: string, content: string, link?: string) {
    try {
      const { data: users } = await supabase.from('profiles').select('id');
      if (users) {
        const notifications = users.map(user => ({
          user_id: user.id,
          type,
          title,
          content,
          link,
          read: false
        }));
        await supabase.from('notifications').insert(notifications);
      }
    } catch (err) {
      console.error('Error notifying all users:', err);
    }
  }
};
