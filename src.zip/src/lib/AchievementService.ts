import { supabase } from './supabase';
import { NotificationService } from './NotificationService';
import { FeedService } from './FeedService';

export type Rarity = 'common' | 'rare' | 'epic' | 'legendary';

export interface AchievementDef {
  name: string;
  description: string;
  points: number;
  icon: string;
  rarity: Rarity;
  color: string;
}

export let ACHIEVEMENT_DEFINITIONS: Record<string, AchievementDef> = {
  first_task: {
    name: 'Primeiro Passo 🏁',
    description: 'Completou sua primeira tarefa oficial.',
    points: 50,
    icon: 'Flag',
    rarity: 'common',
    color: '#94a3b8'
  },
  five_tasks: {
    name: 'Membro Ativo 🏃',
    description: 'Completou 5 tarefas com sucesso.',
    points: 150,
    icon: 'Zap',
    rarity: 'rare',
    color: '#3b82f6'
  },
  veteran: {
    name: 'Veterano da Tribo 🛡️',
    description: 'Alcançou a marca de 15 tarefas aprovadas.',
    points: 500,
    icon: 'Shield',
    rarity: 'epic',
    color: '#a855f7'
  },
  reading_streak_7: {
    name: 'Fiel no Pouco 📖',
    description: '7 dias seguidos de leitura bíblica.',
    points: 300,
    icon: 'BookOpen',
    rarity: 'rare',
    color: '#3b82f6'
  },
  reading_streak_15: {
    name: 'Inabalável ⚔️',
    description: '15 dias seguidos mergulhado na Palavra.',
    points: 1000,
    icon: 'Flame',
    rarity: 'epic',
    color: '#a855f7'
  },
  max_level: {
    name: 'Lenda da Arena 🏆',
    description: 'Atingiu o nível máximo de honra.',
    points: 2000,
    icon: 'Crown',
    rarity: 'legendary',
    color: '#f59e0b'
  },
  store_fan: {
    name: 'Consumidor 🛍️',
    description: 'Realizou seu primeiro resgate na loja.',
    points: 50,
    icon: 'ShoppingBag',
    rarity: 'common',
    color: '#94a3b8'
  },

  // ─── OFENSIVAS DE PRESENÇA (Login) ──────────────────────────────────────────
  streak_login_3: {
    name: 'Faísca ⚡',
    description: '3 dias consecutivos de acesso à Arena.',
    points: 30,
    icon: 'Zap',
    rarity: 'common',
    color: '#94a3b8'
  },
  streak_login_7: {
    name: 'Chama da Semana 🔥',
    description: '7 dias consecutivos de presença digital.',
    points: 150,
    icon: 'Flame',
    rarity: 'rare',
    color: '#f97316'
  },
  streak_login_14: {
    name: 'Guardião Quinzenal 🛡️',
    description: '14 dias de presença contínua sem falhas.',
    points: 400,
    icon: 'Shield',
    rarity: 'rare',
    color: '#3b82f6'
  },
  streak_login_30: {
    name: 'Guerreiro do Mês 🏆',
    description: '30 dias consecutivos de acesso — um mês sem falhar.',
    points: 1000,
    icon: 'Trophy',
    rarity: 'epic',
    color: '#a855f7'
  },
  streak_login_60: {
    name: 'Inabalável 💎',
    description: '60 dias de fidelidade absoluta à Arena.',
    points: 2500,
    icon: 'Gem',
    rarity: 'epic',
    color: '#6366f1'
  },
  streak_login_100: {
    name: 'Centurião 🌟',
    description: '100 dias consecutivos — um verdadeiro guerreiro.',
    points: 5000,
    icon: 'Star',
    rarity: 'legendary',
    color: '#f59e0b'
  },
  streak_login_365: {
    name: 'Guardião Eterno 🔱',
    description: '365 dias — um ano inteiro de presença inabalável.',
    points: 15000,
    icon: 'Crown',
    rarity: 'legendary',
    color: '#ec4899'
  },

  // ─── OFENSIVAS DEVOCIONAIS ────────────────────────────────────────────────────
  streak_devotional_7: {
    name: 'Fiel no Pouco 📖',
    description: '7 dias consecutivos de devocional diário concluído.',
    points: 300,
    icon: 'BookOpen',
    rarity: 'rare',
    color: '#3b82f6'
  },
  streak_devotional_14: {
    name: 'Discípulo Ardente ✝️',
    description: '14 dias de devocional diário sem interrupção.',
    points: 750,
    icon: 'BookMarked',
    rarity: 'epic',
    color: '#a855f7'
  },
  streak_devotional_30: {
    name: 'Servidor da Palavra 📜',
    description: '30 dias de devoção — um mês inteiro mergulhado na Palavra.',
    points: 2000,
    icon: 'Scroll',
    rarity: 'epic',
    color: '#a855f7'
  },
  streak_devotional_60: {
    name: 'Apóstolo da Disciplina 🔱',
    description: '60 dias de devocional ininterrupto. Disciplina lendária.',
    points: 5000,
    icon: 'Crown',
    rarity: 'legendary',
    color: '#f59e0b'
  },
};

/**
 * Carrega as definições de conquistas do banco de dados.
 * Caso falhe ou não encontre, mantém as definições hardcoded acima.
 */
export async function loadAchievementDefinitions() {
  try {
    const { data, error } = await supabase
      .from('system_achievements')
      .select('*')
      .eq('isActive', true);

    if (error) throw error;

    if (data && data.length > 0) {
      const newDefs: Record<string, AchievementDef> = {};
      data.forEach((row: any) => {
        newDefs[row.key] = {
          name: row.name,
          description: row.description,
          points: row.points,
          icon: row.icon,
          rarity: row.rarity as Rarity,
          color: row.color || '#94a3b8'
        };
      });
      ACHIEVEMENT_DEFINITIONS = newDefs;
      return newDefs;
    }
  } catch (err) {
    console.error('Error loading achievement definitions:', err);
  }
  return ACHIEVEMENT_DEFINITIONS;
}

export class AchievementService {
  /**
   * Verifica se o usuário atingiu os critérios para novas conquistas
   */
  static async check(userId: string) {
    try {
      // 🚀 Paralelizar as 4 queries independentes em vez de rodar sequencialmente
      const [participationsRes, redemptionsRes, profileRes, completionsRes] = await Promise.all([
        supabase
          .from('participations')
          .select('*', { count: 'exact', head: true })
          .eq('"userId"', userId)
          .eq('status', 'approved'),
        supabase
          .from('redemptions')
          .select('*', { count: 'exact', head: true })
          .eq('"userId"', userId),
        supabase
          .from('profiles')
          .select('totalPoints, "streakLogin", "streakDevotional"')
          .eq('id', userId)
          .single(),
        supabase
          .from('bible_completions')
          .select('created_at')
          .eq('user_id', userId)
          .eq('is_devotional', true)
          .order('created_at', { ascending: false })
      ]);

      const tasksCount = participationsRes.count;
      const redemptionsCount = redemptionsRes.count;
      const profile = profileRes.data;
      const completions = completionsRes.data;

      let streak = 0;
      if (completions && completions.length > 0) {
        const dates = [...new Set(completions.map((l: any) => l.created_at.split('T')[0]))];
        const today = new Date().toISOString().split('T')[0];
        const checkDate = new Date();
        if (!dates.includes(today)) checkDate.setDate(checkDate.getDate() - 1);

        while (true) {
          const dateStr = checkDate.toISOString().split('T')[0];
          if (dates.includes(dateStr)) {
            streak++;
            checkDate.setDate(checkDate.getDate() - 1);
          } else {
            break;
          }
        }
      }

      // Buscar conquistas existentes (depende das queries acima, fica serial)
      const { data: existing } = await supabase
        .from('user_achievements')
        .select('"achievementKey"')
        .eq('"userId"', userId);

      const existingKeys = existing?.map((e: any) => e.achievementKey) || [];

      const toAward: string[] = [];

      if (tasksCount && tasksCount >= 1 && !existingKeys.includes('first_task')) toAward.push('first_task');
      if (tasksCount && tasksCount >= 5 && !existingKeys.includes('five_tasks')) toAward.push('five_tasks');
      if (tasksCount && tasksCount >= 15 && !existingKeys.includes('veteran')) toAward.push('veteran');
      if (redemptionsCount && redemptionsCount >= 1 && !existingKeys.includes('store_fan')) toAward.push('store_fan');

      if (streak >= 7 && !existingKeys.includes('reading_streak_7')) toAward.push('reading_streak_7');
      if (streak >= 15 && !existingKeys.includes('reading_streak_15')) toAward.push('reading_streak_15');

      if (profile && (profile as any).totalPoints >= 10000 && !existingKeys.includes('max_level')) toAward.push('max_level');

      const streakLogin = (profile as any)?.streakLogin ?? 0;
      const streakDevotional = (profile as any)?.streakDevotional ?? 0;
      const loginMilestones = [3, 7, 14, 30, 60, 100, 365];
      const devMilestones = [7, 14, 30, 60];
      for (const m of loginMilestones) {
        if (streakLogin >= m && !existingKeys.includes(`streak_login_${m}`)) toAward.push(`streak_login_${m}`);
      }
      for (const m of devMilestones) {
        if (streakDevotional >= m && !existingKeys.includes(`streak_devotional_${m}`)) toAward.push(`streak_devotional_${m}`);
      }

      for (const key of toAward) {
        await this.award(userId, key);
      }

    } catch (err) {
      console.error('Error checking achievements:', err);
    }
  }

  private static async award(userId: string, key: string) {
    const def = ACHIEVEMENT_DEFINITIONS[key as keyof typeof ACHIEVEMENT_DEFINITIONS];
    if (!def) return;

    try {
      // Usar aspas duplas nas colunas camelCase para garantir persistência correta no Supabase
      const { error } = await supabase
        .from('user_achievements')
        .insert({ '"userId"': userId, '"achievementKey"': key });

      if (error) return;

      // Dar pontos bônus
      const { data: profile } = await supabase.from('profiles').select('name, groupId').eq('id', userId).single();
      
      await supabase.rpc('increment_points', {
        user_id: userId,
        group_id: profile?.groupId,
        pts: def.points,
        reason: `Conquista: ${def.name}`
      });

      // Notificar o usuário
      const rarityLabel = def.rarity === 'legendary' ? '🏆 TROFÉU LENDÁRIO' : 
                          def.rarity === 'epic' ? '🛡️ CONQUISTA ÉPICA' : 
                          def.rarity === 'rare' ? '🏅 MEDALHA RARA' : '🎖️ SELO';

      await NotificationService.send(
        userId,
        'achievement',
        `${rarityLabel}: ${def.name}`,
        `Você desbloqueou algo incrível: ${def.description} (+${def.points} pts)`
      );

      // 📢 Notificar no Chat Global se for Épico ou Lendário
      if (def.rarity === 'epic' || def.rarity === 'legendary') {
        await supabase.from('messages').insert({
          senderId: 'system',
          senderName: 'SISTEMA ARENA',
          text: `🔥 ABSURDO! ${profile?.name} acaba de alcançar o status de ${def.rarity.toUpperCase()} ao desbloquear: "${def.name}"! Reverência ao guerreiro! 👑`,
          groupId: 'global'
        });
      }

    } catch (err) {
      console.error('Error awarding achievement:', err);
    }
  }

  /**
   * Concede uma conquista somente se o usuário ainda não a possui.
   * Chamado diretamente pelo AutomationService no loop de milestones.
   */
  static async awardIfNotExists(userId: string, key: string): Promise<void> {
    const { data: existing } = await supabase
      .from('user_achievements')
      .select('id')
      .eq('"userId"', userId)
      .eq('"achievementKey"', key)
      .maybeSingle();

    if (!existing) {
      await this.award(userId, key);
    }
  }
}
