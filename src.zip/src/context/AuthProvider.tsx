import React, { useEffect, useState, useCallback, useRef } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { UserProfile } from '../types';
import { AuthContext } from './AuthContext';
import { loadAchievementDefinitions } from '../lib/AchievementService';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [revalidateCount, setRevalidateCount] = useState(0);
  const profileRef = useRef<UserProfile | null>(null);
  // Refs estáveis para callbacks (evita recriar o listener de auth a cada render)
  const fetchProfileRef = useRef<((userId: string) => Promise<UserProfile | null>) | null>(null);
  const mountedRef = useRef(true);

  const fetchProfile = useCallback(async (userId: string) => {
    // Timeout de 5s para o perfil não travar a UI
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      clearTimeout(timeoutId);

      if (error) {
        console.error('AuthProvider: Erro RLS ao buscar perfil:', error.code, error.message, error.hint);
        return null;
      }
      return data as UserProfile | null;
    } catch (err) {
      clearTimeout(timeoutId);
      console.error('AuthProvider: Erro ou Timeout ao buscar perfil:', err);
      return null;
    }
  }, []);

  // Manter ref estável para fetchProfile (evita recriar listener)
  fetchProfileRef.current = fetchProfile;

  const triggerRevalidate = useCallback(() => {
    setRevalidateCount(prev => prev + 1);
  }, []);

  const refreshProfile = useCallback(async () => {
    const { data: { user: currentUser } } = await supabase.auth.getUser();
    if (currentUser) {
      const updatedProfile = await fetchProfile(currentUser.id);
      if (mountedRef.current) {
        setProfile(updatedProfile);
        profileRef.current = updatedProfile;
        triggerRevalidate();
      }
    }
  }, [fetchProfile, triggerRevalidate]);

  useEffect(() => {
    mountedRef.current = true;

    // Timer de segurança (8s) — libera o loading caso algo falhe silenciosamente
    const timeoutId = setTimeout(() => {
      if (mountedRef.current) {
        console.warn("AuthProvider: Safety Timeout reached (8s). Liberando loading.");
        setLoading(false);
      }
    }, 8000);

    const initializeAuth = async () => {
      try {
        // Carrega definições de conquistas dinâmicas do banco
        await loadAchievementDefinitions();

        const { data: { session } } = await supabase.auth.getSession();
        if (!mountedRef.current) return;

        if (session?.user) {
          setUser(session.user);
          const p = await fetchProfileRef.current!(session.user.id);
          if (mountedRef.current) {
            setProfile(p);
            profileRef.current = p;
            setLoading(false);
          }
        } else {
          setLoading(false);
        }
      } catch (err) {
        console.error("Auth init error:", err);
        if (mountedRef.current) setLoading(false);
      }
    };

    initializeAuth();

    // ⚠️ CRÍTICO: usar lista de deps VAZIA para não recriar o listener a cada render.
    // O listener usa fetchProfileRef.current que é sempre atualizado via ref estável.
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (!mountedRef.current) return;

      // INITIAL_SESSION é tratado por initializeAuth — ignorar aqui para evitar duplicidade
      if (event === 'INITIAL_SESSION') return;

      const currentUser = session?.user ?? null;
      setUser(currentUser);

      if (currentUser) {
        if (!profileRef.current || event === 'SIGNED_IN' || event === 'USER_UPDATED') {
          try {
            const p = await fetchProfileRef.current!(currentUser.id);
            if (mountedRef.current) {
              setProfile(p);
              profileRef.current = p;
            }
          } catch (err) {
            console.error("Error fetching profile on state change:", err);
          }
        }
      } else {
        if (mountedRef.current) {
          setProfile(null);
          profileRef.current = null;
        }
      }

      if (mountedRef.current) setLoading(false);
    });

    // 🔄 MOTOR DE AUTO-RECUPERAÇÃO (apenas online/visibility — não em focus para evitar spam)
    let recoveryDebounceId: ReturnType<typeof setTimeout> | null = null;

    const handleAutoRecovery = async () => {
      if (!navigator.onLine || !mountedRef.current) return;
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user && mountedRef.current && fetchProfileRef.current) {
          const p = await fetchProfileRef.current(session.user.id);
          if (mountedRef.current) {
            setProfile(p);
            profileRef.current = p;
            setRevalidateCount(c => c + 1);
          }
        }
      } catch (err) {
        console.error("Auto-Recovery error:", err);
      }
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        // Debounce: ignora trocas rápidas de aba (evita fetch em cascata)
        if (recoveryDebounceId) clearTimeout(recoveryDebounceId);
        recoveryDebounceId = setTimeout(handleAutoRecovery, 3000);
      }
    };

    window.addEventListener('online', handleAutoRecovery);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      mountedRef.current = false;
      subscription.unsubscribe();
      clearTimeout(timeoutId);
      if (recoveryDebounceId) clearTimeout(recoveryDebounceId);
      window.removeEventListener('online', handleAutoRecovery);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // ← DEPS VAZIAS: listener de auth deve ser criado UMA única vez

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      profile, 
      loading, 
      signOut, 
      refreshProfile,
      revalidateCount,
      triggerRevalidate 
    }}>
      {children}
    </AuthContext.Provider>
  );
}
