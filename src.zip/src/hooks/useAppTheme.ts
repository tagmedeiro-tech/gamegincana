/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { UserLevel, LEVEL_THRESHOLDS } from '../types';

export interface CustomTab {
  id: string;
  label: string;
  url: string;
  icon: string;
  enabled: boolean;
}

export interface AppTheme {
  primaryColor: string;
  accentColor: string;
  appName: string;
  churchName: string;
  logoType: string;
  logoUrl?: string;
  welcomeMessage: string;
  seasonLabel: string;
  showRanking: boolean;
  showChat: boolean;
  showBible: boolean;
  showStore: boolean;
  showFeed: boolean;
  showActivities: boolean;
  showReadingPlans: boolean;
  showDuel: boolean;
  showMyGroup: boolean;
  customTabs: CustomTab[];
  // Novos campos para a página de login
  loginTitle?: string;
  loginSubtitle?: string;
  loginButtonText?: string;
  registerPrompt?: string;
  registerButtonText?: string;
  whatsappLinks?: Record<string, string>;
  autoDevotional?: {
    startDate: string;
    startBookId: string;
    startChapter: number;
    points: number;
    enabled: boolean;
    mode: 'linear' | 'random';
  };
  dailyLoginBonus?: {
    enabled: boolean;
    points: number;
  };
  coinMultiplier?: number;
  logoError?: boolean;
  setLogoError?: (val: boolean) => void;
  muralPoints?: {
    postPoints: number;
    studyPoints: number;
    commentPoints: number;
    commentMaxDaily: number;
    reactionBonusPoints: number;
    reactionBonusThreshold: number;
  };
  duelSettings?: {
    totalQuestions: number;
    questionTime: number;
    winPoints: number;
    drawPoints: number;
    lossPoints: number;
    winCoins: number;
    drawCoins: number;
    lossCoins: number;
    waitTimeBetweenQuestions: number;
  };
  gincanaStatus?: 'active' | 'waiting' | 'preparing';
  gincanaStartDate?: string;
  levels?: UserLevel[];
  landing?: {
    heroTitle: string;
    heroSubtitle: string;
    ctaText: string;
    videoUrl?: string;
    showStats: boolean;
    showModules: boolean;
    showFeed: boolean;
    showGallery: boolean;
    footerText: string;
  };
}

export const DEFAULT_THEME: AppTheme = {
  primaryColor: '#FBBF24',
  accentColor: '#F59E0B',
  appName: 'TRIBO IDE',
  churchName: 'Igreja do Evangelho',
  logoType: 'landmark',
  welcomeMessage: 'Bem-vindo à Gincana da Tribo!',
  seasonLabel: 'Temporada 2024',
  showRanking: true,
  showChat: true,
  showBible: true,
  showStore: true,
  showFeed: true,
  showActivities: true,
  showReadingPlans: true,
  showDuel: true,
  showMyGroup: true,
  customTabs: [],
  loginTitle: 'Acesso à Tribo',
  loginSubtitle: 'Seja bem-vindo soldado!',
  loginButtonText: 'ENTRAR NA BATALHA',
  registerPrompt: 'Ainda não tem uma tribo?',
  registerButtonText: 'Cadastre-se Agora',
  whatsappLinks: {},
  dailyLoginBonus: {
    enabled: true,
    points: 5
  },
  muralPoints: {
    postPoints: 2,
    studyPoints: 5,
    commentPoints: 1,
    commentMaxDaily: 3,
    reactionBonusPoints: 3,
    reactionBonusThreshold: 5,
  },
  duelSettings: {
    totalQuestions: 10,
    questionTime: 20,
    winPoints: 60,
    drawPoints: 30,
    lossPoints: 15,
    winCoins: 20,
    drawCoins: 10,
    lossCoins: 5,
    waitTimeBetweenQuestions: 1500,
  },
  gincanaStatus: 'active',
  gincanaStartDate: new Date().toISOString(),
  levels: LEVEL_THRESHOLDS,
  landing: {
    heroTitle: 'A MAIOR GINCANA BÍBLICA DA REGIÃO',
    heroSubtitle: 'Prepare-se para a batalha, fortaleça sua fé e lidere sua tribo rumo à vitória na Arena Digital.',
    ctaText: 'ENTRAR NA ARENA',
    videoUrl: '',
    showStats: true,
    showModules: true,
    showFeed: true,
    showGallery: true,
    footerText: '© 2024 Gincana da Tribo - Desenvolvido para a Glória de Deus.'
  }
};

export function useAppTheme() {
    const [theme, setTheme] = useState<AppTheme>(() => {
      const cached = localStorage.getItem('app_theme_cache');
      if (cached) {
        try {
          const parsed = JSON.parse(cached);
          return { ...DEFAULT_THEME, ...parsed };
        } catch (e) {
          console.error('Error parsing theme cache', e);
        }
      }
      return DEFAULT_THEME;
    });
  
    const [logoError, setLogoError] = useState(false);
 
  const applyTheme = (data: AppTheme) => {
    // Mescla com os padrões para garantir que novas propriedades do sistema não sumam
    const mergedData = { ...DEFAULT_THEME, ...data };
    setTheme(mergedData);
    localStorage.setItem('app_theme_cache', JSON.stringify(mergedData));
    document.documentElement.style.setProperty('--color-primary', mergedData.primaryColor);
    const darkPrimary = shadeColor(mergedData.primaryColor, -20);
    document.documentElement.style.setProperty('--color-primary-dark', darkPrimary);
  };

  useEffect(() => {
    const fetchTheme = async () => {
      const { data, error } = await supabase
        .from('config')
        .select('value')
        .eq('key', 'app')
        .single();
      
      if (data?.value && !error) {
        applyTheme(data.value as AppTheme);
      }
    };

    fetchTheme();

    // 🔄 RE-FETCH ON WAKE/FOCUS
    window.addEventListener('focus', fetchTheme);
    window.addEventListener('online', fetchTheme);

    const channel = supabase
      .channel(`public:config:${Math.random()}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'config', filter: 'key=eq.app' }, (payload) => {
        const newData = payload.new as { value?: AppTheme };
        if (newData && newData.value) {
          applyTheme(newData.value);
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      window.removeEventListener('focus', fetchTheme);
      window.removeEventListener('online', fetchTheme);
    };
  }, []);

  return { ...theme, logoError, setLogoError };
}

// Helper to darken colors for primary-dark
function shadeColor(color: string, percent: number) {
    let R = parseInt(color.substring(1,3), 16);
    let G = parseInt(color.substring(3,5), 16);
    let B = parseInt(color.substring(5,7), 16);

    R = Math.floor(R * (100 + percent) / 100);
    G = Math.floor(G * (100 + percent) / 100);
    B = Math.floor(B * (100 + percent) / 100);

    R = (R<255)?R:255;  
    G = (G<255)?G:255;  
    B = (B<255)?B:255;  

    const RR = ((R.toString(16).length===1)?"0"+R.toString(16):R.toString(16));
    const GG = ((G.toString(16).length===1)?"0"+G.toString(16):G.toString(16));
    const BB = ((B.toString(16).length===1)?"0"+B.toString(16):B.toString(16));

    return "#"+RR+GG+BB;
}
