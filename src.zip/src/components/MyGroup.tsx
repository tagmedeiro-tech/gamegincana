import React from 'react';
import { MessageSquare } from 'lucide-react';
import Chat from './Chat';
import PointHistory from './PointHistory';
import { useAuth } from '../context/useAuth';

export default function MyGroup() {
  const { profile } = useAuth();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-1 space-y-6">
        <div className="card-bold bg-zinc-900 border-primary">
          <h2 className="text-3xl font-black mb-2 text-primary uppercase italic tracking-tighter leading-none">
            {profile?.groupId ? `Tribo #${profile.groupId}` : 'Guerreiros da Fé'}
          </h2>
          <div className="h-1 w-16 bg-primary mb-4"></div>
          <p className="text-slate-500 font-bold italic mb-6">Informações e mural da sua tribo.</p>
          
          <div className="space-y-4">
            <div className="p-4 bg-black rounded-xl border-l-4 border-primary">
              <p className="text-[10px] font-black uppercase text-zinc-500">Membros Conectados</p>
              <p className="text-xl font-black text-white italic">12 Guerreiros</p>
            </div>
            <div className="p-4 bg-black rounded-xl border-l-4 border-primary">
              <p className="text-[10px] font-black uppercase text-zinc-500">Ranking da Tribo</p>
              <p className="text-xl font-black text-white italic">2º Lugar</p>
            </div>
          </div>
        </div>

        <div className="card-bold bg-zinc-900 border-primary p-6">
          <PointHistory groupId={profile?.groupId} />
        </div>

        <div className="card-bold bg-primary text-black p-6">
          <div className="flex items-center gap-2 mb-2">
            <MessageSquare size={20} />
            <p className="text-xs font-black uppercase">Dica da Tribo</p>
          </div>
          <p className="font-bold text-sm italic leading-tight">
            "O ferro com o ferro se afia; assim, o homem afia o rosto do seu amigo." Prosperem juntos!
          </p>
        </div>
      </div>

      <div className="lg:col-span-2">
        <Chat groupId={profile?.groupId || 'leoes-juda'} />
      </div>
    </div>
  );
}
