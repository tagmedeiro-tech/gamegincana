/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { UserProfile, Group, ActivityDefinition } from '../types';
import { UserCog, Trash2, Zap, X, Award, Loader2, ClipboardList, CheckCircle2, Search, Archive, AlertTriangle, Cross, Shield, Heart, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useToast } from '../context/ToastContext';
import { useAuth } from '../context/useAuth';
import LoadingSpinner from './LoadingSpinner';

export default function AdminUsers() {
  const { success, error: toastError } = useToast();
  const { profile } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [definitions, setDefinitions] = useState<ActivityDefinition[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  
  // Modais
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [showPointsModal, setShowPointsModal] = useState(false);
  const [showActivityModal, setShowActivityModal] = useState(false);
  const [showDossierModal, setShowDossierModal] = useState(false);

  // Modal de confirmação customizado (window.confirm é bloqueado em iframes/dev)
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    title: string;
    message: string;
    danger?: boolean;
    onConfirm: () => void;
  }>({ open: false, title: '', message: '', onConfirm: () => {} });

  const showConfirm = (title: string, message: string, onConfirm: () => void, danger = true) => {
    setConfirmDialog({ open: true, title, message, danger, onConfirm });
  };

  const closeConfirm = () => setConfirmDialog(prev => ({ ...prev, open: false }));
  
  // Form States
  const [adjustAmount, setAdjustAmount] = useState<number>(0);
  const [selectedActivityId, setSelectedActivityId] = useState<string>('');
  const [processing, setProcessing] = useState(false);
  const [filter, setFilter] = useState<'all' | 'active' | 'pending' | 'inactive' | 'archived'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [groupFilter, setGroupFilter] = useState('all');

  // Gatilho de atualização
  const refresh = () => setRefreshTrigger(prev => prev + 1);

  useEffect(() => {
    let mounted = true;

    const loadData = async () => {
      try {
        setLoading(true);
        // 🚀 Busca independente com limite estendido para evitar paginação PostgREST (default 1000)
        const [usersRes, groupsRes, defsRes] = await Promise.allSettled([
          supabase.from('profiles').select('*').order('name').limit(2000),
          supabase.from('groups').select('*').order('name'),
          supabase.from('activity_definitions').select('*').eq('is_active', true)
        ]);

        if (!mounted) return;

        // Processamento de Usuários
        if (usersRes.status === 'fulfilled' && usersRes.value.data) {
          // Normalização: perfis sem status são considerados 'active' por padrão
          setUsers(usersRes.value.data.map(u => ({ 
            uid: u.id, 
            ...u, 
            status: u.status || 'active' 
          }) as UserProfile));
        } else if (usersRes.status === 'rejected' || (usersRes.status === 'fulfilled' && usersRes.value.error)) {
          console.error("Erro ao buscar usuários:", usersRes.status === 'fulfilled' ? usersRes.value.error : usersRes.reason);
        }

        // Processamento de Grupos
        if (groupsRes.status === 'fulfilled' && groupsRes.value.data) {
          setGroups(groupsRes.value.data as Group[]);
        }

        // Processamento de Definições
        if (defsRes.status === 'fulfilled' && defsRes.value.data) {
          setDefinitions(defsRes.value.data as ActivityDefinition[]);
        }

      } catch (error) {
        console.error("Error fetching admin data:", error);
      } finally {
        if (mounted) setLoading(false);
      }
    };

    loadData();
    return () => { mounted = false; };
  }, [refreshTrigger]);

  const handleUpdateRole = async (userId: string, newRole: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ role: newRole })
        .eq('id', userId);
      
      if (error) throw error;
      setUsers(prev => prev.map(u => u.uid === userId ? { ...u, role: newRole as UserProfile['role'] } : u));
      success("Cargo Atualizado", "O papel do usuário foi alterado.");
    } catch (error) {
      console.error(error);
      toastError("Erro", "Não foi possível atualizar o cargo.");
    }
  };

  const handleUpdateGroup = async (userId: string, groupId: string) => {
    const finalGroupId = groupId === "" || groupId === "none" ? null : groupId;
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ groupId: finalGroupId })
        .eq('id', userId);
      
      if (error) throw error;

      if (finalGroupId) {
        const user = users.find(u => u.uid === userId);
        if (user) {
          const { FeedService } = await import('../lib/FeedService');
          await FeedService.autoPostNewMember(userId, finalGroupId, user.name).catch(console.error);
        }
      }

      setUsers(prev => prev.map(u => u.uid === userId ? { ...u, groupId: finalGroupId } : u));
      success("Tribo Atualizada", "O guerreiro foi movido para a nova tribo.");
    } catch (error) {
      console.error(error);
      toastError("Erro", "Não foi possível atualizar a tribo.");
    }
  };

  const handleManualPoints = async () => {
    if (!selectedUser || adjustAmount === 0) return;
    setProcessing(true);
    try {
      const { error } = await supabase.rpc('increment_points', {
        user_id: selectedUser.uid,
        group_id: selectedUser.groupId,
        pts: adjustAmount,
        reason: 'Ajuste Manual do Administrador'
      });

      if (error) throw error;
      
      refresh();
      setShowPointsModal(false);
      setAdjustAmount(0);
      success("Pontos Ajustados", "O saldo do guerreiro foi atualizado.");
    } catch (err) {
      console.error(err);
      toastError("Erro", "Não foi possível ajustar os pontos.");
    } finally {
      setProcessing(false);
    }
  };

  const handleManualActivity = async () => {
    if (!selectedUser || !selectedActivityId) return;
    const def = definitions.find(d => d.id === selectedActivityId);
    if (!def) return;

    setProcessing(true);
    try {
      const { error: partError } = await supabase
        .from('participations')
        .insert({
          userId: selectedUser.uid,
          groupId: selectedUser.groupId,
          activityId: def.id,
          status: 'approved',
          pointsEarned: def.current_points,
          proofUrl: 'Lançamento Manual (Admin)'
        });

      if (partError) throw partError;

      const { error: rpcError } = await supabase.rpc('increment_points', {
        user_id: selectedUser.uid,
        group_id: selectedUser.groupId,
        pts: def.current_points,
        reason: `Atividade Manual: ${def.title}`
      });

      if (rpcError) throw rpcError;

      refresh();
      setShowActivityModal(false);
      setSelectedActivityId('');
      success("Atividade Concluída", `Atividade "${def.title}" atribuída com sucesso!`);
    } catch (err) {
      console.error(err);
      toastError("Erro", "Não foi possível atribuir a atividade.");
    } finally {
      setProcessing(false);
    }
  };

  const handleApproveUser = async (userId: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ status: 'active' })
        .eq('id', userId);
      
      if (error) throw error;

      const approvedUser = users.find(u => u.uid === userId);
      if (approvedUser) {
        const { FeedService } = await import('../lib/FeedService');
        await FeedService.autoPostNewMember(userId, approvedUser.groupId, approvedUser.name).catch(console.error);
      }

      setUsers(prev => prev.map(u => u.uid === userId ? { ...u, status: 'active' } : u));
      success("Usuário Aprovado", "O acesso foi liberado com sucesso!");
    } catch (error) {
      console.error(error);
      toastError("Erro", "Não foi possível aprovar o usuário.");
    }
  };

  const handlePermanentDelete = (userId: string) => {
    showConfirm(
      '⚠️ Excluir Permanentemente',
      'Todos os dados deste guerreiro (pontos, participações, histórico) serão apagados permanentemente. Esta ação é irreversível!',
      async () => {
        closeConfirm();
        setProcessing(true);
        try {
          const { error: profileError } = await supabase
            .from('profiles')
            .delete()
            .eq('id', userId);

          if (profileError) throw profileError;

          // Banir no Auth para revogar acesso (nao-critico se falhar)
          try {
            await supabase.rpc('ban_user_in_auth', { user_id: userId });
          } catch (banErr: any) {
            console.warn('ban_user_in_auth:', banErr.message);
          }

          setUsers(prev => prev.filter(u => u.uid !== userId));
          success('Guerreiro Excluído', 'O cadastro foi removido da arena.');
        } catch (error: any) {
          console.error('Erro ao excluir:', error);
          toastError('Erro', error.message || 'Verifique se você tem permissão de Admin.');
        } finally {
          setProcessing(false);
        }
      }
    );
  };

  const handleSoftDelete = (userId: string) => {
    showConfirm(
      'Arquivar Guerreiro',
      'O guerreiro não aparecerá nos rankings, mas todos os dados serão preservados. Você pode reativá-lo depois.',
      async () => {
        closeConfirm();
        try {
          const { error } = await supabase
            .from('profiles')
            .update({ status: 'archived', deleted_at: new Date().toISOString() })
            .eq('id', userId);

          if (error) throw error;
          setUsers(prev => prev.map(u => u.uid === userId ? { ...u, status: 'archived' } : u));
          success('Guerreiro Arquivado', 'O perfil foi movido para a aba de arquivados.');
        } catch (error: any) {
          console.error(error);
          toastError('Erro', error.message || 'Não foi possível arquivar o usuário.');
        }
      }
    );
  };

  const handleReactivate = async (userId: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ 
          status: 'active',
          deleted_at: null
        })
        .eq('id', userId);
      
      if (error) throw error;
      setUsers(prev => prev.map(u => u.uid === userId ? { ...u, status: 'active' } : u));
      success("Guerreiro Reativado", "O perfil voltou à ativa!");
    } catch (error) {
      console.error(error);
      toastError("Erro", "Não foi possível reativar o usuário.");
    }
  };

  const filteredUsers = users.filter(u => {
    const uStatus = (u as any).status || 'active';
    
    // 1. Filtro de Status
    if (filter === 'active') {
       if (uStatus !== 'active') return false;
    } else if (filter === 'pending') {
       if (uStatus !== 'pending') return false;
    } else if (filter === 'inactive') {
       if (uStatus !== 'inactive') return false;
    } else if (filter === 'archived') {
       if (uStatus !== 'archived') return false;
    }
    // No 'all', mostramos quase tudo, exceto arquivados (a menos que explicitamente filtrado)
    if (filter === 'all' && uStatus === 'archived') return false;
    
    // 2. Filtro de Grupo
    if (groupFilter !== 'all' && u.groupId !== groupFilter) return false;

    // 3. Busca por Nome/Email
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q);
    }

    return true;
  });

  if (loading) return <LoadingSpinner message="Mobilizando Guerreiros..." size="md" />;

  return (
    <div className="space-y-6">
      <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-8">
        <div>
          <h2 className="text-4xl font-black uppercase italic tracking-tighter text-primary leading-none">Gerenciar Membros</h2>
          <p className="text-zinc-500 font-bold italic text-xs mt-2 uppercase tracking-widest">Total: {users.length} guerreiros na arena</p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-4 items-center flex-1 max-w-4xl">
          {/* BARRA DE BUSCA */}
          <div className="relative w-full group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-600 group-focus-within:text-primary transition-colors" size={18} />
            <input 
              type="text"
              placeholder="Buscar por nome ou e-mail..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-black/50 border-2 border-zinc-900 focus:border-primary rounded-2xl pl-12 pr-6 py-3.5 font-bold text-white outline-none transition-all placeholder:text-zinc-700"
            />
          </div>

          <div className="flex gap-2 w-full md:w-auto">
            {/* FILTRO DE GRUPO */}
            <select
              value={groupFilter}
              onChange={(e) => setGroupFilter(e.target.value)}
              className="flex-1 md:w-48 bg-black/50 border-2 border-zinc-900 rounded-2xl px-4 py-3 font-black uppercase italic text-[10px] tracking-widest text-zinc-400 outline-none focus:border-primary transition-all appearance-none"
            >
              <option value="all">TODAS AS TRIBOS</option>
              {groups.map(g => (
                <option key={g.id} value={g.id}>{g.name.toUpperCase()}</option>
              ))}
            </select>

            {/* FILTRO DE STATUS */}
            <div className="flex gap-1 bg-black p-1 rounded-2xl border-2 border-zinc-900">
              <button 
                onClick={() => setFilter('all')} 
                className={`text-[10px] px-4 py-2 rounded-xl font-black uppercase tracking-widest transition-all ${filter === 'all' ? 'bg-primary text-black' : 'text-zinc-500 hover:text-white'}`}
              >
                Todos
              </button>
              <button 
                onClick={() => setFilter('active')} 
                className={`text-[10px] px-4 py-2 rounded-xl font-black uppercase tracking-widest transition-all ${filter === 'active' ? 'bg-green-500 text-white' : 'text-zinc-500 hover:text-white'}`}
              >
                Ativos
              </button>
              <button 
                onClick={() => setFilter('pending')} 
                className={`text-[10px] px-4 py-2 rounded-xl font-black uppercase tracking-widest transition-all relative ${filter === 'pending' ? 'bg-orange-500 text-white' : 'text-zinc-500 hover:text-white'}`}
              >
                Pendentes
                {users.filter(u => (u as any).status === 'pending').length > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-white text-black text-[9px] flex items-center justify-center rounded-full font-black border-2 border-orange-500">
                    {users.filter(u => (u as any).status === 'pending').length}
                  </span>
                )}
              </button>
              <button 
                onClick={() => setFilter('archived')} 
                className={`text-[10px] px-4 py-2 rounded-xl font-black uppercase tracking-widest transition-all ${filter === 'archived' ? 'bg-zinc-700 text-white' : 'text-zinc-500 hover:text-white'}`}
              >
                Arquivados
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-4">
        {filteredUsers.length === 0 ? (
          <div className="bg-zinc-900/50 border-2 border-dashed border-zinc-800 rounded-2xl p-8 text-center">
            <p className="text-zinc-500 font-bold italic uppercase">Nenhum guerreiro encontrado</p>
          </div>
        ) : (
          filteredUsers.map((user: any) => (
            <div key={user.uid} className={`bg-zinc-900 shadow-xl rounded-2xl p-4 md:p-6 group transition-transform hover:scale-[1.01] flex flex-col xl:flex-row xl:items-center justify-between gap-4 border-l-4 border-primary ${user.status === 'pending' ? 'ring-2 ring-red-500/20' : ''}`}>
              
              {/* User Info */}
              <div className="flex items-center gap-3 w-full xl:w-auto overflow-hidden">
                <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center text-primary font-black text-xl relative shrink-0">
                  {user.name.charAt(0)}
                  {user.status === 'pending' && <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-zinc-900" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-black text-white uppercase italic truncate text-sm md:text-base leading-none">{user.name}</p>
                    {user.status === 'pending' && (
                      <span className="bg-orange-500/10 text-orange-500 text-[8px] font-black px-1.5 py-0.5 rounded-md uppercase border border-orange-500/20 shrink-0">Pendente</span>
                    )}
                    {user.status === 'archived' && (
                      <span className="bg-zinc-800 text-zinc-500 text-[8px] font-black px-1.5 py-0.5 rounded-md uppercase border border-zinc-700 shrink-0">Arquivado</span>
                    )}
                    {user.status === 'inactive' && (
                      <span className="bg-red-500/10 text-red-500 text-[8px] font-black px-1.5 py-0.5 rounded-md uppercase border border-red-500/20 shrink-0">Inativo</span>
                    )}
                  </div>
                  <p className="text-[10px] text-zinc-500 font-bold truncate mt-0.5">{user.email}</p>
                </div>
              </div>

              {/* Configs (Role & Group) */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full xl:w-auto shrink-0">
                <select 
                  value={user.role}
                  onChange={(e) => handleUpdateRole(user.uid, e.target.value)}
                  className="bg-black border-2 border-zinc-800 rounded-lg px-3 py-2.5 text-xs font-black uppercase text-primary focus:border-primary outline-none appearance-none cursor-pointer"
                >
                  <option value="participant">Participante</option>
                  <option value="leader">Líder</option>
                  <option value="admin">Admin</option>
                </select>

                <select 
                  value={user.groupId || ''}
                  onChange={(e) => handleUpdateGroup(user.uid, e.target.value)}
                  className="bg-black border-2 border-zinc-800 rounded-lg px-3 py-2.5 text-xs font-black uppercase text-white focus:border-primary outline-none appearance-none cursor-pointer truncate max-w-[160px]"
                >
                  <option value="">Sem Tribo</option>
                  {groups.map(g => (
                    <option key={g.id} value={g.id}>{g.name}</option>
                  ))}
                </select>
              </div>

              {/* Points and Actions */}
              <div className="flex items-center justify-between xl:justify-end gap-4 w-full xl:w-auto mt-2 xl:mt-0 pt-4 xl:pt-0 border-t-2 xl:border-t-0 border-zinc-800/50 shrink-0">
                <div className="text-xl md:text-2xl font-black text-primary italic shrink-0">
                  {user.totalPoints || 0}<span className="text-[10px] md:text-xs text-zinc-500 ml-1">XP</span>
                </div>

                <div className="flex items-center gap-2">
                  {user.status === 'pending' ? (
                    <button 
                      onClick={() => handleApproveUser(user.uid)}
                      className="bg-green-600 text-white px-4 py-2.5 rounded-lg font-black uppercase italic text-[10px] hover:bg-white hover:text-black active:scale-95 transition-all flex items-center gap-2 shadow-lg"
                    >
                      <Zap size={14} /> Aprovar
                    </button>
                  ) : (
                    <>
                      <button 
                        onClick={() => { setSelectedUser(user); setShowPointsModal(true); }}
                        className="p-2.5 bg-zinc-800 text-yellow-500 rounded-lg hover:bg-yellow-500 hover:text-black active:scale-95 transition-all shadow-lg"
                        title="Ajustar Pontos"
                      >
                        <Zap size={18} />
                      </button>
                      <button 
                        onClick={() => { setSelectedUser(user); setShowActivityModal(true); }}
                        className="p-2.5 bg-zinc-800 text-primary rounded-lg hover:bg-primary hover:text-black active:scale-95 transition-all shadow-lg"
                        title="Atribuir Atividade"
                      >
                        <Award size={18} />
                      </button>
                      <button 
                        onClick={() => { setSelectedUser(user); setShowDossierModal(true); }}
                        className="p-2.5 bg-zinc-800 text-blue-400 rounded-lg hover:bg-blue-500 hover:text-black active:scale-95 transition-all shadow-lg"
                        title="Dossiê do Membro"
                      >
                        <ClipboardList size={18} />
                      </button>
                    </>
                  )}
                  
                  {user.status === 'archived' ? (
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => handleReactivate(user.uid)}
                        className="p-2.5 bg-green-500 text-black rounded-lg hover:bg-white active:scale-95 transition-all shadow-lg"
                        title="Reativar Guerreiro"
                      >
                        <CheckCircle2 size={18} />
                      </button>
                      <button 
                        onClick={() => handlePermanentDelete(user.uid)}
                        className="p-2.5 bg-red-600 text-white rounded-lg hover:bg-white hover:text-black active:scale-95 transition-all shadow-lg"
                        title="Excluir Permanentemente"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1">
                      <button 
                        onClick={() => handleSoftDelete(user.uid)}
                        className="p-2.5 text-zinc-600 hover:text-orange-500 hover:bg-orange-500/10 rounded-lg active:scale-95 transition-colors"
                        title="Arquivar Guerreiro"
                      >
                        <Archive size={18} />
                      </button>
                      <button 
                        onClick={() => handlePermanentDelete(user.uid)}
                        className="p-2.5 text-zinc-600 hover:text-red-500 hover:bg-red-500/10 rounded-lg active:scale-95 transition-colors"
                        title="Excluir Permanentemente"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  )}
                </div>
              </div>

            </div>
          ))
        )}
      </div>

      {/* MODAL: CONFIRMAÇÃO DE AÇÃO DESTRUTIVA */}
      <AnimatePresence>
        {confirmDialog.open && (
          <div className="fixed inset-0 z-100 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/90 backdrop-blur-sm"
              onClick={closeConfirm}
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
              className={`relative bg-zinc-950 border-4 ${confirmDialog.danger ? 'border-red-600' : 'border-orange-500'} rounded-3xl p-8 w-full max-w-sm shadow-2xl`}
            >
              <div className="flex flex-col items-center text-center gap-4">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center ${confirmDialog.danger ? 'bg-red-600/20' : 'bg-orange-500/20'}`}>
                  <AlertTriangle size={32} className={confirmDialog.danger ? 'text-red-500' : 'text-orange-400'} />
                </div>
                <div>
                  <h3 className="text-xl font-black text-white uppercase italic tracking-tight">{confirmDialog.title}</h3>
                  <p className="text-zinc-400 text-sm mt-2 font-medium leading-relaxed">{confirmDialog.message}</p>
                </div>
                <div className="flex gap-3 w-full mt-2">
                  <button
                    onClick={closeConfirm}
                    className="flex-1 py-3 bg-zinc-800 text-zinc-300 rounded-xl font-black uppercase text-xs hover:bg-zinc-700 transition-all"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={confirmDialog.onConfirm}
                    className={`flex-1 py-3 rounded-xl font-black uppercase text-xs transition-all ${confirmDialog.danger ? 'bg-red-600 text-white hover:bg-white hover:text-red-600' : 'bg-orange-500 text-black hover:bg-white hover:text-orange-600'}`}
                  >
                    Confirmar
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL: AJUSTE DE PONTOS */}
      <AnimatePresence>
        {showPointsModal && selectedUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowPointsModal(false)} />
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="relative bg-zinc-900 border-4 border-yellow-500 rounded-[2.5rem] p-8 w-full max-w-md shadow-2xl">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter">Ajustar Pontos</h3>
                  <p className="text-zinc-500 font-bold uppercase text-[10px] tracking-widest">{selectedUser.name}</p>
                </div>
                <button onClick={() => setShowPointsModal(false)} className="text-zinc-500 hover:text-white"><X size={24} /></button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Quantidade (Positivo ou Negativo)</label>
                  <input 
                    type="number"
                    value={adjustAmount}
                    onChange={(e) => setAdjustAmount(parseInt(e.target.value))}
                    className="w-full bg-black border-2 border-zinc-800 focus:border-yellow-500 p-4 rounded-2xl text-3xl font-black text-center text-yellow-500 outline-none"
                  />
                  <div className="flex gap-2 mt-4">
                    {[+10, +50, -10, -50].map(v => (
                      <button key={v} onClick={() => setAdjustAmount(prev => prev + v)} className="flex-1 bg-zinc-800 hover:bg-zinc-700 py-2 rounded-xl text-xs font-black text-white">
                        {v > 0 ? `+${v}` : v}
                      </button>
                    ))}
                  </div>
                </div>

                <button 
                  onClick={handleManualPoints}
                  disabled={processing || adjustAmount === 0}
                  className="w-full bg-yellow-500 text-black py-4 rounded-2xl font-black uppercase italic tracking-tighter active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {processing ? <><Loader2 className="animate-spin" size={20} /> Processando...</> : "Confirmar Ajuste"}
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {/* MODAL: ATRIBUIR ATIVIDADE */}
        {showActivityModal && selectedUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowActivityModal(false)} />
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="relative bg-zinc-900 border-4 border-primary rounded-[2.5rem] p-8 w-full max-w-lg shadow-2xl">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter">Atribuir Atividade</h3>
                  <p className="text-zinc-500 font-bold uppercase text-[10px] tracking-widest">{selectedUser.name}</p>
                </div>
                <button onClick={() => setShowActivityModal(false)} className="text-zinc-500 hover:text-white"><X size={24} /></button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Selecione a Atividade Concluída</label>
                  <select 
                    value={selectedActivityId}
                    onChange={(e) => setSelectedActivityId(e.target.value)}
                    className="w-full bg-black border-2 border-zinc-800 focus:border-primary p-4 rounded-2xl text-white font-bold outline-none"
                  >
                    <option value="">Escolha uma atividade...</option>
                    {definitions.map(def => (
                      <option key={def.id} value={def.id}>{def.icon} {def.title} (+{def.current_points} XP)</option>
                    ))}
                  </select>
                </div>

                {selectedActivityId && (
                  <div className="bg-primary/5 border-2 border-primary/20 p-4 rounded-2xl">
                    <p className="text-[10px] font-black uppercase text-primary mb-1">Pontuação Automática</p>
                    <p className="text-white font-bold italic">{definitions.find(d => d.id === selectedActivityId)?.description}</p>
                  </div>
                )}

                <button 
                  onClick={handleManualActivity}
                  disabled={processing || !selectedActivityId}
                  className="w-full bg-primary text-black py-4 rounded-2xl font-black uppercase italic tracking-tighter active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {processing ? <><Loader2 className="animate-spin" size={20} /> Lançando...</> : "Lançar Atividade e Pontos"}
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {/* MODAL: DOSSIÊ DO MEMBRO */}
        {showDossierModal && selectedUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowDossierModal(false)} />
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="relative bg-zinc-900 border-4 border-blue-500 rounded-[2.5rem] p-8 w-full max-w-md shadow-2xl">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center border-2 border-blue-500 text-blue-500 font-black text-xl overflow-hidden shrink-0">
                    {selectedUser.avatar_url ? <img src={selectedUser.avatar_url} className="w-full h-full object-cover" /> : selectedUser.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter leading-none">Dossiê</h3>
                    <p className="text-zinc-500 font-bold uppercase text-[10px] tracking-widest mt-1">{selectedUser.name}</p>
                  </div>
                </div>
                <button onClick={() => setShowDossierModal(false)} className="text-zinc-500 hover:text-white"><X size={24} /></button>
              </div>

              <div className="space-y-4">
                {/* Batismo */}
                <div className="flex items-center gap-4 p-4 bg-black rounded-2xl border-2 border-zinc-800">
                  <Cross size={24} className={selectedUser.isBaptized ? "text-blue-500" : "text-zinc-700"} />
                  <div>
                    <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Batismo</p>
                    <p className={`font-bold italic ${selectedUser.isBaptized ? 'text-white' : 'text-zinc-600'}`}>
                      {selectedUser.isBaptized ? 'Sim, é Batizado(a)' : 'Ainda não é batizado(a)'}
                    </p>
                  </div>
                </div>

                {/* Engajamento */}
                <div className="flex items-center gap-4 p-4 bg-black rounded-2xl border-2 border-zinc-800">
                  {selectedUser.isServing ? (
                    <Shield size={24} className="text-green-500" />
                  ) : selectedUser.wantsToServe ? (
                    <Heart size={24} className="text-primary" />
                  ) : (
                    <Shield size={24} className="text-zinc-700" />
                  )}
                  <div>
                    <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Serviço Ministerial</p>
                    <p className={`font-bold italic ${selectedUser.isServing ? 'text-green-400' : selectedUser.wantsToServe ? 'text-primary' : 'text-zinc-600'}`}>
                      {selectedUser.isServing ? 'Já serve em um ministério' : selectedUser.wantsToServe ? 'Tem interesse em servir' : 'Não serve / Sem interesse'}
                    </p>
                  </div>
                </div>

                {/* Área de Interesse/Serviço */}
                {(selectedUser.isServing || selectedUser.wantsToServe) && (
                  <div className="p-4 bg-zinc-800/50 rounded-2xl border-2 border-zinc-700/50">
                    <div className="flex items-start gap-3 mb-2">
                      <MapPin size={16} className="text-zinc-400 mt-1" />
                      <div>
                        <p className="text-[10px] font-black uppercase text-zinc-400 tracking-widest">Área de Atuação</p>
                        <p className="text-white font-black italic">{selectedUser.serviceArea ? selectedUser.serviceArea.toUpperCase() : 'NÃO INFORMADA'}</p>
                      </div>
                    </div>
                    {selectedUser.praiseInstrument && (
                      <div className="pl-7">
                        <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Talento / Instrumento</p>
                        <p className="text-zinc-300 font-bold">{selectedUser.praiseInstrument}</p>
                      </div>
                    )}
                  </div>
                )}
                
                {/* Whatsapp CTA */}
                {selectedUser.whatsapp && (
                  <a 
                    href={`https://wa.me/55${selectedUser.whatsapp.replace(/\D/g, '')}`} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="mt-6 w-full flex items-center justify-center gap-3 py-4 bg-[#25D366]/10 text-[#25D366] border-2 border-[#25D366]/30 rounded-2xl font-black uppercase tracking-widest hover:bg-[#25D366] hover:text-white transition-all"
                  >
                    Chamar no WhatsApp
                  </a>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
