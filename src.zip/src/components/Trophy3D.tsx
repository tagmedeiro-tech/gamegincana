import React from 'react';
import { motion } from 'motion/react';
import * as LucideIcons from 'lucide-react';

interface Trophy3DProps {
  icon: string;
  rarity: 'legendary' | 'epic' | 'rare' | 'common';
  size?: number;
  isFloating?: boolean;
}

export default function Trophy3D({ icon, rarity, size = 64, isFloating = true }: Trophy3DProps) {
  const Icon = (LucideIcons as any)[icon] || LucideIcons.Award;

  // Cores de Alto Contraste (Centro claro, bordas neon)
  const colors = {
    legendary: {
      primary: '#FFF2B2', // Amarelo quase branco para o ícone
      accent: '#F59E0B',  // Amber para as bordas
      glow: 'rgba(245, 158, 11, 0.4)',
      bg: 'rgba(245, 158, 11, 0.1)'
    },
    epic: {
      primary: '#F3E8FF', // Roxo quase branco
      accent: '#A855F7',  // Purple
      glow: 'rgba(168, 85, 247, 0.3)',
      bg: 'rgba(168, 85, 247, 0.1)'
    },
    rare: {
      primary: '#E0F2FE', // Azul quase branco
      accent: '#3B82F6',  // Blue
      glow: 'rgba(59, 130, 246, 0.3)',
      bg: 'rgba(59, 130, 246, 0.1)'
    },
    common: {
      primary: '#F8FAFC', // Branco puro
      accent: '#94A3B8',  // Slate
      glow: 'rgba(148, 163, 184, 0.2)',
      bg: 'rgba(148, 163, 184, 0.05)'
    }
  };

  const current = colors[rarity] || colors.common;

  return (
    <div className="relative flex items-center justify-center select-none" style={{ perspective: '1200px' }}>
      
      {/* 1. Glow Suave de Fundo (Backlight) */}
      <motion.div
        animate={{ 
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3] 
        }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="absolute blur-2xl rounded-full"
        style={{ 
          width: size * 2, 
          height: size * 2, 
          backgroundColor: current.accent 
        }}
      />

      {/* 2. Container Principal (Escudo Medalha) */}
      <motion.div
        animate={isFloating ? {
          y: [-6, 6, -6],
          rotateY: [-10, 10, -10]
        } : {}}
        transition={{ 
          y: { duration: 3, repeat: Infinity, ease: "easeInOut" },
          rotateY: { duration: 4, repeat: Infinity, ease: "easeInOut" }
        }}
        whileHover={{ scale: 1.1, rotateY: 0 }}
        className="relative z-10 flex items-center justify-center"
      >
        {/* Círculo de Fundo (O "Escudo") */}
        <div 
          className="relative rounded-full border-2 flex items-center justify-center shadow-2xl backdrop-blur-sm overflow-hidden"
          style={{ 
            width: size * 1.6, 
            height: size * 1.6,
            backgroundColor: current.bg,
            borderColor: `${current.accent}44`,
            boxShadow: `inset 0 0 20px ${current.glow}, 0 10px 30px rgba(0,0,0,0.5)`
          }}
        >
          {/* Brilho Superior (Efeito de Vidro/Metal) */}
          <div className="absolute top-0 left-0 w-full h-full bg-linear-to-br from-white/20 to-transparent pointer-events-none" />
          
          {/* Ícone com Brilho Intenso */}
          <div className="relative z-20">
            {/* Sombra de profundidade do ícone */}
            <Icon 
              size={size * 0.9} 
              className="absolute top-[2px] left-[2px] opacity-30 blur-[1px]"
              style={{ color: '#000' }}
            />
            {/* Ícone Principal */}
            <Icon 
              size={size * 0.9} 
              strokeWidth={rarity === 'legendary' ? 2.5 : 2}
              style={{ 
                color: current.primary,
                filter: `drop-shadow(0 0 8px ${current.accent})`
              }} 
            />
          </div>
        </div>

        {/* Anel de Luz Único e Elegante */}
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
          className="absolute rounded-full border border-dashed opacity-20"
          style={{ 
            width: size * 2.1, 
            height: size * 2.1,
            borderColor: current.accent
          }}
        />
      </motion.div>

      {/* 3. Sombra de Chão (Simples e Limpa) */}
      <motion.div
        animate={{ scale: [1, 0.8, 1], opacity: [0.4, 0.2, 0.4] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        className="absolute -bottom-8 w-12 h-1.5 bg-black/60 blur-md rounded-full"
      />
    </div>
  );
}



