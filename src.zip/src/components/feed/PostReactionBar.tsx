import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, Share2 } from 'lucide-react';
import { ReactionEmoji, FeedPost } from '../../types';
import { FeedService } from '../../lib/FeedService';
import { useAuth } from '../../context/useAuth';

const EMOJIS: ReactionEmoji[] = ['❤️', '🔥', '🙌', '😂', '😮'];

interface Props {
  post: FeedPost;
  onCommentToggle: () => void;
  showComments: boolean;
  onReactionUpdate: (post: FeedPost) => void;
}

export default function PostReactionBar({ post, onCommentToggle, showComments, onReactionUpdate }: Props) {
  const { profile } = useAuth();
  const [showPicker, setShowPicker] = useState(false);
  const [loading, setLoading] = useState(false);

  const summary = post.reactionSummary ?? {} as Record<ReactionEmoji, number>;
  const totalReactions = Object.values(summary).reduce((a, b) => a + b, 0);

  const handleReact = async (emoji: ReactionEmoji) => {
    if (!profile || loading) return;
    setLoading(true);
    setShowPicker(false);
    try {
      await FeedService.toggleReaction(post.id, profile.id, emoji);
      const reactions = await FeedService.getReactions(post.id);
      const newSummary = reactions.reduce((acc, r) => {
        acc[r.emoji] = (acc[r.emoji] ?? 0) + 1;
        return acc;
      }, {} as Record<ReactionEmoji, number>);
      const myReaction = reactions.find(r => r.userId === profile.id)?.emoji ?? null;
      onReactionUpdate({ ...post, reactions, reactionSummary: newSummary, myReaction });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="px-5 py-3 flex items-center justify-between border-t-2 border-zinc-800/40 relative">
      {/* Reacoes existentes */}
      <div className="flex items-center gap-3">
        {/* Picker trigger */}
        <div className="relative">
          <button
            onClick={() => setShowPicker(p => !p)}
            className={`flex items-center gap-2 font-black uppercase text-[10px] tracking-widest active:scale-95 transition-all
              ${post.myReaction ? 'text-primary' : 'text-zinc-500 hover:text-white'}`}
          >
            <span className="text-base">{post.myReaction ?? '❤️'}</span>
            {totalReactions > 0 && <span>{totalReactions}</span>}
            <span>{post.myReaction ? 'Reagido' : 'Reagir'}</span>
          </button>

          <AnimatePresence>
            {showPicker && (
              <motion.div
                initial={{ opacity: 0, y: 8, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 8, scale: 0.9 }}
                className="absolute bottom-full mb-3 left-0 bg-zinc-800 border-2 border-zinc-700
                           rounded-2xl p-3 flex gap-2 shadow-2xl z-30"
              >
                {EMOJIS.map(emoji => (
                  <button
                    key={emoji}
                    onClick={() => handleReact(emoji)}
                    className={`text-xl w-9 h-9 flex items-center justify-center rounded-xl
                               hover:bg-zinc-700 active:scale-90 transition-all
                               ${post.myReaction === emoji ? 'bg-primary/20 ring-2 ring-primary' : ''}`}
                  >
                    {emoji}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Resumo de emojis */}
        {totalReactions > 0 && (
          <div className="flex items-center gap-0.5">
            {EMOJIS.filter(e => (summary[e] ?? 0) > 0).slice(0, 3).map(e => (
              <span key={e} className="text-sm">{e}</span>
            ))}
          </div>
        )}
      </div>

      {/* Comentar */}
      <button
        onClick={onCommentToggle}
        className={`flex items-center gap-2 font-black uppercase text-[10px] tracking-widest
                   active:scale-95 transition-colors
                   ${showComments ? 'text-white' : 'text-zinc-500 hover:text-white'}`}
      >
        <MessageCircle size={16} />
        <span>{(post.commentCount ?? 0) > 0 ? post.commentCount : ''} Comentar</span>
      </button>
    </div>
  );
}
