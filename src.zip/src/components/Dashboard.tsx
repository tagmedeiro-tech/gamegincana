import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trophy, Shield, Users, ChevronRight, Star, Award, Zap, LayoutGrid, Crown, Medal, BookOpen, AlertCircle } from 'lucide-react';
import { useAppTheme } from '../hooks/useAppTheme';
import { useAuth } from '../context/useAuth';
import { supabase } from '../lib/supabase';
import LoadingSpinner from './LoadingSpinner';
import { Group, Activity, getUserLevel, getLevelProgress, Achievement } from '../types';
import PostCommentSection from './feed/PostCommentSection';
import AchievementList from './AchievementList';
import LevelIcon from './LevelIcon';
import { useToast } from '../context/ToastContext';
import { AIMissionPanel } from './AIMissionPanel';
import { BibleService } from '../lib/BibleService';
import { ReadingPlanService, UserPlan } from '../lib/ReadingPlanService';
import StreakWidget from './StreakWidget';
import { AutomationService } from '../lib/AutomationService';
import { Link, useNavigate } from 'react-router-dom';
import PointHistory from './PointHistory';
import { DuelBanner, MissionsGrid } from './dashboard/DashboardSubcomponents';

interface Member {
  id: string;
  name: string;
  avatar_url?: string;
  totalPoints: number;
}

interface GroupWithMembers extends Group {
  members: Member[];
}

interface RecentLog {
  id: string;
  points: number;
  reason: string;
  profiles?: { name: string } | { name: string }[] | null;
}

export default function Dashboard() {
  const theme = useAppTheme();
  const navigate = useNavigate();
  const { user, profile, loading: authLoading, revalidateCount, signOut, refreshProfile } = useAuth();
  const [groups, setGroups] = useState<GroupWithMembers[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedGroupId, setExpandedGroupId] = useState<string | null>(null);
  const [hasReadToday, setHasReadToday] = useState(false);
  const [recentLogs, setRecentLogs] = useState<RecentLog[]>([]);
  const [readingStreak, setReadingStreak] = useState(0);
  const [weeklyXPData, setWeeklyXPData] = useState<{date: string, points: number}[]>([]);
  const [awardingMemberId, setAwardingMemberId] = useState<string | null>(null);
  const [quickXPValue, setQuickXPValue] = useState<string>("");
  const [processingAward, setProcessingAward] = useState(false);
  const [activeReadingPlan, setActiveReadingPlan] = useState<UserPlan | null>(null);

  const fetchData = useCallback(async () => {
    if (!profile) {
      setLoading(false);
      return;
    }
    
    try {
      const now = new Date();
      const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const todayUTCStr = startOfToday.toISOString();
      
      const toLocalISOString = (dateInput: Date | string) => {
        const d = new Date(dateInput);
        return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().split('T')[0];
      };
      const todayLocal = toLocalISOString(now);

      const sevenDaysAgo = new Date(startOfToday);
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      // 1. Bloco Crítico (Ranking) - Mostra a página rápido
      // Profiles: busca apenas os dados necessários por grupo (sem limit 500 global)
      const [groupsRes, activitiesRes] = await Promise.all([
        supabase.from('groups').select('*').order('totalPoints', { ascending: false }).limit(10),
        supabase.from('activities').select('*').eq('status', 'active').order('points', { ascending: false }).limit(5)
      ]);

      // Busca profiles de cada grupo em paralelo — apenas os campos necessários
      let allProfiles: any[] = [];
      if (groupsRes.data && groupsRes.data.length > 0) {
        const groupIds = groupsRes.data.map((g: any) => g.id);
        const { data: profilesData } = await supabase
          .from('profiles')
          .select('id, name, avatar_url, totalPoints, "groupId"')
          .in('"groupId"', groupIds)
          .order('totalPoints', { ascending: false });
        allProfiles = profilesData || [];
      }

      if (groupsRes.data) {
        const processedGroups = groupsRes.data.map((g: any) => ({
          ...g,
          members: allProfiles.filter(p => p.groupId === g.id)
        }));
        setGroups(processedGroups as GroupWithMembers[]);
      }

      if (activitiesRes.data) {
        setActivities(activitiesRes.data as Activity[]);
      }

      // Liberar o loading assim que o essencial carregar
      setLoading(false);

      // 2. Bloco Secundário (Stats, Streak e Feed) - Carrega em background
      const [achievementsRes, todayDevotionalRes, allDevotionalRes, weekLogsRes, feedRes, userPlansRes] = await Promise.all([
        supabase.from('user_achievements').select('*').eq('"userId"', profile.id).order('created_at', { ascending: false }).limit(5),
        supabase.from('point_logs').select('id, created_at').eq('"userId"', profile.id).ilike('reason', '%devoc%').gte('created_at', todayUTCStr).limit(1),
        supabase.from('point_logs').select('created_at').eq('"userId"', profile.id).ilike('reason', '%devoc%').order('created_at', { ascending: false }).limit(60),
        supabase.from('point_logs').select('created_at, points').eq('"userId"', profile.id).gte('created_at', sevenDaysAgo.toISOString()),
        supabase.from('point_logs').select('id, points, reason, "userId", created_at').order('created_at', { ascending: false }).limit(5),
        supabase.from('user_reading_plans').select('*').eq('user_id', profile.id).eq('status', 'active').maybeSingle()
      ]);

      if (achievementsRes.data) setAchievements(achievementsRes.data);
      if (todayDevotionalRes.data) setHasReadToday(todayDevotionalRes.data.length > 0);

      // Streak de Leitura
      if (allDevotionalRes.data) {
        const dates = [...new Set(allDevotionalRes.data.map(l => toLocalISOString(l.created_at)))];
        let streak = 0;
        const checkDate = new Date();
        if (!dates.includes(todayLocal)) checkDate.setDate(checkDate.getDate() - 1);

        while (true) {
          const dateStr = toLocalISOString(checkDate);
          if (dates.includes(dateStr)) {
            streak++;
            checkDate.setDate(checkDate.getDate() - 1);
          } else {
            break;
          }
        }
        setReadingStreak(streak);
      }

      // Dados do Sparkline (XP Semanal)
      if (weekLogsRes.data) {
        const dailyPts: Record<string, number> = {};
        for (let i = 0; i < 7; i++) {
          const d = new Date();
          d.setDate(d.getDate() - i);
          dailyPts[toLocalISOString(d)] = 0;
        }
        weekLogsRes.data.forEach(log => {
          const date = toLocalISOString(log.created_at);
          if (dailyPts[date] !== undefined) dailyPts[date] += log.points;
        });
        const sparkData = Object.keys(dailyPts).sort().map(d => ({ date: d, points: dailyPts[d] }));
        setWeeklyXPData(sparkData);
      }

      // Feed de Atividades — busca apenas o nome do userId do log
      if (feedRes.data) {
        const userIds = feedRes.data.map((l: any) => l.userId).filter(Boolean);
        let feedProfileMap = new Map<string, string>();
        if (userIds.length > 0) {
          const { data: feedProfiles } = await supabase
            .from('profiles')
            .select('id, name')
            .in('id', userIds);
          if (feedProfiles) feedProfiles.forEach(p => feedProfileMap.set(p.id, p.name));
        }
        const logsWithNames = feedRes.data.map((log: any) => ({
          ...log,
          profiles: log.userId ? { name: feedProfileMap.get(log.userId) || 'Membro' } : null
        }));
        setRecentLogs(logsWithNames as RecentLog[]);
      }

      // Plano de Leitura Ativo
      if (userPlansRes.data) {
        const { data: completions } = await supabase
          .from('reading_plan_completions')
          .select('day_number')
          .eq('user_plan_id', userPlansRes.data.id);
          
        setActiveReadingPlan({
          id: userPlansRes.data.id,
          planId: userPlansRes.data.plan_id,
          startedAt: userPlansRes.data.started_at,
          status: userPlansRes.data.status,
          completedDays: (completions || []).map(c => c.day_number),
        });
      } else {
        setActiveReadingPlan(null);
      }

    } catch (err) {
      console.error("Dashboard error:", err);
    } finally {
      setLoading(false);
    }
  }, [profile, revalidateCount]);

  useEffect(() => {
    if (activeReadingPlan && profile?.id) {
      const plan = ReadingPlanService.getPlanById(activeReadingPlan.planId);
      if (!plan) return;
      const currentDay = activeReadingPlan.completedDays.length >= plan.totalDays 
        ? plan.totalDays 
        : activeReadingPlan.completedDays.length + 1;
      const expectedDay = Math.min(ReadingPlanService.getCurrentDay(activeReadingPlan.startedAt), plan.totalDays);
      const daysLate = expectedDay - currentDay;
      const isLate = daysLate > 0 && !activeReadingPlan.completedDays.includes(currentDay);
      
      if (isLate) {
        const today = new Date().toISOString().split('T')[0];
        const key = `late_notification_sent_${activeReadingPlan.id}_${today}`;
        if (!localStorage.getItem(key)) {
          localStorage.setItem(key, 'true');
          import('../lib/NotificationService').then(({ NotificationService }) => {
            NotificationService.send(
              profile.id,
              'announcement',
              'Plano Atrasado!',
              `Você está ${daysLate} dia${daysLate > 1 ? 's' : ''} atrasado no plano "${plan.name}". Recupere sua leitura hoje!`,
              '/dashboard/reading-plans'
            ).catch(console.error);
          }).catch(console.error);
        }
      }
    }
  }, [activeReadingPlan, profile?.id]);

  useEffect(() => {
    let channel: ReturnType<typeof supabase.channel> | null = null;

    if (profile?.id) {
      fetchData();
      
      // 🔥 Processar Login Diário e Ofensiva de Presença
      AutomationService.handleDailyLogin(profile.id)
        .then(() => refreshProfile())
        .catch(console.error);

      // 📡 Realtime: Atualizar ranking instantaneamente
      const channelId = `groups-realtime-${Math.random().toString(36).substr(2, 9)}`;
      channel = supabase.channel(channelId)
        .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'groups' }, () => {
          fetchData();
        })
        .subscribe();
    } else if (!authLoading) {
      setLoading(false);
    }

    return () => {
      if (channel) supabase.removeChannel(channel);
    };
  }, [profile?.id, revalidateCount, authLoading, fetchData]);

  const handleQuickAward = async (memberId: string, groupId: string, points: number) => {
    if (processingAward) return;
    setProcessingAward(true);
    try {
      const { error } = await supabase.rpc('increment_points', {
        user_id: memberId,
        group_id: groupId,
        pts: points,
        reason: `Lancamento Rapido: +${points} XP`
      });

      if (error) throw error;
      
      // Feedback visual e refresh
      setAwardingMemberId(null);
      refreshProfile?.();
      fetchData(); // 🔄 Atualiza o dashboard imediatamente após award
      alert(`+${points} XP creditados com sucesso!`);
    } catch (err) {
      console.error("Erro ao atribuir pontos:", err);
      alert("Erro ao processar pontos.");
    } finally {
      setProcessingAward(false);
    }
  };

  // 1. Aguarda auth completar (transitório — AuthProvider resolve em < 2s)
  if (authLoading) {
    return <LoadingSpinner message="Sincronizando Arena..." size="lg" fullScreen />;
  }

  // 2. Loading local apenas no primeiro carregamento sem dados em cache
  if (loading && groups.length === 0) return <LoadingSpinner message="Mobilizando as Tribos..." size="md" />;

  // 3. Usuário logado mas sem perfil ainda (pode ser pending ou novo)
  if (user && !profile) {
    return <LoadingSpinner message="Buscando seu Perfil na Arena..." size="lg" fullScreen />;
  }

  if (!profile) {
    const isMasterEmail = user?.email?.toLowerCase() === 'tagmedeiro@gmail.com';
    
    const handleCreateMasterProfile = async () => {
      if (!user) return;
      try {
        const { error } = await supabase.from('profiles').upsert({
          id: user.id,
          name: 'Administrador Mestre',
          email: user.email,
          role: 'admin',
          status: 'active',
          totalPoints: 0,
          coins: 0,
          achievements: []
        });
        if (error) throw error;
        alert("Perfil mestre criado com sucesso! Reiniciando...");
        refreshProfile?.();
      } catch (err) {
        console.error("Erro ao criar perfil mestre:", err);
        alert("Falha ao criar perfil: " + (err instanceof Error ? err.message : "Erro de RLS ou Banco"));
      }
    };

    return (
      <div className="max-w-4xl mx-auto py-12 px-6">
        <div className="bg-zinc-900 border-4 border-red-500 rounded-[3rem] p-12 text-center shadow-[0_0_80px_rgba(239,68,68,0.15)] relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <AlertCircle size={200} className="text-red-500" />
          </div>
          
          <div className="relative z-10">
            <div className="w-24 h-24 bg-black border-4 border-red-500 rounded-full flex items-center justify-center mx-auto mb-8 shadow-[0_0_40px_rgba(239,68,68,0.3)]">
              <AlertCircle size={48} className="text-red-500" />
            </div>
            
            <h2 className="text-5xl font-black italic tracking-tighter text-white uppercase leading-none mb-6">
              PERFIL <span className="text-red-500">INEXISTENTE</span>
            </h2>
            
            <div className="bg-black/50 border-2 border-zinc-800 rounded-2xl p-4 mb-8 inline-block text-left">
              <p className="text-[10px] font-black uppercase text-zinc-500 mb-1">Status da Sessão</p>
              <p className="text-xs font-mono text-zinc-300">UID: {user?.id || 'Desconectado'}</p>
              <p className="text-xs font-mono text-zinc-300">Email: {user?.email || 'N/A'}</p>
            </div>

            <p className="text-zinc-400 font-bold italic text-lg mb-10 max-w-2xl mx-auto leading-relaxed">
              Detectamos que você está logado no sistema de autenticação, mas seus dados de jogador não foram encontrados no banco de dados da Arena.
            </p>
            
            <div className="flex flex-col items-center gap-4">
              {isMasterEmail && (
                <button 
                  onClick={handleCreateMasterProfile}
                  className="w-full sm:w-auto flex items-center gap-3 px-8 py-5 bg-primary text-black rounded-2xl font-black uppercase italic tracking-tighter hover:bg-white transition-all shadow-[0_0_50px_rgba(251,191,36,0.3)]"
                >
                  <Zap size={24} /> INICIALIZAR PERFIL MESTRE
                </button>
              )}
              
              <div className="flex flex-col sm:flex-row gap-4 w-full justify-center">
                <button 
                  onClick={() => signOut?.()}
                  className="flex-1 sm:flex-initial flex items-center justify-center gap-3 px-8 py-4 bg-zinc-800 text-white rounded-2xl font-black uppercase italic tracking-tighter hover:bg-zinc-700 transition-all"
                >
                  SAIR DO SISTEMA
                </button>
                <button 
                  onClick={() => window.location.reload()}
                  className="flex-1 sm:flex-initial flex items-center justify-center gap-3 px-8 py-4 border-2 border-zinc-800 text-zinc-500 rounded-2xl font-black uppercase italic tracking-tighter hover:text-white hover:border-white transition-all"
                >
                  RECARREGAR TELA
                </button>
              </div>
            </div>

            {isMasterEmail && (
              <p className="mt-8 text-[10px] text-zinc-600 font-black uppercase tracking-widest">
                Nota: Se o botão falhar, certifique-se de que as políticas de RLS no Supabase foram aplicadas.
              </p>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (profile?.status === 'pending') {
    return (
      <div className="max-w-4xl mx-auto py-12 px-6">
        <div className="bg-zinc-900 border-4 border-primary rounded-[3rem] p-12 text-center shadow-[0_0_80px_rgba(251,191,36,0.15)] relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <Shield size={200} className="text-primary" />
          </div>
          <div className="relative z-10">
            <div className="w-24 h-24 bg-black border-4 border-primary rounded-full flex items-center justify-center mx-auto mb-8 animate-pulse shadow-[0_0_40px_rgba(251,191,36,0.3)]">
              <Zap size={48} className="text-primary" />
            </div>
            <h2 className="text-5xl font-black italic tracking-tighter text-white uppercase leading-none mb-6">
              ACESSO EM <span className="text-primary">ANÁLISE</span>
            </h2>
            <p className="text-zinc-400 font-bold italic text-lg mb-10 max-w-2xl mx-auto leading-relaxed">
              Olá, <span className="text-white">{profile.name}</span>! Seu cadastro na <span className="text-primary uppercase tracking-widest">{theme.appName}</span> foi realizado com sucesso.
              <br/><br/>
              Agora, um administrador ou líder da sua tribo precisa validar sua entrada na arena.
              Geralmente isso leva apenas alguns minutos.
            </p>
            <div className="bg-black/50 border-2 border-zinc-800 rounded-3xl p-6 mb-10 inline-block">
              <p className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-500 mb-2">Sua Tribo Selecionada</p>
              <p className="text-2xl font-black italic text-white uppercase">{groups.find(g => g.id === profile.groupId)?.name || 'Carregando Tribo...'}</p>
            </div>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => window.location.reload()}
                className="flex items-center gap-3 px-8 py-4 bg-primary text-black rounded-2xl font-black uppercase italic tracking-tighter hover:bg-white transition-all active:scale-95"
              >
                <ChevronRight size={20} className="rotate-180" /> ATUALIZAR STATUS
              </button>
              <button
                onClick={() => signOut?.()}
                className="text-zinc-500 hover:text-white font-black uppercase italic text-sm tracking-widest px-8 py-4 transition-colors"
              >
                SAIR DO SISTEMA
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const topThree = groups.slice(0, 3);
  const remainingGroups = groups.slice(3);
  const maxPoints = Math.max(...groups.map(g => g.totalPoints), 1);

  // RPG Progression Logic
  const pts = profile?.totalPoints || 0;
  const lvl = getUserLevel(pts, theme.levels);
  const pct = getLevelProgress(pts, theme.levels);
  const nextLvl = lvl.level < (theme.levels?.length || 5) ? lvl.level + 1 : null;

  // Meu Grupo Logic
  const myGroupIndex = groups.findIndex(g => g.id === profile?.groupId);
  const myGroup = myGroupIndex !== -1 ? groups[myGroupIndex] : null;
  const myRank = myGroupIndex + 1;
  const nextGroup = myGroupIndex > 0 ? groups[myGroupIndex - 1] : null;
  const pointsToNext = nextGroup && myGroup ? nextGroup.totalPoints - myGroup.totalPoints : 0;

  // Cores dinâmicas da tribo
  const tribePrimary = myGroup?.primaryColor || theme.primaryColor || '#FBBF24';
  const tribeSecondary = myGroup?.secondary_color || '#78350f';

  // Sparkline computation
  const maxXP = weeklyXPData.length > 0 ? Math.max(...weeklyXPData.map(d => d.points), 1) : 1;
  const sparkPoints = weeklyXPData.length > 0 ? weeklyXPData.map((d, i) => {
    const x = (i / (weeklyXPData.length - 1 || 1)) * 60;
    const y = 20 - ((d.points / maxXP) * 20);
    return `${x},${y}`;
  }).join(' ') : "0,20 60,20";

  return (
    <div className="space-y-12 pb-20 overflow-x-hidden w-full">
      {/* HEADER PREMIUM */}
      <header className="flex flex-col xl:flex-row xl:items-center justify-between gap-6 mb-4 w-full">
        {/* HERO STATUS CARD (LEFT) */}
        <div className="flex items-center gap-4 w-full xl:w-auto order-2 xl:order-1">
          {/* NotificationBell removido daqui e movido para o Sidebar global */}
          
          <div className="bg-zinc-900/50 border-4 border-zinc-800 p-3 pr-4 sm:pr-8 rounded-[32px] sm:rounded-3xl flex items-center gap-4 sm:gap-6 relative overflow-hidden group hover:border-primary transition-all flex-1 xl:flex-none w-full">
             <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full border-4 shadow-xl overflow-hidden shrink-0 relative z-10" style={{ borderColor: lvl.color }}>
                {profile?.avatar_url || profile?.avatarUrl
                  ? <img src={profile.avatar_url || profile.avatarUrl} alt={profile.name} className="w-full h-full object-cover" />
                  : <div className="w-full h-full flex items-center justify-center bg-zinc-900 font-black text-lg sm:text-xl text-zinc-500">{profile?.name?.charAt(0)}</div>
                }
             </div>
             
             <div className="flex-1 space-y-2 relative z-10">
                <div className="flex justify-between items-start">
                   <div>
                      <p className="text-white font-black text-[10px] sm:text-[11px] uppercase italic leading-none">{profile?.name?.split(' ')[0]}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <LevelIcon name={lvl.icon} size={10} color={lvl.color} />
                        <p className="text-[8px] sm:text-[9px] font-black uppercase tracking-widest" style={{ color: lvl.color }}>
                          NV. {lvl.level} {lvl.title}
                        </p>
                      </div>
                      {/* 🏅 MINI MEDALS */}
                      <div className="flex gap-1 mt-1.5">
                        {achievements.slice(0, 4).map(ach => (
                          <div key={ach.id} className="w-4 h-4 rounded-full bg-black/40 border border-white/10 flex items-center justify-center">
                            <Star size={8} className="text-primary" />
                          </div>
                        ))}
                      </div>
                   </div>
                </div>
                
                <div className="space-y-1">
                   <div className="flex justify-between text-[6px] font-black uppercase text-zinc-600">
                      <span>PROGRESSO DE XP</span>
                      {nextLvl ? <span>{pct}% → NV.{nextLvl}</span> : <span>MAX LEVEL</span>}
                   </div>
                   <div className="h-1 bg-zinc-950 rounded-full overflow-hidden border border-zinc-800/50">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        className="h-full rounded-full shadow-[0_0_10px_currentColor]"
                        style={{ backgroundColor: lvl.color, color: lvl.color }}
                      />
                   </div>
                </div>
             </div>

             {/* 💰 INTEGRATED SCORE */}
             <div className="pl-6 border-l-2 border-zinc-800/50 flex flex-col items-end shrink-0 relative z-10">
                <div className="absolute -top-1 -right-4 opacity-10 group-hover:opacity-100 transition-opacity">
                   <Zap size={16} className="text-primary" />
                </div>
                <p className="text-[8px] font-black uppercase tracking-widest text-zinc-500 mb-0.5">SCORE</p>
                <div className="flex items-baseline gap-1 mb-2">
                   <span className="text-3xl font-black text-white uppercase italic leading-none">{pts}</span>
                   <span className="text-primary font-black text-[10px] uppercase italic">pts</span>
                </div>
                
                {/* 📈 SPARKLINE */}
                <div className="relative group/spark cursor-default">
                  <svg width="60" height="20" className="overflow-visible">
                    <defs>
                      <linearGradient id="sparkGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.5" />
                        <stop offset="100%" stopColor="#f59e0b" stopOpacity="0" />
                      </linearGradient>
                    </defs>
                    <polygon points={`0,20 ${sparkPoints} 60,20`} fill="url(#sparkGradient)" />
                    <polyline points={sparkPoints} fill="none" stroke="#f59e0b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    {weeklyXPData.length > 0 && (
                      <circle cx="60" cy={20 - ((weeklyXPData[weeklyXPData.length - 1].points / maxXP) * 20)} r="2" fill="#f59e0b" />
                    )}
                  </svg>
                  <div className="absolute -top-6 -right-2 bg-black/90 border border-zinc-800 text-[8px] text-zinc-400 uppercase tracking-wider px-2 py-1 rounded opacity-0 group-hover/spark:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-20">
                    Últimos 7 dias
                  </div>
                </div>
             </div>
          </div>
        </div>

        {/* LOGO & TITLE BLOCK (RIGHT) */}
        <div className="flex items-center gap-4 sm:gap-6 text-right w-full xl:w-auto justify-end order-1 xl:order-2 mt-4 xl:mt-0">
          <div className="text-right">
            <h2 className="text-5xl sm:text-6xl font-black tracking-tight leading-none uppercase text-white italic pr-2" style={{ textShadow: '0 4px 10px rgba(0,0,0,0.5)' }}>
               <span>Arena </span><span style={{ color: tribePrimary, textShadow: `0 0 25px ${tribePrimary}99` }} className="italic">Ide</span>
            </h2>
            <p className="text-zinc-500 font-bold mt-2 italic uppercase tracking-widest sm:tracking-[0.2em] text-[9px] sm:text-[11px]">
              <span>{theme.churchName}</span><span className="opacity-50 mx-1">•</span><span>Temporada {new Date().getFullYear()}</span>
            </p>
          </div>
          <div 
            className="w-16 h-16 sm:w-20 sm:h-20 bg-black rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(0,0,0,0.5)] shrink-0 overflow-hidden border-4 relative group"
            style={{ borderColor: tribePrimary, boxShadow: `0 0 50px ${tribePrimary}40` }}
          >
            {myGroup?.logoUrl || theme.logoUrl ? (
              <>
                <img src={myGroup?.logoUrl || theme.logoUrl} alt="Logo" className="w-full h-full object-cover scale-110 transition-transform duration-700 group-hover:scale-125" />
                <div className="absolute inset-0 shadow-[inset_0_0_20px_rgba(0,0,0,0.8)] rounded-full pointer-events-none"></div>
              </>
            ) : (
              <Shield size={32} sm-size={40} style={{ color: tribePrimary }} />
            )}
          </div>
        </div>
      </header>
      
      {/* 🔥 SISTEMA DE OFENSIVAS (STREAKS) */}
      <StreakWidget />

      {/* MINHA TRIBO (PREMIUM) */}
      {myGroup && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="card-premium flex flex-col md:flex-row items-center justify-between gap-8 group"
        >
          {/* Background Banner (se existir) */}
          {myGroup.banner_url && (
            <div className="absolute inset-0 opacity-20 group-hover:opacity-30 transition-opacity">
              <img src={myGroup.banner_url} alt="Banner" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-linear-to-r from-black via-transparent to-black"></div>
              <div className="absolute inset-0 bg-linear-to-t from-black via-transparent to-transparent"></div>
            </div>
          )}

          {/* Background Glow */}
          <div className="absolute -right-20 -bottom-20 w-96 h-96 blur-[120px] rounded-full opacity-10 pointer-events-none" style={{ backgroundColor: tribePrimary }}></div>
          
          <div className="flex items-center gap-8 relative z-10">
            <div 
              className="w-28 h-28 bg-black rounded-4xl border-2 flex items-center justify-center shrink-0 shadow-2xl transition-all duration-500 group-hover:scale-105 group-hover:-rotate-2"
              style={{ borderColor: tribePrimary, boxShadow: `0 0 30px ${tribePrimary}30` }}
            >
              {myGroup.logoUrl ? (
                <img src={myGroup.logoUrl} alt="Logo" className="w-full h-full object-cover rounded-[1.8rem]" />
              ) : (
                <Users style={{ color: tribePrimary }} size={40} />
              )}
            </div>
            <div>
              <p className="text-[10px] font-black uppercase text-zinc-500 tracking-[0.3em] mb-2">Tropa de Elite</p>
              <h3 className="text-5xl font-black uppercase italic text-white leading-none mb-3 tracking-tighter">{myGroup.name}</h3>
              {myGroup.slogan && (
                <div className="flex items-center gap-2">
                   <div className="w-2 h-2 rounded-full" style={{ backgroundColor: tribePrimary }}></div>
                   <p className="text-sm font-black italic uppercase tracking-tight text-zinc-400">
                    "{myGroup.slogan}"
                  </p>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-10 bg-black/40 backdrop-blur-md px-8 py-6 rounded-4xl border border-zinc-800/50 flex-1 md:flex-none relative z-10">
            <div className="text-center">
              <p className="text-[10px] font-black uppercase text-zinc-500 mb-2 tracking-widest">Global Rank</p>
              <p className="text-5xl font-black italic tracking-tighter leading-none" style={{ color: tribePrimary }}>
                {myRank}º 
              </p>
              <p className="text-[10px] font-bold text-zinc-600 mt-1 uppercase">de {groups.length} tribos</p>
            </div>
            <div className="w-px h-16 bg-zinc-800/50"></div>
            <div className="text-center">
              <p className="text-[10px] font-black uppercase text-zinc-500 mb-2 tracking-widest">Poder Bélico</p>
              <div className="flex items-baseline gap-1 justify-center">
                <p className="text-5xl font-black italic text-white tracking-tighter leading-none">{myGroup.totalPoints}</p>
                <span className="text-[10px] font-black text-zinc-600 uppercase">pts</span>
              </div>
            </div>
          </div>

          {nextGroup && pointsToNext > 0 && (
            <div className="text-right flex-1 md:flex-none relative z-10 min-w-[200px]">
              <p className="text-xs font-black text-zinc-400 uppercase tracking-tighter">Próximo Alvo: <span style={{ color: tribePrimary }}>+{pointsToNext} XP</span></p>
              <p className="text-[10px] font-black uppercase italic text-zinc-600 tracking-tight">para ultrapassar {nextGroup.name}</p>
              {/* Barra de Perseguição Mini */}
              <div className="w-full h-2 bg-black/50 rounded-full mt-4 overflow-hidden border border-zinc-800/50 relative">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${(myGroup.totalPoints / nextGroup.totalPoints) * 100}%` }}
                  className="h-full relative z-10"
                  style={{ backgroundColor: tribePrimary }}
                />
                <div className="absolute inset-0 bg-linear-to-r from-transparent via-white/10 to-transparent animate-sweep"></div>
              </div>
            </div>
          )}
        </motion.div>
      )}

      {/* ⚔️ ARENA DE DUELOS (COMPONENTE MEMOIZADO) */}
      <DuelBanner />

      {/* IA INTELLIGENCE (FASE 5) */}
      {profile && <AIMissionPanel user={profile} />}

      {/* DEVOCIONAL DIÁRIO (AUTOMATIZADO) */}
      {theme.autoDevotional?.enabled && (
        (() => {
          const { book, chapter } = BibleService.getDailyChapter({
            startDate: theme.autoDevotional.startDate,
            startBookId: theme.autoDevotional.startBookId,
            startChapter: theme.autoDevotional.startChapter,
            mode: theme.autoDevotional.mode
          });

          return (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative group"
            >
            <div 
              onClick={() => navigate(`/dashboard/bible?book=${book.id}&chapter=${chapter}`)}
              className={`card-premium group flex flex-col md:flex-row items-center gap-8 transition-all duration-500 overflow-hidden cursor-pointer ${
                hasReadToday 
                  ? 'border-green-500/30! shadow-[0_0_40px_rgba(34,197,94,0.15)]' 
                  : 'hover:border-primary!'
              }`}
            >
                {/* Efeito de brilho ao fundo */}
                <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full blur-[100px] transition-colors opacity-10 ${
                  hasReadToday ? 'bg-green-500' : 'bg-primary'
                }`}></div>
                
                <div className={`relative z-10 w-24 h-24 bg-black rounded-3xl border-2 flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:rotate-3 transition-all ${
                  hasReadToday ? 'border-green-500 shadow-[0_0_30px_rgba(34,197,94,0.2)]' : 'border-primary shadow-[0_0_50px_rgba(251,191,36,0.2)]'
                }`}>
                   <BookOpen size={48} className={hasReadToday ? 'text-green-500' : 'text-primary'} />
                </div>

                <div className="relative z-10 flex-1 text-center md:text-left">
                   <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mb-3">
                      <span className={`badge-premium ${hasReadToday ? 'text-green-500! border-green-500/20!' : 'text-primary! border-primary/20!'}`}>
                        {hasReadToday ? 'CONCLUÍDO' : 'DEVOCIONAL DIÁRIO'}
                      </span>
                      <span className="text-zinc-500 text-[10px] font-black uppercase tracking-widest italic">Leitura do Dia</span>
                      {readingStreak > 0 && (
                        <div className="flex items-center gap-1 bg-orange-500/10 border border-orange-500/30 px-2 py-0.5 rounded-full">
                          <span className="text-[10px]">🔥</span>
                          <span className="text-[9px] font-black text-orange-500 uppercase">{readingStreak} {readingStreak === 1 ? 'Dia' : 'Dias'}</span>
                        </div>
                      )}
                   </div>
                   <h3 className="text-4xl md:text-5xl font-black text-white uppercase italic tracking-tighter leading-none mb-2">
                      <span>{book.name} </span><span className={`italic ${hasReadToday ? 'text-green-500' : 'text-primary'}`}>{chapter}</span>
                   </h3>
                   <p className="text-zinc-400 font-bold italic text-sm md:text-lg">
                     {hasReadToday 
                       ? <span>"XP garantido! O Ciclo Bíblico TRIBO avança amanhã."</span> 
                       : <span>"O Ciclo Bíblico TRIBO avança automaticamente."</span>}
                   </p>
                </div>

                <div className="relative z-10 flex flex-col items-center md:items-end gap-3">
                   <div className="bg-black/50 border-2 border-zinc-800 px-6 py-3 rounded-2xl text-center">
                      <p className="text-[8px] font-black uppercase text-zinc-500 mb-1">RECOMPENSA</p>
                      <p className={`text-2xl font-black italic leading-none ${hasReadToday ? 'text-zinc-500 line-through' : 'text-primary'}`}>
                        +{theme.autoDevotional?.points} XP
                      </p>
                   </div>
                   <div className={`flex items-center gap-2 font-black uppercase italic text-xs tracking-tighter transition-colors ${
                     hasReadToday ? 'text-green-500' : 'text-white group-hover:text-primary'
                   }`}>
                      <span>{hasReadToday ? 'LER NOVAMENTE' : 'LER AGORA'} </span><ChevronRight size={18} />
                   </div>
                </div>
              </div>
            </motion.div>
          );
        })()
      )}
      
      {/* 📚 PLANO DE LEITURA ATIVO */}
      {activeReadingPlan && (() => {
        const plan = ReadingPlanService.getPlanById(activeReadingPlan.planId);
        if (!plan) return null;
        
        const currentDay = activeReadingPlan.completedDays.length >= plan.totalDays 
          ? plan.totalDays 
          : activeReadingPlan.completedDays.length + 1;
        const expectedDay = Math.min(ReadingPlanService.getCurrentDay(activeReadingPlan.startedAt), plan.totalDays);
        const daysLate = expectedDay - currentDay;
        const isLate = daysLate > 0 && !activeReadingPlan.completedDays.includes(currentDay);
        const todayPortion = ReadingPlanService.getDayPortion(plan, currentDay);
        const todayDone = activeReadingPlan.completedDays.includes(currentDay);
        const pct = ReadingPlanService.getProgressPercent(activeReadingPlan.completedDays.length, plan.totalDays);
        
        return (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative group"
          >
            <div 
              onClick={() => navigate("/dashboard/reading-plans")}
              className={`card-premium group flex flex-col md:flex-row items-center gap-8 transition-all duration-500 overflow-hidden cursor-pointer ${
                todayDone 
                  ? 'border-green-500/30! shadow-[0_0_40px_rgba(34,197,94,0.15)]' 
                  : isLate
                    ? 'border-red-500/50! shadow-[0_0_40px_rgba(239,68,68,0.2)]'
                    : 'hover:border-primary!'
              }`}
            >
              <div className={`absolute top-1/2 left-0 -translate-y-1/2 w-64 h-64 rounded-full blur-[100px] transition-colors opacity-10 ${
                todayDone ? 'bg-green-500' : isLate ? 'bg-red-500' : ''
              }`} style={(!todayDone && !isLate) ? { backgroundColor: plan.color } : undefined}></div>
              
              <div 
                className={`relative z-10 w-24 h-24 bg-black rounded-3xl border-2 flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:-rotate-3 transition-all ${
                  todayDone ? 'border-green-500 shadow-[0_0_30px_rgba(34,197,94,0.2)]' : 'shadow-[0_0_50px_rgba(251,191,36,0.1)]'
                }`}
                style={{ borderColor: !todayDone ? plan.color : undefined }}
              >
                 <span className="text-4xl">{plan.icon}</span>
              </div>

              <div className="relative z-10 flex-1 text-center md:text-left">
                 <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mb-3">
                    <span className={`badge-premium ${todayDone ? 'text-green-500! border-green-500/20!' : isLate ? 'text-red-500! border-red-500/20!' : ''}`} style={(!todayDone && !isLate) ? { color: plan.color, borderColor: `${plan.color}33` } : undefined}>
                      {todayDone ? 'DIA CONCLUÍDO' : isLate ? 'LEITURA ATRASADA' : `PLANO: ${plan.name.toUpperCase()}`}
                    </span>
                    <span className="text-zinc-500 text-[10px] font-black uppercase tracking-widest italic">Dia {currentDay} de {plan.totalDays}</span>
                    <div className="bg-zinc-800/50 px-2 py-0.5 rounded-full border border-zinc-700">
                      <span className="text-[9px] font-black text-zinc-400 uppercase">{pct}% COMPLETO</span>
                    </div>
                 </div>
                 <h3 className="text-4xl md:text-5xl font-black text-white uppercase italic tracking-tighter leading-none mb-2">
                    {todayPortion ? ReadingPlanService.formatPortion(todayPortion) : 'Leitura de Hoje'}
                 </h3>
                 <p className="text-zinc-400 font-bold italic text-sm md:text-lg mb-4">
                   {todayDone 
                     ? <span>"Meta cumprida! Mantenha a constância na Palavra."</span> 
                     : isLate
                       ? <span className="text-red-400">"Você está {daysLate} dia{daysLate > 1 ? 's' : ''} atrasado! Recupere sua leitura agora."</span>
                       : <span>"Sua porção diária está pronta. Ganhe +{plan.pointsPerDay} XP."</span>}
                 </p>
                 
                 {/* Mini Progress Bar */}
                 <div className="w-full max-w-[200px] h-1.5 bg-black/40 rounded-full overflow-hidden border border-zinc-800/50 hidden md:block">
                   <motion.div 
                     initial={{ width: 0 }}
                     animate={{ width: `${pct}%` }}
                     className="h-full rounded-full"
                     style={{ backgroundColor: plan.color }}
                   />
                 </div>
              </div>

              <div className="relative z-10 flex flex-col items-center md:items-end gap-3">
                 {!todayDone && todayPortion && (
                   <Link 
                     to={`/dashboard/reading-plans?reader=true&book=${todayPortion.readings[0].bookId}&chapter=${todayPortion.readings[0].chapters[0]}`}
                     onClick={(e) => e.stopPropagation()}
                     className="btn-primary px-8 py-3 rounded-xl font-black uppercase italic tracking-tighter text-sm flex items-center gap-2 group/btn"
                   >
                     <span>LER AGORA</span>
                     <BookOpen size={18} className="group-hover/btn:rotate-12 transition-transform" />
                   </Link>
                 )}
                 
                 <div className="bg-black/50 border-2 border-zinc-800 px-6 py-3 rounded-2xl text-center">
                    <p className="text-[8px] font-black uppercase text-zinc-500 mb-1">RECOMPENSA</p>
                    <p className={`text-2xl font-black italic leading-none ${todayDone ? 'text-zinc-500 line-through' : 'text-primary'}`}>
                      +{plan.pointsPerDay} XP
                    </p>
                 </div>
                 <div className={`flex items-center gap-2 font-black uppercase italic text-xs tracking-tighter transition-colors ${
                   todayDone ? 'text-green-500' : 'text-white group-hover:text-primary'
                 }`}>
                    <span>{todayDone ? 'VER HISTÓRICO' : 'ABRIR PLANO'} </span><ChevronRight size={18} />
                 </div>
              </div>
            </div>
          </motion.div>
        );
      })()}

      {/* --- O PODIO (TOP 3) --- */}
      <section className="space-y-8">
        <div className="flex items-center gap-4">
           <Trophy className="text-primary" size={32} />
           <h3 className="text-3xl font-black uppercase italic tracking-tighter text-white"><span>Elite da Gincana</span></h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {topThree.map((group, index) => {
            const isFirst = index === 0;
            const isExpanded = expandedGroupId === group.id;
            const accentColor = isFirst ? '#000000' : (group.primaryColor || '#FBBF24');
            
            return (
              <div key={group.id} className="space-y-4">
                <motion.div
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.15, duration: 0.5 }}
                  onClick={() => setExpandedGroupId(isExpanded ? null : group.id)}
                  className={`relative cursor-pointer group rounded-[2.5rem] md:rounded-[3rem] p-6 md:p-8 border-4 transition-all duration-500 overflow-hidden will-change-auto ${
                    isFirst 
                      ? 'bg-primary border-white shadow-[0_20px_50px_rgba(251,191,36,0.4)] min-h-64 md:h-64' 
                      : 'bg-zinc-900 border-zinc-800 min-h-56 md:h-56 hover:border-primary hover:-translate-y-2 hover:scale-[1.01]'
                  }`}
                >
                  {/* Glassy Overlay for 1st Place */}
                  {isFirst && <div className="absolute inset-0 bg-linear-to-br from-white/20 to-transparent opacity-50 pointer-events-none" />}
                  
                  {/* RANK BADGE */}
                  <div className={`absolute top-4 right-4 md:top-6 md:right-6 w-10 h-10 md:w-12 md:h-12 rounded-full flex items-center justify-center font-black italic text-lg md:text-xl border-2 z-20 ${
                    isFirst ? 'bg-black text-primary border-black' : 'bg-primary text-black border-primary shadow-lg shadow-primary/20'
                  }`}>
                    <span>{index + 1}º</span>
                  </div>

                  {/* GROUP LOGO / ICON (BACKGROUND GHOST) */}
                  <div className={`absolute right-2 bottom-2 md:right-4 md:bottom-4 w-32 h-32 md:w-48 md:h-48 pointer-events-none z-0 transition-opacity duration-500 ${
                    isFirst ? 'opacity-[0.07] md:opacity-[0.1]' : 'opacity-10 md:opacity-20 grayscale'
                  }`}>
                     {group.logoUrl ? (
                       <img src={group.logoUrl} alt="" className="w-full h-full object-contain" />
                     ) : (
                       <Shield size={192} className={isFirst ? 'text-black' : 'text-primary'} />
                     )}
                  </div>

                  {/* CONTENT */}
                  <div className="relative z-10 h-full flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 md:gap-3 mb-4 md:mb-6">
                        <div className={`p-2 rounded-xl ${isFirst ? 'bg-black/10' : 'bg-primary/10'}`}>
                          {isFirst ? <Crown size={20} className="text-black" /> : <Medal size={18} className="text-primary" />}
                        </div>
                        <p className={`text-[10px] md:text-[11px] font-black uppercase tracking-[0.2em] ${isFirst ? 'text-black/60' : 'text-zinc-500'}`}>
                          <span>{index === 0 ? 'Tribo Soberana' : index === 1 ? 'Vice-Líder' : 'Elite Bronze'}</span>
                        </p>
                      </div>
                      
                      <div className="flex items-center gap-4 md:gap-6">
                        <div className={`w-16 h-16 md:w-20 md:h-20 rounded-2xl md:rounded-3xl border-2 flex items-center justify-center bg-black/20 backdrop-blur-sm shadow-2xl shrink-0 overflow-hidden transition-transform group-hover:rotate-3 ${isFirst ? 'border-white/40' : 'border-zinc-800 group-hover:border-primary'}`}>
                          {group.logoUrl ? (
                            <img src={group.logoUrl} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <Shield size={36} className={isFirst ? 'text-black' : 'text-primary'} />
                          )}
                        </div>
                        <h4 className={`text-3xl md:text-4xl font-black uppercase italic leading-[0.9] tracking-tighter ${isFirst ? 'text-black' : 'text-white'}`}>
                          <span>{group.name}</span>
                        </h4>
                      </div>
                    </div>
                    
                    <div className="flex items-end justify-between mt-6 md:mt-0">
                       <div className="flex flex-col">
                          <p className={`text-[9px] md:text-[10px] font-black uppercase tracking-widest opacity-60 mb-1 ${isFirst ? 'text-black' : 'text-zinc-500'}`}>Poder Bélico</p>
                          <p className={`text-4xl md:text-5xl font-black italic leading-none ${isFirst ? 'text-black' : 'text-primary'}`}>
                             <span>{group.totalPoints} </span><span className="text-xs md:text-sm uppercase ml-1">pts</span>
                          </p>
                       </div>
                       
                       <div className={`flex items-center gap-2.5 px-4 md:px-5 py-2 md:py-3 rounded-2xl border backdrop-blur-md transition-all shadow-lg ${
                         isFirst 
                           ? 'bg-black/10 border-black/10 text-black shadow-black/5' 
                           : 'bg-black/60 border-zinc-800 text-zinc-400 group-hover:border-primary/40 group-hover:text-white shadow-black/40'
                       }`}>
                          <Users size={14} className="md:w-4 md:h-4" />
                          <span className="text-[11px] md:text-sm font-black uppercase italic">
                            <span>{group.members.length} </span><span className="opacity-60">Membros</span>
                          </span>
                       </div>
                    </div>
                  </div>
                </motion.div>

                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, y: -20, height: 0 }}
                      animate={{ opacity: 1, y: 0, height: 'auto' }}
                      exit={{ opacity: 0, y: -20, height: 0 }}
                      className="bg-zinc-900 border-4 border-zinc-800 rounded-[2.5rem] p-6 space-y-4"
                    >
                      <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500 px-2">
                        <span>Escalação </span><span>{group.name}</span>
                      </p>
                      <div className="space-y-2">
                        {group.members.map((member, mIndex) => {
                          const isLeader = member.role === 'leader' || member.id === group.leaderId;
                          const isGold = mIndex === 0;
                          const isSilver = mIndex === 1;
                          const isBronze = mIndex === 2;
                          
                          let borderClass = 'border-zinc-800 hover:border-primary/40';
                          let bgClass = 'bg-black/40';
                          let rankClass = 'text-zinc-700';
                          
                          if (isGold) {
                            borderClass = 'border-primary/50 shadow-[0_0_15px_rgba(251,191,36,0.1)] hover:border-primary hover:shadow-[0_0_25px_rgba(251,191,36,0.25)]';
                            bgClass = 'bg-primary/5';
                            rankClass = 'text-primary drop-shadow-[0_0_5px_rgba(251,191,36,0.5)]';
                          } else if (isSilver) {
                            borderClass = 'border-zinc-300/50 hover:border-zinc-300';
                            bgClass = 'bg-zinc-300/5';
                            rankClass = 'text-zinc-300';
                          } else if (isBronze) {
                            borderClass = 'border-amber-600/50 hover:border-amber-600';
                            bgClass = 'bg-amber-600/5';
                            rankClass = 'text-amber-600';
                          }
                          
                          if (isLeader) {
                             borderClass = 'border-primary hover:border-white shadow-[0_0_20px_rgba(251,191,36,0.2)]';
                             bgClass = 'bg-black/60';
                          }

                          return (
                            <motion.div 
                              key={member.id} 
                              initial={{ opacity: 0, y: -10 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: mIndex * 0.05 }}
                              className="relative"
                            >
                              <div className={`flex items-center gap-3 p-3 rounded-2xl border-2 transition-all hover:-translate-y-1 group/member ${bgClass} ${borderClass}`}>
                                <Link 
                                  to={`/dashboard/profile/${member.id}`} 
                                  onClick={(e) => e.stopPropagation()}
                                  className="flex items-center gap-3 flex-1 min-w-0"
                                >
                                  <div className={`relative w-10 h-10 rounded-full overflow-visible shrink-0 z-10 ${isLeader ? 'border-2 border-primary ring-2 ring-primary/30' : 'border-2 border-zinc-700 group-hover/member:border-primary bg-zinc-800'}`}>
                                    {isLeader && (
                                      <div className="absolute -top-3 -right-2 z-20 animate-pulse-slow">
                                        <Crown size={18} className="text-primary drop-shadow-[0_0_8px_rgba(251,191,36,0.8)]" fill="currentColor" />
                                      </div>
                                    )}
                                    {member.avatar_url ? (
                                      <img src={member.avatar_url} alt={member.name} className="w-full h-full object-cover rounded-full relative z-10" />
                                    ) : (
                                      <div className="w-full h-full flex items-center justify-center text-[10px] text-white font-black bg-linear-to-br from-zinc-700 to-black rounded-full relative z-10">
                                        {member.name.charAt(0)}
                                      </div>
                                    )}
                                  </div>
                                  <div className="flex-1 min-w-0 flex flex-col justify-center">
                                    <p className={`font-black uppercase italic text-[11px] truncate ${isLeader ? 'text-primary drop-shadow-sm' : 'text-white'}`}>
                                      {member.name}
                                    </p>
                                    {isLeader ? (
                                      <p className="text-[8px] font-black tracking-widest text-primary/80 uppercase">Líder da Tribo</p>
                                    ) : null}
                                  </div>
                                </Link>

                                <div className="flex items-center gap-3 shrink-0">
                                  {/* Badge de Pontos */}
                                  <div className="bg-primary/10 border border-primary/20 text-primary px-3 py-1.5 rounded-xl flex items-center justify-center min-w-[60px] md:min-w-[70px]">
                                    <span className="font-black italic text-[10px] md:text-xs">{member.totalPoints} PTS</span>
                                  </div>
                                  
                                  {/* BOTAO DE ACESSO RAPIDO (ADMIN/LIDER) */}
                                  {(profile?.role === 'admin' || (profile?.role === 'leader' && profile?.groupId === group.id)) && (
                                    <button 
                                      onClick={(e) => {
                                        e.preventDefault();
                                        setAwardingMemberId(awardingMemberId === member.id ? null : member.id);
                                      }}
                                      className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${awardingMemberId === member.id ? 'bg-primary text-black' : 'bg-black border-2 border-zinc-800 text-primary hover:border-primary hover:scale-110 shadow-lg shadow-black'}`}
                                    >
                                      <Zap size={14} fill={awardingMemberId === member.id ? "currentColor" : "none"} />
                                    </button>
                                  )}
                                  <span className={`font-black italic text-sm w-6 text-right ${rankClass}`}>#{mIndex + 1}</span>
                                </div>
                              </div>

                            {/* POPUP DE PREMIACAO RAPIDA (PREMIUM) */}
                            <AnimatePresence>
                                  {awardingMemberId === member.id && (
                                    <motion.div 
                                      initial={{ opacity: 0, scale: 0.9, y: 10 }}
                                      animate={{ opacity: 1, scale: 1, y: 0 }}
                                      exit={{ opacity: 0, scale: 0.9, y: 10 }}
                                      className="absolute right-0 top-full mt-3 z-50 card-premium p-5! border-primary/50! shadow-[0_20px_60px_rgba(0,0,0,0.9)] flex flex-col gap-4 min-w-[240px]"
                                    >
                                      <div className="absolute inset-0 bg-primary/5 pointer-events-none"></div>
                                      <div className="flex items-center gap-2 relative z-10">
                                        <Zap size={12} className="text-primary" fill="currentColor" />
                                        <p className="text-[10px] font-black uppercase text-zinc-400 italic tracking-widest">Atribuir XP Rápido</p>
                                      </div>
                                      
                                      <div className="flex gap-2 relative z-10">
                                        {[10, 25, 50].map(pts => (
                                          <button
                                            key={pts}
                                            disabled={processingAward}
                                            onClick={() => handleQuickAward(member.id, group.id, pts)}
                                            className="flex-1 bg-black/60 border border-zinc-800 hover:border-primary hover:bg-primary hover:text-black py-3 rounded-xl text-xs font-black italic transition-all group/btn"
                                          >
                                            <span className="opacity-60 group-hover/btn:opacity-100">+{pts}</span>
                                          </button>
                                        ))}
                                      </div>

                                      <div className="h-px bg-zinc-800/50 relative z-10"></div>

                                      <div className="flex gap-2 relative z-10">
                                        <div className="relative flex-1">
                                          <input 
                                            type="number"
                                            value={quickXPValue}
                                            onChange={(e) => setQuickXPValue(e.target.value)}
                                            placeholder="Personalizado..."
                                            className="w-full bg-black/60 border border-zinc-800 rounded-xl p-3 text-white font-black italic text-xs outline-none focus:border-primary transition-all pr-10"
                                          />
                                          <div className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-black text-zinc-600">XP</div>
                                        </div>
                                        <button
                                          disabled={processingAward || !quickXPValue}
                                          onClick={() => {
                                            handleQuickAward(member.id, group.id, parseInt(quickXPValue));
                                            setQuickXPValue("");
                                          }}
                                          className="bg-primary text-black px-5 rounded-xl text-[10px] font-black italic hover:brightness-110 active:scale-95 transition-all disabled:opacity-30 shadow-lg shadow-primary/20"
                                        >
                                          Lançar
                                        </button>
                                      </div>
                                    </motion.div>
                                  )}
                            </AnimatePresence>
                          </motion.div>
                        )})}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </section>

      {/* --- A PISTA DE PERSEGUIÇÃO --- */}
      {remainingGroups.length > 0 && (
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-black uppercase italic tracking-tighter text-white flex items-center gap-3">
               <LayoutGrid className="text-zinc-600" /><span>A Perseguição</span>
            </h3>
            <p className="text-[10px] font-black uppercase text-zinc-600 italic"><span>Tribos lutando pelo pódio</span></p>
          </div>

          <div className="bg-zinc-900/30 border-4 border-zinc-900 p-8 rounded-[40px] space-y-12">
            {remainingGroups.map((group, index) => {
              const progress = (group.totalPoints / maxPoints) * 100;
              const isExpanded = expandedGroupId === group.id;
              const globalIndex = index + 3;

              return (
                <div key={group.id} className="space-y-4">
                  <div className="relative">
                    <div className="flex items-center justify-between mb-2">
                       <div className="flex items-center gap-3">
                          <span className="text-sm font-black italic text-zinc-600"><span>#</span><span>{globalIndex + 1}</span></span>
                          <h4 className="text-lg font-black uppercase italic text-white"><span>{group.name}</span></h4>
                       </div>
                       <div className="flex items-center gap-4">
                          <span className="text-primary font-black italic text-xl">
                            <span>{group.totalPoints} </span><span className="text-[10px] uppercase tracking-widest">PTS</span>
                          </span>
                          <button 
                            onClick={() => setExpandedGroupId(isExpanded ? null : group.id)}
                            className={`p-2 rounded-xl transition-all ${isExpanded ? 'bg-primary text-black' : 'bg-zinc-800 text-zinc-500 hover:text-white'}`}
                          >
                            <Users size={18} />
                          </button>
                       </div>
                    </div>

                    <div className="h-8 bg-black/50 rounded-xl border-2 border-zinc-800 relative">
                       <motion.div 
                         initial={{ width: 0 }}
                         animate={{ width: `${progress}%` }}
                         transition={{ duration: 1.5, ease: "easeOut" }}
                         className="h-full rounded-lg relative overflow-hidden"
                         style={{ 
                           backgroundColor: group.primaryColor || '#FBBF24',
                           backgroundImage: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.2) 50%, transparent 100%)',
                         }}
                       />
                       <motion.div 
                         initial={{ left: 0 }}
                         animate={{ left: `${progress}%` }}
                         transition={{ duration: 1.5, ease: "easeOut" }}
                         className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-12 h-12 bg-black border-4 rounded-xl flex items-center justify-center shadow-2xl z-20 overflow-hidden"
                         style={{ borderColor: group.primaryColor }}
                       >
                          {group.logoUrl ? (
                            <img src={group.logoUrl} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <Shield size={20} style={{ color: group.primaryColor }} />
                          )}
                       </motion.div>
                    </div>
                  </div>

                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="bg-black/40 rounded-3xl p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 border-2 border-zinc-800"
                      >
                         {group.members.map((member) => (
                            <div key={member.id} className="relative">
                              <div className="flex items-center gap-4 bg-zinc-900/80 p-4 rounded-2xl border-2 border-zinc-800 hover:border-primary transition-all group/member">
                                <Link to={`/dashboard/profile/${member.id}`} className="flex items-center gap-4 flex-1 min-w-0">
                                  <div className="w-12 h-12 rounded-full bg-zinc-800 border-2 border-zinc-700 overflow-hidden group-hover/member:border-primary transition-all">
                                    {member.avatar_url ? (
                                      <img src={member.avatar_url} alt={member.name} className="w-full h-full object-cover" />
                                    ) : (
                                      <div className="w-full h-full flex items-center justify-center text-zinc-600 font-black"><span>{member.name.charAt(0)}</span></div>
                                    )}
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <p className="text-white font-black uppercase italic text-sm truncate"><span>{member.name}</span></p>
                                    <p className="text-primary font-black text-xs">
                                      <span>{member.totalPoints} </span><span>PTS</span>
                                    </p>
                                  </div>
                                </Link>

                                {/* ⚡ ACESSO RAPIDO (ADMIN/LIDER) */}
                                {(profile?.role === 'admin' || (profile?.role === 'leader' && profile?.groupId === group.id)) && (
                                  <button 
                                    onClick={(e) => {
                                      e.preventDefault();
                                      setAwardingMemberId(awardingMemberId === member.id ? null : member.id);
                                    }}
                                    className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${awardingMemberId === member.id ? 'bg-primary text-black' : 'bg-black text-primary border border-primary/20 hover:scale-110'}`}
                                  >
                                    <Zap size={16} fill={awardingMemberId === member.id ? "currentColor" : "none"} />
                                  </button>
                                )}
                              </div>

                              {/* POPUP DE PREMIACAO RAPIDA */}
                              <AnimatePresence>
                                {awardingMemberId === member.id && (
                                  <motion.div 
                                    initial={{ opacity: 0, scale: 0.9, y: 10 }}
                                    animate={{ opacity: 1, scale: 1, y: 0 }}
                                    exit={{ opacity: 0, scale: 0.9, y: 10 }}
                                    className="absolute right-0 top-full mt-2 z-50 bg-black border-2 border-primary p-3 rounded-2xl shadow-2xl flex flex-col gap-3 min-w-[180px]"
                                  >
                                    <p className="text-[9px] font-black uppercase text-zinc-500 italic">Atribuir XP: {member.name.split(' ')[0]}</p>
                                    
                                    <div className="flex gap-2">
                                      {[10, 25, 50].map(pts => (
                                        <button
                                          key={pts}
                                          disabled={processingAward}
                                          onClick={() => handleQuickAward(member.id, group.id, pts)}
                                          className="flex-1 bg-zinc-900 hover:bg-primary hover:text-black py-2 rounded-lg text-[10px] font-black italic transition-all"
                                        >
                                          +{pts}
                                        </button>
                                      ))}
                                    </div>

                                    <div className="h-px bg-zinc-800 my-1"></div>

                                    <div className="flex gap-2">
                                      <input 
                                        type="number"
                                        value={quickXPValue}
                                        onChange={(e) => setQuickXPValue(e.target.value)}
                                        placeholder="Outro..."
                                        className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-white font-black italic text-xs outline-none focus:border-primary transition-all"
                                      />
                                      <button
                                        disabled={processingAward || !quickXPValue}
                                        onClick={() => {
                                          handleQuickAward(member.id, group.id, parseInt(quickXPValue));
                                          setQuickXPValue("");
                                        }}
                                        className="bg-primary text-black px-3 py-2 rounded-lg text-[9px] font-black italic hover:bg-white transition-all disabled:opacity-50"
                                      >
                                        LANÇAR
                                      </button>
                                    </div>
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </div>
                         ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* MISSÕES E CONQUISTAS (COMPONENTE MEMOIZADO) */}
      <MissionsGrid
        activities={activities}
        recentLogs={recentLogs}
        profileId={profile?.id}
      />
    </div>
  );
}
