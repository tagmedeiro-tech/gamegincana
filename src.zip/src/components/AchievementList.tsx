import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Achievement } from '../types';
import { ACHIEVEMENT_DEFINITIONS } from '../lib/AchievementService';
import Trophy3D from './Trophy3D';
import { Medal, Lock, Info, X } from 'lucide-react';

interface AchievementListProps {
  achievements?: Achievement[];
  userBadges?: any[];
}

export default function AchievementList({ achievements = [], userBadges = [] }: AchievementListProps) {
  const [selectedTrophy, setSelectedTrophy] = useState<any | null>(null);

  // Mapear conquistas do sistema que o usuário JÁ GANHOU
  const unlockedSystemKeys = new Set(achievements.map(a => a.achievementKey));
  
  // 1. TROFÉUS DO SISTEMA (Catálogo Completo)
  const systemCatalog = Object.entries(ACHIEVEMENT_DEFINITIONS).map(([key, def]) => {
    const userEarned = achievements.find(a => a.achievementKey === key);
    return {
      ...def,
      key,
      id: userEarned?.id || `locked_${key}`,
      date: userEarned?.created_at || null,
      type: 'system',
      unlocked: unlockedSystemKeys.has(key)
    };
  });

  // 2. SELOS DA TRIBO (Apenas os que o usuário ganhou)
  const tribeBadges = userBadges.map(ub => ({
    name: ub.badges.name,
    description: ub.badges.description || 'Honraria especial concedida pelo líder.',
    points: ub.badges.points,
    icon: ub.badges.icon,
    rarity: 'rare' as const,
    id: ub.id,
    date: ub.created_at,
    type: 'tribe',
    unlocked: true
  }));

  // Unificar e ordenar: Desbloqueados primeiro, depois por raridade
  const allRecognition = [...systemCatalog, ...tribeBadges].sort((a, b) => {
    if (a.unlocked && !b.unlocked) return -1;
    if (!a.unlocked && b.unlocked) return 1;
    return 0;
  });

  return (
    <div className="space-y-8">
      <div className="relative group/gallery">
        {/* Gradientes de Fade (Dicas Visuais de Scroll) */}
        <div className="absolute left-0 top-0 bottom-0 w-12 bg-linear-to-r from-zinc-950/80 to-transparent z-20 pointer-events-none rounded-l-4xl" />
        <div className="absolute right-0 top-0 bottom-0 w-12 bg-linear-to-l from-zinc-950/80 to-transparent z-20 pointer-events-none rounded-r-4xl" />

        {/* Container de Scroll Horizontal */}
        <div className="flex overflow-x-auto gap-4 pb-8 pt-4 px-6 snap-x snap-mandatory no-scrollbar scroll-smooth relative z-10">
          {allRecognition.map((item, i) => {
            const def = item!;
            const isLegendary = def.rarity === 'legendary';
            const isEpic = def.rarity === 'epic';
            const isRare = def.rarity === 'rare';
            const isUnlocked = def.unlocked;

            return (
              <motion.div
                key={def.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => setSelectedTrophy(def)}
                className={`relative flex-none w-[140px] sm:w-[200px] snap-center group/card bg-zinc-900/20 backdrop-blur-md border-2 p-4 sm:p-6 rounded-4xl sm:rounded-[3rem] flex flex-col items-center text-center transition-all duration-500 cursor-pointer ${
                  isUnlocked 
                    ? (isLegendary ? 'border-amber-500/40 shadow-[0_0_30px_rgba(245,158,11,0.15)] hover:bg-amber-500/10 hover:scale-105' :
                       isEpic ? 'border-purple-500/40 shadow-[0_0_25px_rgba(168,85,247,0.15)] hover:bg-purple-500/10 hover:scale-105' :
                       isRare ? 'border-blue-500/40 shadow-[0_0_20px_rgba(59,130,246,0.15)] hover:bg-blue-500/10 hover:scale-105' :
                       'border-zinc-700 hover:bg-zinc-700/30 hover:scale-105')
                    : 'border-zinc-800/50 opacity-50 grayscale hover:opacity-80 hover:grayscale-[0.5] bg-zinc-950/40'
                }`}
              >
                {/* Efeito de Reflexo (Glint) */}
                <div className="absolute inset-0 bg-linear-to-tr from-white/0 via-white/5 to-white/0 opacity-0 group-hover/card:opacity-100 transition-opacity duration-700 pointer-events-none rounded-[inherit]" />

                {/* Status Lock */}
                {!isUnlocked && (
                  <div className="absolute top-4 right-4 text-zinc-700 group-hover/card:text-zinc-500 transition-colors">
                    <Lock size={12} className="sm:w-4 sm:h-4" />
                  </div>
                )}

                {/* Visual do Troféu 3D */}
                <div className="h-24 sm:h-44 flex items-center justify-center mb-4 sm:mb-6 w-full relative">
                   {/* Aura Fantasmagórica para Bloqueados */}
                   {!isUnlocked && (
                      <div className="absolute inset-0 bg-zinc-800/10 blur-2xl rounded-full scale-75" />
                   )}
                   <Trophy3D 
                     icon={def.icon} 
                     rarity={def.rarity as any} 
                     size={window.innerWidth < 640 ? 40 : 80} 
                     isFloating={isUnlocked}
                   />
                </div>

                {/* Conteúdo do Card */}
                <div className="relative z-10 w-full space-y-2">
                  <div>
                     <h4 className={`font-black italic uppercase tracking-tighter text-[10px] sm:text-lg leading-none mb-1 line-clamp-1 ${
                      !isUnlocked ? 'text-zinc-600' :
                      isLegendary ? 'text-amber-400' : 
                      isEpic ? 'text-purple-400' : 
                      'text-white'
                    }`}>
                      {def.name}
                    </h4>
                    <span className={`text-[6px] sm:text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-[0.2em] inline-block ${
                      !isUnlocked ? 'bg-zinc-800/50 text-zinc-700' :
                      isLegendary ? 'bg-amber-500 text-black' :
                      isEpic ? 'bg-purple-500 text-white' :
                      isRare ? 'bg-blue-500/20 text-blue-400' :
                      'bg-zinc-800 text-zinc-500'
                    }`}>
                      {def.rarity}
                    </span>
                  </div>

                  <div className="pt-2 border-t border-white/5 flex flex-col items-center">
                     <p className={`text-[8px] sm:text-xs font-black italic tracking-tighter leading-none ${isUnlocked ? 'text-primary/80' : 'text-zinc-800'}`}>
                       {isUnlocked ? `+${def.points} XP` : '?? XP'}
                     </p>
                  </div>
                </div>
              </motion.div>
            );
          })}
          
          {/* Espaçador final */}
          <div className="flex-none w-12" />
        </div>
        
        {/* Indicador de Navegação (Pill Minimalista) */}
        <div className="flex justify-center gap-2 mt-2">
           <div className="h-1 w-24 bg-zinc-900 rounded-full overflow-hidden relative">
              <motion.div 
                className="absolute inset-y-0 left-0 bg-primary/40 rounded-full"
                style={{ width: '40%' }}
                animate={{ 
                  x: ['0%', '150%', '0%']
                }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
              />
           </div>
        </div>
      </div>

      {/* MODAL DE DETALHES DO TROFÉU */}
      <AnimatePresence>
        {selectedTrophy && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-zinc-900 border-4 border-zinc-800 p-8 rounded-[3rem] w-full max-w-md relative overflow-hidden"
            >
              <button 
                onClick={() => setSelectedTrophy(null)}
                className="absolute top-6 right-6 text-zinc-500 hover:text-white transition-colors"
              >
                <X size={24} />
              </button>

              <div className="flex flex-col items-center text-center">
                <div className="h-48 flex items-center justify-center mb-6">
                  <Trophy3D 
                    icon={selectedTrophy.icon} 
                    rarity={selectedTrophy.rarity} 
                    size={100}
                    isFloating={true}
                  />
                </div>

                <h3 className={`text-3xl font-black italic uppercase tracking-tighter mb-2 ${
                  selectedTrophy.unlocked ? 'text-white' : 'text-zinc-500'
                }`}>
                  {selectedTrophy.name}
                </h3>
                
                <span className={`px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-6 ${
                  selectedTrophy.rarity === 'legendary' ? 'bg-amber-500 text-black' :
                  selectedTrophy.rarity === 'epic' ? 'bg-purple-500 text-white' :
                  'bg-zinc-800 text-zinc-400'
                }`}>
                  {selectedTrophy.rarity}
                </span>

                <div className="bg-black/40 p-6 rounded-3xl border border-white/5 w-full mb-6">
                  <p className="text-zinc-400 font-bold text-sm leading-relaxed">
                    {selectedTrophy.description}
                  </p>
                </div>

                {selectedTrophy.unlocked ? (
                  <div className="text-green-500 font-black uppercase italic flex items-center gap-2 bg-green-500/10 px-6 py-3 rounded-2xl border border-green-500/20 w-full justify-center">
                    <Medal size={20} /> Conquistado em {new Date(selectedTrophy.date).toLocaleDateString()}
                  </div>
                ) : (
                  <div className="text-zinc-500 font-black uppercase italic flex flex-col items-center gap-2 bg-zinc-800/50 px-6 py-4 rounded-2xl border border-zinc-700 w-full">
                    <div className="flex items-center gap-2 text-zinc-400">
                      <Lock size={18} /> TROFÉU BLOQUEADO
                    </div>
                    <p className="text-[10px] text-zinc-600 not-italic mt-1">
                      Continue participando das atividades para desbloquear este prêmio!
                    </p>
                  </div>
                )}
                
                <p className="mt-6 text-primary font-black italic text-xl">
                  +{selectedTrophy.points} XP
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
