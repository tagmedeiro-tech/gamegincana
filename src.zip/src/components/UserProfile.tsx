import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/useAuth';
import { UserProfile as UserProfileType, getUserLevel, getLevelProgress, Achievement } from '../types';
import { Trophy, Star, Calendar, ArrowLeft, Shield, Zap, Medal, MapPin, Edit2, Save, X, Camera, Settings, Coins, ShoppingBag, Users, Gift, RefreshCw, Link, Loader2, Crown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import AchievementList from './AchievementList';
import { useAppTheme, AppTheme } from '../hooks/useAppTheme';
import { useToast } from '../context/ToastContext';
import LoadingSpinner from './LoadingSpinner';
import LevelIcon from './LevelIcon';

export default function UserProfile() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const theme = useAppTheme();
  const { user, refreshProfile: refreshAuthProfile } = useAuth();
  const { success, error: toastError } = useToast();
  
  const [profile, setProfile] = useState<UserProfileType | null>(null);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [userBadges, setUserBadges] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [groupName, setGroupName] = useState<string>('');
  
  // Estados de Edição
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editForm, setEditForm] = useState({
    name: '',
    avatar_url: '',
    favorite_verse: '',
    bio: '',
    whatsapp: ''
  });

  // Estado para Recompensa Especial
  const [showRewardModal, setShowRewardModal] = useState(false);
  const [rewardAmount, setRewardAmount] = useState(100);
  const [rewardReason, setRewardReason] = useState('');
  const [rewarding, setRewarding] = useState(false);


  // Estado para Configurações Globais
  const [appConfig, setAppConfig] = useState<AppTheme | null>(null);
  const [savingConfig, setSavingConfig] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showChallengeMsg, setShowChallengeMsg] = useState(false);

  const allRecognitionCount = achievements.length + userBadges.length;

  useEffect(() => {
    const fetchProfileData = async () => {
      if (!id) {
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        // 1. Perfil e Config
        const [pRes, cRes] = await Promise.all([
          supabase.from('profiles').select('*').eq('id', id).single(),
          supabase.from('config').select('value').eq('key', 'app').single()
        ]);

        if (pRes.error) throw pRes.error;
        const profileData = pRes.data;
        if (cRes.data) setAppConfig(cRes.data.value);
        
        setProfile(profileData);
        
        // 2. Nome do Grupo (Busca separada para evitar erro de relacionamento se a FK estiver faltando)
        if (profileData.groupId) {
          const { data: groupData } = await supabase
            .from('groups')
            .select('name')
            .eq('id', profileData.groupId)
            .single();
          if (groupData) setGroupName(groupData.name);
        } else {
          setGroupName('Sem Tribo');
        }

        setEditForm({
          name: profileData.name || '',
          avatar_url: profileData.avatar_url || profileData.avatarUrl || '',
          favorite_verse: profileData.favorite_verse || '',
          bio: profileData.bio || '',
          whatsapp: profileData.whatsapp || ''
        });

        // 2. Conquistas
        const { data: achData } = await supabase
          .from('user_achievements')
          .select('*')
          .eq('"userId"', id)
          .order('created_at', { ascending: false });

        if (achData) setAchievements(achData);

        // 3. Selos da Tribo (Join com metadados do selo)
        const { data: badgeData } = await supabase
          .from('user_badges')
          .select('*, badges(*)')
          .eq('"userId"', id);
        
        if (badgeData) setUserBadges(badgeData);
      } catch (err) {
        console.error('Error fetching user profile:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchProfileData();
  }, [id]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSaving(true);
    try {
      const sanitizeFilename = (name: string) => {
        return name
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .replace(/[^a-z0-9.]/gi, "_")
          .toLowerCase();
      };

      const fileExt = sanitizeFilename(file.name.split('.').pop() || '');
      const fileName = `${user?.id}-${Math.random()}.${fileExt}`;
      const filePath = `${fileName}`;

      await supabase.storage.createBucket('avatars', { public: true });
      const { error: uploadError } = await supabase.storage.from('avatars').upload(filePath, file);
      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(filePath);
      setEditForm(prev => ({ ...prev, avatar_url: publicUrl }));
    } catch (err) {
      console.error('Error uploading avatar:', err);
      toastError("Erro no Upload", "Não foi possível enviar a foto.");
    } finally {
      setSaving(false);
    }
  };

  const handleSave = async () => {
    if (!profile || !user) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          name: editForm.name,
          avatar_url: editForm.avatar_url,
          avatarUrl: editForm.avatar_url,
          favorite_verse: editForm.favorite_verse,
          bio: editForm.bio,
          whatsapp: editForm.whatsapp
        })
        .eq('id', user.id);

      if (error) throw error;
      
      setProfile(prev => prev ? { ...prev, ...editForm } : null);
      setIsEditing(false);
      await refreshAuthProfile();
      success("Perfil Salvo", "Suas informações foram atualizadas.");
    } catch (err) {
      console.error('Error saving profile:', err);
      toastError("Erro ao Salvar", "Não foi possível salvar as alterações do perfil.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <LoadingSpinner message="Forjando Perfil do Guerreiro..." size="lg" />;
  }

  if (!profile) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-black text-white uppercase italic mb-4">Usuário não encontrado</h2>
        <button onClick={() => navigate(-1)} className="text-yellow-500 font-bold uppercase flex items-center gap-2 mx-auto">
          <ArrowLeft size={18} /> Voltar
        </button>
      </div>
    );
  }

  const lvl = getUserLevel(profile.totalPoints, theme.levels);
  const pct = getLevelProgress(profile.totalPoints, theme.levels);

  const handleGiveReward = async () => {
    if (!profile) return;
    setRewarding(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ coins: (profile.coins || 0) + rewardAmount })
        .eq('id', profile.id);

      if (error) throw error;
      
      success("Recompensa Enviada", `🎉 Recompensa de ${rewardAmount} Moedas enviada com sucesso!`);
      setShowRewardModal(false);
      setProfile({ ...profile, coins: (profile.coins || 0) + rewardAmount });
    } catch (err) {
      console.error(err);
      toastError("Erro", "Não foi possível enviar a recompensa.");
    } finally {
      setRewarding(false);
    }
  };

  const handleCopyAdminInvite = async () => {
    const link = `${window.location.origin}/register?invite=arena-admin-master`;
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
      success("🔥 Link Copiado!", "Envie este link apenas para novos administradores de confiança. Quem se cadastrar por ele terá controle total do sistema.");
    } catch (err) {
      console.error('Erro ao copiar link:', err);
      prompt("Não foi possível copiar automaticamente. Copie o link manual abaixo:", link);
    }
  };

  return (
    <>
    <div className="max-w-5xl mx-auto space-y-8 pb-20">
      {/* HEADER NAVIGATION */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 w-full md:w-auto">
          <button 
            onClick={() => navigate(-1)} 
            className="group flex items-center gap-3 px-5 py-3 bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-2xl text-zinc-400 hover:text-white hover:border-zinc-600 transition-all active:scale-95 shadow-xl"
          >
            <div className="p-1 bg-zinc-800 rounded-lg group-hover:bg-zinc-700 transition-colors">
              <ArrowLeft size={16} />
            </div>
            <span className="font-black uppercase italic tracking-tighter text-sm">Voltar</span>
          </button>

          {user?.id === profile.id && !isEditing && (
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setIsEditing(true)}
                className="group flex items-center gap-3 px-5 py-3 bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-2xl text-zinc-400 hover:text-primary hover:border-primary/30 transition-all active:scale-95 shadow-xl"
              >
                <div className="p-1 bg-zinc-800 rounded-lg group-hover:bg-primary group-hover:text-black transition-all">
                  <Edit2 size={16} />
                </div>
                <span className="font-black uppercase italic tracking-tighter text-sm">Editar Perfil</span>
              </button>

              {profile.role === 'admin' && (
                <button 
                  onClick={() => navigate('/dashboard/admin')}
                  className="group flex items-center gap-3 px-5 py-3 bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-2xl text-red-500/50 hover:text-red-500 hover:border-red-500/30 transition-all active:scale-95 shadow-xl"
                >
                  <div className="p-1 bg-zinc-800 rounded-lg group-hover:bg-red-500 group-hover:text-black transition-all">
                    <Settings size={16} />
                  </div>
                  <span className="font-black uppercase italic tracking-tighter text-sm">Painel Master</span>
                </button>
              )}
            </div>
          )}

          {isEditing && (
            <div className="flex items-center gap-2">
               <button 
                onClick={() => setIsEditing(false)}
                className="flex items-center gap-2 px-5 py-3 bg-zinc-900 border border-zinc-800 rounded-2xl text-zinc-500 hover:text-white transition-all font-black uppercase italic text-xs"
              >
                <X size={16} /> Cancelar
              </button>
              <button 
                onClick={handleSave}
                disabled={saving}
                className="flex items-center gap-2 px-6 py-3 bg-primary text-black rounded-2xl hover:scale-[1.02] hover:shadow-[0_0_20px_rgba(251,191,36,0.3)] transition-all font-black uppercase italic text-sm active:scale-95 disabled:opacity-50"
              >
                {saving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                Salvar Arena
              </button>
            </div>
          )}
        </div>
        
        <div className="flex flex-col items-end">
          <div className="flex items-center gap-2 mb-1">
             <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
             <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500">Perfil Público Ativo</p>
          </div>
          <p className="text-xs font-bold text-zinc-400 italic">Guerreiro desde {new Date(profile.created_at || '').toLocaleDateString('pt-BR')}</p>
        </div>
      </div>

      {/* HERO SECTION */}
      <div className="relative">
        <div className={`absolute inset-0 bg-linear-to-b ${profile.role === 'leader' ? 'from-primary/30' : 'from-yellow-500/10'} to-transparent blur-3xl opacity-30 rounded-full`}></div>
        
        <div className={`bg-zinc-900 border-4 ${profile.role === 'leader' ? 'border-primary shadow-[0_0_80px_rgba(251,191,36,0.15)]' : 'border-zinc-800'} rounded-[3rem] p-8 md:p-12 relative z-10 overflow-hidden`}>
          {/* Background Motif */}
          <div className="absolute top-0 right-0 opacity-[0.03] -mr-20 -mt-20">
            {profile.role === 'leader' ? <Crown size={400} className="text-primary" /> : <Trophy size={400} className="text-white" />}
          </div>

          <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12 mt-6 md:mt-0">
            {/* AVATAR & LEVEL RING */}
            <div className="relative shrink-0 group">
              {profile.role === 'leader' && (
                <div className="absolute -top-12 left-1/2 -translate-x-1/2 z-30 animate-bounce-slow">
                  <Crown size={70} className="text-primary drop-shadow-[0_0_20px_rgba(251,191,36,0.8)]" fill="currentColor" />
                </div>
              )}
              {/* Spinning Ring for high levels or just flair */}
              <div 
                className="absolute -inset-4 md:-inset-6 rounded-full opacity-20 blur-xl animate-pulse"
                style={{ backgroundColor: profile.role === 'leader' ? '#FBBF24' : lvl.color }}
              />
              
              <div 
                className="relative w-36 h-36 md:w-56 md:h-56 rounded-full border-4 p-1.5 md:p-2 z-10 transition-transform duration-700 group-hover:scale-105"
                style={{ borderColor: profile.role === 'leader' ? '#FBBF2488' : `${lvl.color}44` }}
              >
                <div 
                  className="w-full h-full rounded-full border-4 md:border-8 shadow-2xl overflow-hidden relative bg-zinc-950"
                  style={{ borderColor: profile.role === 'leader' ? '#FBBF24' : lvl.color }}
                >
                  {isEditing ? (
                    <div className="w-full h-full relative">
                      <img src={editForm.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${editForm.name}`} alt="Preview" className="w-full h-full object-cover opacity-50" />
                      <label className="absolute inset-0 flex flex-col items-center justify-center cursor-pointer hover:bg-black/40 transition-all gap-2">
                         <Camera size={32} className="text-white" />
                         <span className="text-[10px] font-black uppercase text-white">Mudar Foto</span>
                         <input type="file" className="hidden" accept="image/*" onChange={handleFileUpload} />
                      </label>
                    </div>
                  ) : (
                    profile.avatar_url || profile.avatarUrl ? (
                      <img src={profile.avatar_url || profile.avatarUrl} alt={profile.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-5xl md:text-7xl font-black text-zinc-800">
                        {profile.name.charAt(0)}
                      </div>
                    )
                  )}
                </div>
              </div>
              
              {/* Level Badge Badge */}
              <div 
                className="absolute -bottom-3 left-1/2 -translate-x-1/2 z-20 px-6 py-1.5 rounded-2xl md:rounded-4xl border-2 shadow-2xl flex items-center gap-2"
                style={{ backgroundColor: 'black', borderColor: lvl.color }}
              >
                 <LevelIcon name={lvl.icon} size={14} color={lvl.color} className="animate-pulse" />
                 <p className="text-[10px] md:text-xs font-black uppercase italic tracking-tighter" style={{ color: lvl.color }}>
                   Nível {lvl.level}
                 </p>
              </div>
            </div>

            {/* INFO BLOCK */}
            <div className="flex-1 text-center md:text-left space-y-8">
              <div className="space-y-4">
                <div className="flex flex-col gap-3">
                   {isEditing ? (
                     <input 
                       value={editForm.name}
                       onChange={e => setEditForm({...editForm, name: e.target.value})}
                       className="text-2xl md:text-5xl font-black bg-black border-4 border-primary rounded-2xl px-6 py-3 text-white outline-none w-full max-w-lg italic uppercase"
                       placeholder="Seu Nome"
                     />
                   ) : (
                     <div className="space-y-4">
                       <h1 className="text-4xl md:text-6xl lg:text-7xl font-black text-white uppercase italic tracking-tighter leading-none drop-shadow-[0_5px_15px_rgba(0,0,0,0.5)]">
                         {profile.name}
                       </h1>
                       <div className="flex flex-wrap justify-center md:justify-start gap-3 mt-2">
                         <span className={`inline-flex items-center gap-2 px-3 py-1.5 md:px-5 md:py-2 rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest border shadow-xl ${
                           profile.role === 'admin' 
                            ? 'bg-red-500 text-white border-red-400' 
                            : profile.role === 'leader'
                            ? 'bg-primary text-black border-white/50 shadow-[0_0_20px_rgba(251,191,36,0.5)]'
                            : 'bg-zinc-800 border-zinc-700 text-zinc-300'
                         }`}>
                           {profile.role === 'admin' && <Shield size={12} fill="currentColor" />}
                           {profile.role === 'leader' && <Crown size={14} fill="currentColor" className="text-black" />}
                           {profile.role === 'admin' ? 'Administrador Supremo' : profile.role === 'leader' ? 'Líder de Tribo' : 'Guerreiro de Elite'}
                         </span>
                         
                         <div className="flex items-center gap-2 px-3 py-1.5 md:gap-3 md:px-5 md:py-2 bg-black/60 border-2 border-zinc-800 rounded-xl">
                            <Users size={12} className="text-primary" />
                            <span className="text-zinc-300 font-black uppercase italic text-[9px] md:text-[10px] tracking-widest">{groupName}</span>
                         </div>
                       </div>
                     </div>
                   )}
                </div>

                {/* Versículo Favorito / Status */}
                <div className="relative inline-block">
                  {isEditing ? (
                    <div className="space-y-2">
                      <p className="text-[9px] font-black uppercase text-primary tracking-[0.3em] ml-1">Assinatura de Guerra</p>
                      <input 
                        value={editForm.favorite_verse}
                        onChange={e => setEditForm({...editForm, favorite_verse: e.target.value})}
                        className="w-full md:min-w-[400px] bg-zinc-950 border-2 border-zinc-800 rounded-2xl px-6 py-3 text-zinc-300 text-sm font-bold italic outline-none focus:border-primary transition-all"
                        placeholder="Ex: Tudo posso naquele que me fortalece (Fl 4:13)"
                      />
                    </div>
                  ) : (
                    profile.favorite_verse && (
                      <div className="relative group/verse">
                        <div className="absolute -inset-2 bg-primary/5 blur-lg opacity-0 group-hover/verse:opacity-100 transition-all rounded-xl"></div>
                        <p className="text-primary font-black italic text-base md:text-2xl relative z-10 leading-tight">
                          <span className="opacity-40 text-4xl font-serif absolute -left-6 -top-2">"</span>
                          {profile.favorite_verse}
                          <span className="opacity-40 text-4xl font-serif absolute -right-6 -bottom-4">"</span>
                        </p>
                      </div>
                    )
                  )}
                </div>
              </div>

              {/* PROGRESS BAR (PREMIUM) */}
              <div className="bg-black/40 border border-zinc-800/80 p-5 rounded-4xl max-w-xl mx-auto md:mx-0 mt-6 relative overflow-hidden group">
                <div className="absolute inset-0 opacity-5 transition-all group-hover:opacity-10" style={{ background: `linear-gradient(to right, ${lvl.color}, transparent)` }}></div>
                
                <div className="relative z-10 flex items-center justify-between mb-3">
                   <div className="flex items-center gap-2">
                     <div className="p-1.5 rounded-lg bg-zinc-950 border border-zinc-800">
                        <LevelIcon name={lvl.icon} size={14} color={lvl.color} />
                     </div>
                     <p className="text-sm md:text-base font-black italic uppercase tracking-tighter" style={{ color: lvl.color }}>{lvl.title}</p>
                   </div>
                   <div className="text-right">
                     <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Nível {lvl.level}</p>
                   </div>
                </div>
                
                <div className="relative h-4 bg-zinc-950 rounded-full overflow-hidden border border-zinc-800/80 p-0.5">
                   <motion.div 
                     initial={{ width: 0 }}
                     animate={{ width: `${pct}%` }}
                     className="h-full rounded-full relative overflow-hidden"
                     style={{ backgroundColor: lvl.color, boxShadow: `0 0 20px ${lvl.color}66` }}
                   >
                     <div className="absolute inset-0 bg-linear-to-b from-white/30 to-transparent"></div>
                   </motion.div>
                </div>
                
                <div className="flex justify-between mt-2 text-[9px] font-black text-zinc-600 uppercase tracking-[0.2em]">
                   <span>{pct}% Concluído</span>
                   <span>Alvo: {lvl.maxPoints === Infinity ? 'MÁXIMO' : `${lvl.maxPoints} pts`}</span>
                </div>
              </div>
            </div>

            {/* STATS BENTO GRID */}
            <div className="grid grid-cols-2 gap-3 min-w-[240px] lg:min-w-[320px] w-full md:w-auto shrink-0 mt-8 md:mt-0">
               {/* Total XP - spans 2 columns */}
               <div className="col-span-2 bg-zinc-950/80 backdrop-blur-3xl border-2 border-zinc-800 p-6 rounded-4xl relative overflow-hidden group flex items-center justify-between hover:border-zinc-700 transition-colors">
                 <div className="absolute inset-0 opacity-10 blur-2xl transition-all group-hover:scale-110 group-hover:opacity-20" style={{ backgroundColor: lvl.color }}></div>
                 <div className="relative z-10">
                   <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-1">Poder Total</p>
                   <div className="flex items-baseline gap-1.5">
                     <motion.span initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-5xl md:text-6xl font-black text-white italic tracking-tighter">
                       {profile.totalPoints}
                     </motion.span>
                     <span className="text-primary font-black text-[10px] italic uppercase">xp</span>
                   </div>
                 </div>
                 <div className="relative z-10 w-12 h-12 rounded-full border-2 bg-black/40 flex items-center justify-center shadow-inner" style={{ borderColor: `${lvl.color}44` }}>
                    <Zap size={20} style={{ color: lvl.color }} className="opacity-80" />
                 </div>
               </div>
               
               {/* Moedas */}
               <div className="bg-black/60 border border-zinc-800 p-5 rounded-4xl flex flex-col items-center justify-center group hover:border-yellow-500/40 transition-colors">
                  <Coins size={18} className="text-yellow-500 mb-2 opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all drop-shadow-[0_0_10px_rgba(234,179,8,0.5)]" />
                  <span className="text-2xl font-black text-yellow-500 italic leading-none">{profile.coins || 0}</span>
                  <span className="text-[9px] font-black text-zinc-600 uppercase mt-1 tracking-widest">Moedas</span>
               </div>
               
               {/* Medalhas */}
               <div className="bg-black/60 border border-zinc-800 p-5 rounded-4xl flex flex-col items-center justify-center group hover:border-primary/40 transition-colors">
                  <Medal size={18} className="text-zinc-400 mb-2 opacity-80 group-hover:opacity-100 group-hover:scale-110 group-hover:text-primary transition-all" />
                  <span className="text-2xl font-black text-white italic leading-none">{achievements.length}</span>
                  <span className="text-[9px] font-black text-zinc-600 uppercase mt-1 tracking-widest">Medalhas</span>
               </div>
            </div>
          </div>
        </div>
      </div>

      {/* LOWER CONTENT */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-8">
        {/* CONQUISTAS (Left/Main) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-zinc-900/40 backdrop-blur-xl border border-zinc-800 rounded-[2.5rem] p-8 md:p-10 relative overflow-hidden group">
            {/* Ambient Light */}
            <div className="absolute -top-24 -left-24 w-48 h-48 bg-primary/5 blur-3xl group-hover:bg-primary/10 transition-all"></div>
            
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-10 relative z-10">
              <div className="flex items-center gap-4">
                 <div className="w-12 h-12 bg-primary/10 border border-primary/20 rounded-2xl flex items-center justify-center text-primary shadow-[0_0_15px_rgba(251,191,36,0.1)]">
                    <Medal size={24} />
                 </div>
                 <div>
                    <h3 className="text-2xl font-black uppercase italic tracking-tighter text-white leading-none">Galeria de Honra</h3>
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500 mt-1">Conquistas e Medalhas</p>
                 </div>
              </div>
              <div className="px-4 py-1.5 bg-black/40 border border-zinc-800 rounded-full text-[10px] font-black text-zinc-400 uppercase italic">
                {allRecognitionCount} Desbloqueadas
              </div>
            </div>

            <AchievementList achievements={achievements} userBadges={userBadges} />
          </div>
        </div>

        {/* DETAILS (Right) */}
        <div className="space-y-6">
           <div className="bg-zinc-900/40 backdrop-blur-xl border border-zinc-800 p-8 rounded-[2.5rem] relative overflow-hidden group">
              {/* Ambient Light */}
              <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-primary/5 blur-3xl group-hover:bg-primary/10 transition-all"></div>

              <div className="flex items-center gap-3 mb-8 relative z-10">
                 <div className="w-10 h-10 bg-primary/10 border border-primary/20 rounded-xl flex items-center justify-center text-primary">
                    <Zap size={20} />
                 </div>
                 <h3 className="text-xl font-black uppercase italic tracking-tighter text-white">Bio do Guerreiro</h3>
              </div>

              <div className="space-y-4 relative z-10">
                 {isEditing ? (
                   <div className="space-y-4">
                     <div className="bg-black/40 p-5 rounded-2xl border border-zinc-800 focus-within:border-primary transition-all shadow-inner">
                       <p className="text-[10px] font-black uppercase text-zinc-600 mb-2 tracking-widest">Sobre Você</p>
                       <textarea 
                         value={editForm.bio}
                         onChange={e => setEditForm({...editForm, bio: e.target.value})}
                         className="w-full bg-transparent text-white text-sm font-bold italic outline-none min-h-[120px] resize-none placeholder:text-zinc-800"
                         placeholder="Conte um pouco sobre sua caminhada na fé e na gincana..."
                       />
                     </div>
                     <div className="bg-black/40 p-5 rounded-2xl border border-zinc-800 focus-within:border-primary transition-all shadow-inner">
                       <p className="text-[10px] font-black uppercase text-zinc-600 mb-2 tracking-widest">WhatsApp de Contato</p>
                       <input 
                         value={editForm.whatsapp}
                         onChange={e => setEditForm({...editForm, whatsapp: e.target.value})}
                         className="w-full bg-transparent text-white text-sm font-bold italic outline-none"
                         placeholder="(00) 00000-0000"
                       />
                     </div>
                   </div>
                 ) : (
                   <>
                     {profile.bio ? (
                        <div className="bg-black/40 p-5 rounded-2xl border border-zinc-800 mb-4 shadow-inner">
                           <p className="text-zinc-300 text-sm italic leading-relaxed whitespace-pre-wrap">{profile.bio}</p>
                        </div>
                     ) : (
                        <div className="bg-black/10 p-5 rounded-2xl border border-dashed border-zinc-800 mb-4 text-center">
                           <p className="text-zinc-600 text-xs italic">Nenhuma biografia escrita ainda.</p>
                        </div>
                     )}
                      <div className="bg-zinc-950/50 p-4 rounded-2xl border border-zinc-800 flex items-center justify-between group/item hover:border-zinc-700 transition-all shadow-inner">
                         <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Cargo</p>
                         <p className={`font-black text-[10px] uppercase italic tracking-tighter px-3 py-1 rounded-lg border shadow-xs ${
                           profile.role === 'admin' 
                            ? 'bg-red-500/10 border-red-500/30 text-red-500 shadow-red-500/10' 
                            : profile.role === 'leader'
                            ? 'bg-primary/10 border-primary/30 text-primary shadow-primary/10'
                            : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                         }`}>
                           {profile.role === 'admin' ? 'Admin Supremo' : profile.role === 'leader' ? 'Líder de Tribo' : 'Guerreiro'}
                         </p>
                      </div>
                   </>
                 )}
                 {profile.wantsToServe && !isEditing && (
                   <div className="bg-black/40 p-4 rounded-2xl border border-zinc-800 flex items-center justify-between">
                      <p className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">Serviço</p>
                      <p className="text-primary font-black text-[10px] uppercase italic tracking-tighter">{profile.serviceArea || 'Disponível'}</p>
                   </div>
                 )}
                 {!isEditing && (
                   <div className="bg-zinc-950/50 p-4 rounded-2xl border border-zinc-800 flex items-center justify-between text-zinc-500 shadow-inner">
                      <p className="text-[10px] font-black uppercase tracking-widest">Sincronia</p>
                      <div className="flex items-center gap-2 text-[10px] font-bold">
                         <Calendar size={10} /> {new Date().toLocaleDateString('pt-BR')}
                      </div>
                   </div>
                 )}
              </div>
            {/* CALL TO ACTION */}
            <button 
              type="button"
              onClick={() => {
                setShowChallengeMsg(true);
                setTimeout(() => setShowChallengeMsg(false), 3000);
              }}
              className="w-full bg-linear-to-br from-yellow-400 to-yellow-600 p-8 rounded-[2.5rem] text-black group cursor-pointer hover:scale-[1.02] active:scale-95 transition-all overflow-hidden relative shadow-[0_20px_40px_rgba(251,191,36,0.2)] border-t border-white/20 mt-6 text-left"
            >
               <div className="absolute inset-0 bg-linear-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:animate-sweep transition-all duration-1000 pointer-events-none"></div>
               <div className="relative z-10">
                 <h4 className="text-2xl font-black uppercase italic tracking-tighter leading-none mb-2 drop-shadow-sm">
                   {showChallengeMsg ? 'MODO ARENA' : 'Desafiar Membro'}
                 </h4>
                 <p className="text-xs font-bold italic text-black/70 mb-6 max-w-[200px]">
                   {showChallengeMsg ? 'FUNCIONALIDADE SENDO PREPARADA...' : 'Envie um desafio direto e ganhe bônus de engajamento!'}
                 </p>
                 <div className="w-12 h-12 bg-black rounded-2xl flex items-center justify-center text-white shadow-xl group-hover:rotate-12 transition-transform">
                   {showChallengeMsg ? <Loader2 size={24} className="animate-spin text-yellow-400" /> : <Zap size={24} fill="currentColor" className="animate-pulse text-yellow-400" />}
                 </div>
               </div>
               <Shield size={140} className="absolute -right-6 -bottom-6 text-black/10 -rotate-12 group-hover:rotate-0 group-hover:scale-110 transition-all duration-700 pointer-events-none" />
            </button>
           </div>
        </div>
      </div>

      {/* MASTER ADMIN PANEL */}
      {profile.role === 'admin' && (
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-12 bg-zinc-950 border-4 border-red-500/20 rounded-[3rem] p-8 md:p-12 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <Shield size={200} className="text-red-500" />
          </div>

          <div className="relative z-10">
            <div className="flex items-center gap-4 mb-10">
               <div className="w-14 h-14 bg-red-500/10 border border-red-500/30 rounded-2xl flex items-center justify-center text-red-500 shadow-[0_0_20px_rgba(239,68,68,0.2)]">
                  <Settings size={28} className="animate-spin-slow" />
               </div>
               <div>
                  <h3 className="text-3xl font-black uppercase italic tracking-tighter leading-none text-red-500">Painel de Comando Supremo</h3>
                  <p className="text-xs font-bold text-zinc-500 uppercase italic tracking-widest mt-1">Configurações globais da Arena e Economia</p>
               </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               {/* Gerenciar Loja */}
               <button 
                 type="button"
                 onClick={() => navigate('/dashboard/admin/store')}
                 className="flex flex-col items-center p-8 bg-zinc-900 border-2 border-zinc-800 rounded-[2.5rem] hover:border-yellow-500/50 group transition-all active:scale-95"
               >
                  <ShoppingBag size={32} className="text-zinc-600 group-hover:text-yellow-500 mb-4 transition-colors" />
                  <span className="font-black uppercase italic text-sm text-zinc-400 group-hover:text-white">Loja de Recompensas</span>
                  <p className="text-[10px] text-zinc-600 uppercase font-bold mt-2">Configurar Itens e Preços</p>
               </button>

               {/* Gerenciar Usuários */}
               <button 
                 type="button"
                 onClick={() => navigate('/dashboard/admin/users')}
                 className="flex flex-col items-center p-8 bg-zinc-900 border-2 border-zinc-800 rounded-[2.5rem] hover:border-blue-500/50 group transition-all active:scale-95"
               >
                  <div className="relative mb-4">
                    <Users size={32} className="text-zinc-600 group-hover:text-blue-500 transition-colors" />
                  </div>
                  <span className="font-black uppercase italic text-sm text-zinc-400 group-hover:text-white">Base de Guerreiros</span>
                  <p className="text-[10px] text-zinc-600 uppercase font-bold mt-2">Editar Perfis e Moedas</p>
               </button>

               {/* Gerenciar Pontos */}
               <button 
                 type="button"
                 onClick={() => navigate('/dashboard/admin/tasks')}
                 className="flex flex-col items-center p-8 bg-zinc-900 border-2 border-zinc-800 rounded-[2.5rem] hover:border-emerald-500/50 group transition-all active:scale-95"
               >
                  <Zap size={32} className="text-zinc-600 group-hover:text-emerald-500 mb-4 transition-colors" />
                  <span className="font-black uppercase italic text-sm text-zinc-400 group-hover:text-white">Tabela de Pontos</span>
                  <p className="text-[10px] text-zinc-600 uppercase font-bold mt-2">Ajustar XP e Atividades</p>
               </button>

               {/* Recompensa Especial (NOVO) */}
               <button 
                 type="button"
                 onClick={() => setShowRewardModal(true)}
                 className="flex flex-col items-center p-8 bg-zinc-900 border-2 border-zinc-800 rounded-[2.5rem] hover:border-pink-500/50 group transition-all active:scale-95 md:col-span-3"
               >
                  <Gift size={32} className="text-zinc-600 group-hover:text-pink-500 mb-4 transition-colors animate-bounce" />
                  <span className="font-black uppercase italic text-sm text-zinc-400 group-hover:text-white">Recompensa Especial de Moedas</span>
                  <p className="text-[10px] text-zinc-600 uppercase font-bold mt-2">Dar Moedas Extras ao Guerreiro Atual</p>
               </button>

               {/* Gerar Convite Admin (NOVO) */}
               <button 
                 type="button"
                 onClick={handleCopyAdminInvite}
                 className={`w-full flex flex-col items-center p-8 border-2 rounded-[2.5rem] transition-all md:col-span-3 shadow-xl active:scale-95 ${
                   copied ? 'bg-emerald-500/20 border-emerald-500' : 'bg-zinc-900 border-zinc-800 hover:border-red-500/50'
                 }`}
               >
                  <Link size={32} className={copied ? 'text-emerald-500' : 'text-zinc-600 group-hover:text-red-500 mb-4 transition-colors'} />
                  <span className={`font-black uppercase italic text-sm ${copied ? 'text-emerald-500' : 'text-zinc-400 group-hover:text-white'}`}>
                    {copied ? 'LINK COPIADO COM SUCESSO!' : 'Gerar Convite Admin'}
                  </span>
                  <p className="text-[10px] text-zinc-600 uppercase font-bold mt-2">
                    {copied ? 'Pronto para enviar aos novos mestres' : 'Copiar link de cadastro para novos Administradores'}
                  </p>
               </button>
            </div>

            <div className="bg-black/40 border border-red-500/10 p-6 rounded-3xl flex items-center justify-between mt-8">
               <div className="flex items-center gap-3">
                 <Shield className="text-blue-500" size={20} />
                 <div>
                   <p className="text-[10px] font-black uppercase text-zinc-600">Segurança de Dados</p>
                   <p className="text-white font-black italic uppercase text-xs">Proteção RLS Ativada</p>
                 </div>
               </div>
               <div className="bg-blue-500/10 text-blue-500 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter">Fail-Safe</div>
            </div>
          </div>
        </motion.div>
      )}

      {/* MODAL DE RECOMPENSA ESPECIAL */}
      <AnimatePresence>
        {showRewardModal && (
          <div className="fixed inset-0 z-100 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowRewardModal(false)}
              className="absolute inset-0 bg-black/95 backdrop-blur-md"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 40 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 40 }}
              className="relative w-full max-w-lg bg-zinc-900 border-4 border-red-500/30 p-8 rounded-[3rem] shadow-2xl"
            >
              <div className="text-center space-y-6">
                <div className="w-24 h-24 bg-pink-500/10 rounded-full flex items-center justify-center mx-auto border-4 border-pink-500/20">
                   <Gift size={48} className="text-pink-500 animate-bounce" />
                </div>
                
                <div>
                   <h3 className="text-3xl font-black uppercase italic text-white leading-none">Recompensa Extra</h3>
                   <p className="text-zinc-500 font-bold italic mt-2 uppercase text-[10px] tracking-widest">Premiar o Guerreiro: {profile?.name}</p>
                </div>

                <div className="space-y-4">
                  <div className="bg-black/60 p-5 rounded-3xl border border-zinc-800">
                    <p className="text-[10px] font-black uppercase text-zinc-500 mb-2 tracking-widest">Quantidade de Moedas</p>
                    <div className="flex items-center gap-4">
                      <Coins className="text-yellow-500" size={24} />
                      <input 
                        type="number"
                        value={rewardAmount}
                        onChange={e => setRewardAmount(parseInt(e.target.value) || 0)}
                        className="w-full bg-transparent text-4xl font-black italic text-white outline-none"
                      />
                    </div>
                  </div>

                  <div className="bg-black/60 p-5 rounded-3xl border border-zinc-800">
                    <p className="text-[10px] font-black uppercase text-zinc-500 mb-2 tracking-widest">Motivo da Honra</p>
                    <textarea 
                      value={rewardReason}
                      onChange={e => setRewardReason(e.target.value)}
                      placeholder="Ex: Venceu o desafio relâmpago!"
                      className="w-full bg-transparent text-sm font-bold italic text-zinc-300 outline-none resize-none h-20"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                   <button
                     onClick={() => setShowRewardModal(false)}
                     className="bg-zinc-800 text-white py-4 rounded-2xl font-black uppercase italic tracking-tighter"
                   >
                     CANCELAR
                   </button>
                   <button
                     onClick={handleGiveReward}
                     disabled={rewarding || rewardAmount <= 0}
                     className="bg-pink-500 text-white py-4 rounded-2xl font-black uppercase italic tracking-tighter active:scale-95 transition-all disabled:opacity-50 shadow-[0_10px_20px_rgba(236,72,153,0.3)] flex items-center justify-center gap-2"
                   >
                     {rewarding ? <Loader2 size={20} className="animate-spin" /> : null}
                     {rewarding ? 'ENVIANDO...' : 'DAR RECOMPENSA'}
                   </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
    </>
  );
}
