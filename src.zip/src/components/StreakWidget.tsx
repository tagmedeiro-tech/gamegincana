import React from 'react';
import { motion } from 'motion/react';
import { Zap, Flame, Trophy, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/useAuth';
import { ACHIEVEMENT_DEFINITIONS } from '../lib/AchievementService';

const LOGIN_MILESTONES = [3, 7, 14, 30, 60, 100, 365];
const DEVOTIONAL_MILESTONES = [7, 14, 30, 60];

const getStreakColor = (days: number) => {
  if (days >= 60) return 'text-purple-500 shadow-[0_0_15px_rgba(168,85,247,0.4)] animate-pulse';
  if (days >= 30) return 'text-red-500';
  if (days >= 14) return 'text-orange-500';
  if (days >= 7) return 'text-primary';
  return 'text-white';
};

const getNextMilestone = (current: number, milestones: number[]) => {
  return milestones.find(m => m > current) || milestones[milestones.length - 1];
};

export default function StreakWidget() {
  const { profile } = useAuth();

  if (!profile) return null;

  const streakLogin = (profile as any).streakLogin || 0;
  const streakDevotional = (profile as any).streakDevotional || 0;

  const nextLogin = getNextMilestone(streakLogin, LOGIN_MILESTONES);
  const nextDev = getNextMilestone(streakDevotional, DEVOTIONAL_MILESTONES);

  const loginPct = Math.min(100, (streakLogin / nextLogin) * 100);
  const devPct = Math.min(100, (streakDevotional / nextDev) * 100);

  // Buscar troféus de ofensiva já conquistados (simplificado por prefixo da chave)
  const userAchievements = (profile as any).user_achievements || [];
  const streakTrophies = userAchievements
    .map((ua: any) => ACHIEVEMENT_DEFINITIONS[ua.achievementKey])
    .filter((def: any) => def && (def.name.includes('Ofensiva') || def.name.includes('Streak') || def.name.includes('Chama') || def.name.includes('Fiel') || def.name.includes('Discípulo') || def.name.includes('Guardião') || def.name.includes('Faísca')));

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-zinc-900 border-4 border-zinc-800 rounded-[3rem] overflow-hidden group hover:border-zinc-700 transition-all relative shadow-2xl"
    >
      {/* Decorative background glow */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2 pointer-events-none" />
      
      <div className="p-6 md:p-8 space-y-8 relative z-10">
        {/* Header Unificado */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-black rounded-2xl flex items-center justify-center border-2 border-zinc-800 shadow-inner">
                <Flame size={18} className="text-primary animate-pulse" />
             </div>
             <div>
               <p className="text-[9px] font-black uppercase text-zinc-500 tracking-[0.3em] leading-none mb-1">Estatísticas de</p>
               <h3 className="text-2xl font-black italic text-white uppercase leading-none tracking-tighter">Ofensivas</h3>
             </div>
          </div>
          {/* Trophy count summary */}
          {streakTrophies.length > 0 && (
             <div className="flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-xl border border-zinc-800">
               <Trophy size={12} className="text-primary" />
               <span className="text-[10px] font-black text-white uppercase tracking-widest">{streakTrophies.length} Troféus</span>
             </div>
          )}
        </div>

        {/* Unified metrics layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-10 relative">
          {/* Divider visible only on md+ */}
          <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-[2px] bg-linear-to-b from-transparent via-zinc-800 to-transparent -translate-x-1/2" />

          {/* Login Streak */}
          <div className="space-y-5">
             <div className="flex justify-between items-start">
               <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <Zap size={14} className="text-primary" />
                    <p className="text-[9px] font-black uppercase text-zinc-500 tracking-widest">Login Semanal</p>
                  </div>
                  <p className="text-base font-black text-zinc-300 uppercase italic leading-none">Presença</p>
               </div>
               <div className="flex flex-col items-end">
                  <span className={`text-5xl font-black italic tracking-tighter leading-none ${getStreakColor(streakLogin)}`}>{streakLogin}</span>
                  <span className="text-[10px] font-black text-zinc-600 uppercase mt-1 italic">Dias Seguidos</span>
               </div>
             </div>
             <div className="space-y-1.5">
               <div className="flex justify-between items-center">
                 <span className="text-[9px] font-black uppercase text-zinc-400 tracking-widest">Meta: {nextLogin} dias</span>
                 <span className="text-[9px] font-black uppercase text-primary tracking-widest">{Math.round(loginPct)}%</span>
               </div>
               <div className="h-1.5 bg-black rounded-full overflow-hidden border border-zinc-800">
                  <motion.div 
                    initial={{ width: 0 }} animate={{ width: `${loginPct}%` }}
                    className="h-full bg-primary shadow-[0_0_10px_rgba(251,191,36,0.5)] rounded-full"
                  />
               </div>
             </div>
          </div>

          {/* Devotional Streak */}
          <div className="space-y-5">
             <div className="flex justify-between items-start">
               <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <Flame size={14} className="text-orange-500" />
                    <p className="text-[9px] font-black uppercase text-zinc-500 tracking-widest">Leitura Bíblica</p>
                  </div>
                  <p className="text-base font-black text-zinc-300 uppercase italic leading-none">Devocional</p>
               </div>
               <div className="flex flex-col items-end">
                  <span className={`text-5xl font-black italic tracking-tighter leading-none ${getStreakColor(streakDevotional)}`}>{streakDevotional}</span>
                  <span className="text-[10px] font-black text-zinc-600 uppercase mt-1 italic">Dias Seguidos</span>
               </div>
             </div>
             <div className="space-y-1.5">
               <div className="flex justify-between items-center">
                 <span className="text-[9px] font-black uppercase text-zinc-400 tracking-widest">Meta: {nextDev} dias</span>
                 <span className="text-[9px] font-black uppercase text-orange-500 tracking-widest">{Math.round(devPct)}%</span>
               </div>
               <div className="h-1.5 bg-black rounded-full overflow-hidden border border-zinc-800">
                  <motion.div 
                    initial={{ width: 0 }} animate={{ width: `${devPct}%` }}
                    className="h-full bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.5)] rounded-full"
                  />
               </div>
             </div>
          </div>

        </div>

        {/* 🏆 TROFÉUS CONQUISTADOS (SE HOUVER) */}
        {streakTrophies.length > 0 && (
          <div className="pt-4 border-t-2 border-zinc-800/50 flex flex-wrap gap-2 items-center">
            <span className="text-[9px] font-black text-zinc-600 uppercase tracking-widest mr-2 flex items-center gap-1.5">
              <Trophy size={12} className="text-primary/50" /> Suas Conquistas:
            </span>
            {streakTrophies.slice(0, 4).map((trophy: any, i: number) => (
              <div 
                key={i} 
                className="px-2.5 py-1 bg-black/50 border border-zinc-800 rounded-lg flex items-center gap-1.5 hover:border-primary/50 transition-colors"
                title={trophy.description}
              >
                <span className="text-[10px]">{trophy.name.split(' ').pop()}</span>
                <span className="text-[9px] font-black uppercase text-zinc-400">{trophy.name.split(' ').slice(0, -1).join(' ')}</span>
              </div>
            ))}
            {streakTrophies.length > 4 && (
              <span className="text-[9px] font-black text-zinc-500 ml-1">+{streakTrophies.length - 4}</span>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}
