import React from 'react';
import { motion } from 'motion/react';
import { Trophy, Shield, Star, Zap, ChevronRight, Lock } from 'lucide-react';
import { useAppTheme } from '../hooks/useAppTheme';
import LevelIcon from './LevelIcon';

export default function LevelTable() {
  const theme = useAppTheme();
  const levels = [...(theme.levels || [])].sort((a, b) => b.level - a.level); // Mostrar do maior pro menor

  return (
    <div className="relative">
      {/* Vertical Connection Line */}
      <div className="absolute left-10 top-20 bottom-10 w-0.5 bg-linear-to-b from-primary via-zinc-800 to-zinc-900 hidden md:block" />

      <div className="flex items-center gap-3 mb-10 px-2">
        <div className="p-2 bg-primary/10 rounded-lg border border-primary/20">
          <Shield className="text-primary" size={20} />
        </div>
        <h3 className="text-xl font-black uppercase italic text-white tracking-tight">
          Caminho de <span className="text-primary">Evolução</span>
        </h3>
      </div>

      <div className="space-y-4 max-h-[400px] md:max-h-[500px] overflow-y-auto pr-4 custom-scrollbar">
        {levels.map((lvl, index) => (
          <motion.div
            key={lvl.level}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="relative group pl-2"
          >
            {/* Connector Dot */}
            <div className="absolute left-8 top-1/2 -translate-y-1/2 w-4 h-4 bg-zinc-900 border-2 border-zinc-800 rounded-full group-hover:border-primary transition-colors hidden md:block z-10" />

            <div className="bg-zinc-900/40 backdrop-blur-md border-2 border-zinc-800/50 p-4 rounded-3xl flex items-center justify-between hover:border-primary/40 transition-all group-hover:translate-x-1">
              <div className="flex items-center gap-4">
                {/* Level Badge */}
                <div 
                  className="w-14 h-14 rounded-2xl flex items-center justify-center border-2 shadow-glow-primary shrink-0 relative overflow-hidden"
                  style={{ backgroundColor: `${lvl.color}10`, borderColor: lvl.color, color: lvl.color }}
                >
                  <div className="absolute inset-0 bg-linear-to-br from-white/10 to-transparent pointer-events-none" />
                  <div className="flex flex-col items-center">
                    <LevelIcon name={lvl.icon} size={22} color={lvl.color} />
                    <span className="text-[9px] font-black italic -mt-1 uppercase tracking-tighter">LVL {lvl.level}</span>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-white font-black uppercase italic text-sm group-hover:text-primary transition-colors leading-none mb-1">
                    {lvl.title}
                  </h4>
                  <div className="flex items-center gap-2 text-[9px] font-bold text-zinc-500 uppercase tracking-widest mt-1">
                    <div className="flex items-center gap-1 bg-black/40 px-2 py-1 rounded-md border border-zinc-800 whitespace-nowrap shadow-inner">
                      <Zap size={10} className="text-primary" fill="currentColor" />
                      <span>{lvl.minPoints} {!lvl.maxPoints || lvl.maxPoints === Infinity ? '+' : `- ${lvl.maxPoints}`} pts</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                 {index === 0 ? (
                    <div className="px-2 py-1 bg-primary/20 border border-primary/30 rounded-md">
                       <span className="text-[8px] font-black uppercase text-primary tracking-widest">Master</span>
                    </div>
                 ) : (
                    <Lock size={14} className="text-zinc-700 group-hover:text-zinc-500 transition-colors" />
                 )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Info Tip Footer */}
      <div className="mt-8 p-4 bg-primary/5 border border-primary/10 rounded-2xl relative overflow-hidden group">
         <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
            <Trophy size={40} className="text-primary" />
         </div>
         <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest leading-relaxed relative z-10">
            <span className="text-primary">Evolução Tática:</span> Cada nível desbloqueia multiplicadores de moedas e prestígio no Mural da Tribo.
         </p>
      </div>
    </div>
  );
}

