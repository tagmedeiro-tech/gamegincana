/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'admin' | 'leader' | 'participant';

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  criteria: 'visitor' | 'count' | 'attendance';
  unlockedAt: string;
}

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  groupId?: string;
  photoURL?: string;
  totalPoints: number;
  achievements: Achievement[];
}

export interface Group {
  id: string;
  name: string;
  leaderId: string;
  color: string;
  totalPoints: number;
  memberCount: number;
}

export interface Activity {
  id: string;
  title: string;
  description: string;
  points: number;
  type: 'presencial' | 'online';
  expiryDate?: string;
  status: 'active' | 'archived';
  validationType: 'auto' | 'manual';
}

export interface Participation {
  id: string;
  userId: string;
  groupId: string;
  activityId: string;
  status: 'pending' | 'approved' | 'rejected';
  pointsEarned: number;
  timestamp: any;
  proofUrl?: string; // For photos/proofs
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: any;
  groupId: string;
}

export interface PointLog {
  id: string;
  groupId: string;
  userId: string;
  points: number;
  reason: string;
  timestamp: any;
}
