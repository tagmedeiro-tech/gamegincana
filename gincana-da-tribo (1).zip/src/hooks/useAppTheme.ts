/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export interface AppTheme {
  primaryColor: string;
  appName: string;
  churchName: string;
  logoType: string;
}

export function useAppTheme() {
  const [theme, setTheme] = useState<AppTheme>({
    primaryColor: '#FBBF24',
    appName: 'TRIBO IDE',
    churchName: 'Igreja do Evangelho',
    logoType: 'landmark'
  });

  const applyTheme = (data: AppTheme) => {
    setTheme(data);
    document.documentElement.style.setProperty('--color-primary', data.primaryColor);
    const darkPrimary = shadeColor(data.primaryColor, -20);
    document.documentElement.style.setProperty('--color-primary-dark', darkPrimary);
  };

  useEffect(() => {
    const fetchTheme = async () => {
      const { data, error } = await supabase
        .from('config')
        .select('value')
        .eq('key', 'app')
        .single();
      
      if (data?.value && !error) {
        applyTheme(data.value as AppTheme);
      }
    };

    fetchTheme();

    const channel = supabase
      .channel('public:config')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'config', filter: 'key=eq.app' }, (payload) => {
        if (payload.new && (payload.new as any).value) {
          applyTheme((payload.new as any).value as AppTheme);
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return theme;
}

// Helper to darken colors for primary-dark
function shadeColor(color: string, percent: number) {
    let R = parseInt(color.substring(1,3), 16);
    let G = parseInt(color.substring(3,5), 16);
    let B = parseInt(color.substring(5,7), 16);

    R = Math.floor(R * (100 + percent) / 100);
    G = Math.floor(G * (100 + percent) / 100);
    B = Math.floor(B * (100 + percent) / 100);

    R = (R<255)?R:255;  
    G = (G<255)?G:255;  
    B = (B<255)?B:255;  

    const RR = ((R.toString(16).length===1)?"0"+R.toString(16):R.toString(16));
    const GG = ((G.toString(16).length===1)?"0"+G.toString(16):G.toString(16));
    const BB = ((B.toString(16).length===1)?"0"+B.toString(16):B.toString(16));

    return "#"+RR+GG+BB;
}
