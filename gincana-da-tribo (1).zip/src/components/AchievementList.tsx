/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { Award, Zap, Users, ShieldCheck } from 'lucide-react';
import { Achievement } from '../types';

const achievementIcons = {
  visitor: Users,
  count: Zap,
  attendance: ShieldCheck,
};

export const MOCK_ACHIEVEMENTS: Achievement[] = [
  {
    id: '1',
    title: 'Evangelista da Semana',
    description: 'Trouxe um novo visitante para o culto jovem.',
    icon: 'visitor',
    criteria: 'visitor',
    unlockedAt: new Date().toISOString(),
  },
  {
    id: '2',
    title: 'Mais Ativo',
    description: 'Completou mais de 10 atividades na temporada atual.',
    icon: 'count',
    criteria: 'count',
    unlockedAt: new Date().toISOString(),
  },
  {
    id: '3',
    title: 'Top Presença',
    description: '100% de presença nos cultos do último mês.',
    icon: 'attendance',
    criteria: 'attendance',
    unlockedAt: new Date().toISOString(),
  },
];

export default function AchievementList({ achievements = MOCK_ACHIEVEMENTS }) {
  return (
    <div className="space-y-4">
      {achievements.map((achievement, i) => {
        const Icon = achievementIcons[achievement.criteria as keyof typeof achievementIcons] || Award;
        return (
          <motion.div
            key={achievement.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="flex items-center gap-4 p-4 bg-primary text-white rounded-2xl border-2 border-accent hover:scale-[1.02] transition-transform shadow-lg"
          >
            <div className="w-12 h-12 bg-accent rounded-xl flex items-center justify-center text-primary shrink-0">
              <Icon size={24} />
            </div>
            <div>
              <h4 className="font-black italic uppercase tracking-tighter text-accent leading-none mb-1">
                {achievement.title}
              </h4>
              <p className="text-[10px] font-bold opacity-80 uppercase leading-snug">
                {achievement.description}
              </p>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
