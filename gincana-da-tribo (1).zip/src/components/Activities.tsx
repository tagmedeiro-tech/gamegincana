/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CheckCircle2, MapPin, Globe } from 'lucide-react';
import { motion } from 'motion/react';
import { supabase } from '../lib/supabase';
import { Activity } from '../types';

export default function Activities() {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchActivities = async () => {
      const { data, error } = await supabase
        .from('activities')
        .select('*')
        .eq('status', 'active');
      
      if (!error) {
        setActivities(data as Activity[]);
      }
      setLoading(false);
    };

    fetchActivities();
  }, []);

  const handleComplete = (title: string) => {
    alert(`Parabéns! Você completou: ${title}. Pontos e conquistas serão validados pelo seu líder.`);
  };

  if (loading) return <div className="flex justify-center p-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;

  return (
    <div className="space-y-6">
      <header>
        <h2 className="text-3xl font-black text-white tracking-tight">Desafios Disponíveis ⚡</h2>
        <p className="text-zinc-500 font-medium">Cumpra as tarefas e suba no ranking da sua tribo.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {activities.map((activity, i) => (
          <motion.div
            key={activity.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className="card-bold group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-[10px] font-black tracking-[0.2em] uppercase py-1 px-4 bg-primary text-black rounded-full">
                  {activity.category}
                </span>
                <span className="text-primary font-black text-2xl uppercase italic">
                  +{activity.points} <span className="text-xs">pts</span>
                </span>
              </div>
              <h3 className="text-2xl font-black text-white mb-3 leading-none uppercase group-hover:text-primary transition-all">
                {activity.title}
              </h3>
              <p className="text-zinc-500 font-medium italic mb-6">
                {activity.description}
              </p>
            </div>

            <div className="flex items-center justify-between mt-auto pt-6 border-t-2 border-zinc-800">
              <div className="flex items-center gap-2 text-zinc-600 text-[10px] font-black uppercase tracking-widest">
                {activity.type === 'presencial' ? (
                  <><MapPin size={14} className="text-primary" /> Presencial</>
                ) : (
                  <><Globe size={14} className="text-blue-600" /> Online</>
                )}
              </div>
              <button 
                onClick={() => handleComplete(activity.title)}
                className="flex items-center gap-2 bg-primary text-black py-2 px-6 rounded-full font-black text-xs uppercase tracking-tighter hover:scale-105 transition-all shadow-[0_0_10px_rgba(251,191,36,0.2)]"
              >
                CONCLUIR <CheckCircle2 size={16} />
              </button>

            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
