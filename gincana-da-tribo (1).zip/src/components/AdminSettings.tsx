/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Settings, Save, Palette, Type, Landmark, Check } from 'lucide-react';
import { motion } from 'motion/react';

export default function AdminSettings() {
  const [config, setConfig] = useState({
    primaryColor: '#FBBF24',
    appName: 'TRIBO IDE',
    churchName: 'Igreja do Evangelho',
    logoType: 'landmark'
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const fetchConfig = async () => {
      const { data, error } = await supabase
        .from('config')
        .select('value')
        .eq('key', 'app')
        .single();
      
      if (data?.value && !error) {
        setConfig(data.value as any);
      }
      setLoading(false);
    };

    fetchConfig();

    const channel = supabase
      .channel('public:config')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'config', filter: 'key=eq.app' }, (payload) => {
        if (payload.new && (payload.new as any).value) {
          setConfig((payload.new as any).value as any);
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { error } = await supabase
        .from('config')
        .upsert([{ key: 'app', value: config }]);
      
      if (error) throw error;
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (error) {
      alert("Erro ao salvar configurações");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="flex justify-center p-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;

  return (
    <div className="max-w-4xl space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black uppercase italic tracking-tighter text-primary">Configurações do App</h2>
          <p className="text-zinc-500 font-bold italic">Personalize as cores e a identidade da gincana</p>
        </div>
        <div className="bg-primary/10 p-3 rounded-xl border-2 border-primary/20 text-primary">
          <Settings size={32} />
        </div>
      </header>

      <form onSubmit={handleSave} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Identity Section */}
          <div className="card-bold bg-zinc-900 border-primary space-y-6">
            <div className="flex items-center gap-2 mb-4">
              <Type className="text-primary" size={20} />
              <h3 className="font-black uppercase italic tracking-tighter text-white">Identidade Visual</h3>
            </div>
            
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Nome do Aplicativo</label>
              <input 
                type="text"
                value={config.appName}
                onChange={e => setConfig({...config, appName: e.target.value})}
                className="w-full bg-black border-2 border-zinc-800 focus:border-primary p-3 rounded-xl text-white font-bold outline-none"
              />
            </div>

            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Nome da Igreja / Instituição</label>
              <input 
                type="text"
                value={config.churchName}
                onChange={e => setConfig({...config, churchName: e.target.value})}
                className="w-full bg-black border-2 border-zinc-800 focus:border-primary p-3 rounded-xl text-white font-bold outline-none"
              />
            </div>
          </div>

          {/* Style Section */}
          <div className="card-bold bg-zinc-900 border-primary space-y-6">
            <div className="flex items-center gap-2 mb-4">
              <Palette className="text-primary" size={20} />
              <h3 className="font-black uppercase italic tracking-tighter text-white">Estilização</h3>
            </div>

            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Cor Primária (Hex)</label>
              <div className="flex gap-4 items-center">
                <input 
                  type="color"
                  value={config.primaryColor}
                  onChange={e => setConfig({...config, primaryColor: e.target.value})}
                  className="w-16 h-16 bg-transparent border-none cursor-pointer rounded-lg overflow-hidden"
                />
                <input 
                  type="text"
                  value={config.primaryColor}
                  onChange={e => setConfig({...config, primaryColor: e.target.value})}
                  className="flex-1 bg-black border-2 border-zinc-800 focus:border-primary p-3 rounded-xl text-white font-mono font-bold outline-none uppercase"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Tema do Logo</label>
              <div className="grid grid-cols-2 gap-3">
                {['landmark', 'shield', 'trophy', 'cross'].map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setConfig({...config, logoType: type})}
                    className={`p-3 rounded-xl border-2 flex flex-col items-center gap-2 font-black uppercase text-[10px] tracking-widest transition-all ${
                      config.logoType === type ? 'border-primary bg-primary text-black' : 'border-zinc-800 bg-black text-zinc-500'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <button 
          type="submit" 
          disabled={saving}
          className={`w-full py-5 rounded-2xl font-black uppercase italic tracking-tighter text-2xl flex items-center justify-center gap-3 transition-all ${
            success ? 'bg-green-600 text-white shadow-[0_0_30px_rgba(22,163,74,0.4)]' : 'bg-primary text-black hover:scale-[1.02]'
          }`}
        >
          {saving ? "SALVANDO..." : success ? <><Check size={28} /> CONFIGURAÇÕES SALVAS!</> : <><Save size={28} /> APLICAR ALTERAÇÕES</>}
        </button>
      </form>

      <div className="p-8 bg-zinc-900 border-4 border-dashed border-zinc-800 rounded-3xl text-center">
        <p className="text-zinc-500 font-bold italic mb-4">Pré-visualização do Tema</p>
        <div className="flex justify-center flex-wrap gap-6">
          <div className="w-20 h-20 rounded-2xl flex items-center justify-center shadow-lg" style={{ backgroundColor: config.primaryColor }}>
             <Landmark size={32} className="text-black" />
          </div>
          <div className="flex flex-col items-start justify-center">
             <h4 className="text-2xl font-black italic tracking-tighter uppercase leading-none" style={{ color: 'white' }}>
               {config.appName.split(' ')[0]}<span style={{ color: config.primaryColor }}>{config.appName.split(' ')[1] || ''}</span>
             </h4>
             <p className="text-[8px] font-black tracking-[0.4em] text-zinc-500 uppercase mt-2">{config.churchName}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
