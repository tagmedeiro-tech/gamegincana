/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { UserProfile, Group } from '../types';
import { UserCog, Trash2 } from 'lucide-react';

export default function AdminUsers() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: usersData, error: usersError } = await supabase
        .from('profiles')
        .select('*');
      
      const { data: groupsData, error: groupsError } = await supabase
        .from('groups')
        .select('*');
      
      if (!usersError) setUsers(usersData.map(u => ({ uid: u.id, ...u }) as UserProfile));
      if (!groupsError) setGroups(groupsData as Group[]);
    } catch (error) {
      console.error("Error fetching admin data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateRole = async (userId: string, newRole: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ role: newRole })
        .eq('id', userId);
      
      if (error) throw error;
      setUsers(users.map(u => u.uid === userId ? { ...u, role: newRole as any } : u));
    } catch (error) {
      alert("Erro ao atualizar cargo");
    }
  };

  const handleUpdateGroup = async (userId: string, groupId: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ groupId })
        .eq('id', userId);
      
      if (error) throw error;
      setUsers(users.map(u => u.uid === userId ? { ...u, groupId } : u));
    } catch (error) {
      alert("Erro ao atualizar grupo");
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm("Tem certeza que deseja excluir este usuário?")) return;
    try {
      const { error } = await supabase
        .from('profiles')
        .delete()
        .eq('id', userId);
      
      if (error) throw error;
      setUsers(users.filter(u => u.uid !== userId));
    } catch (error) {
      alert("Erro ao excluir usuário");
    }
  };

  if (loading) return <div className="flex justify-center p-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-black uppercase italic tracking-tighter text-primary">Gerenciar Membros</h2>
          <p className="text-zinc-500 font-bold italic">Total: {users.length} guerreiros cadastrados</p>
        </div>
        <div className="bg-primary/10 p-3 rounded-xl border-2 border-primary/20">
          <UserCog className="text-primary" size={32} />
        </div>
      </header>

      <div className="overflow-x-auto">
        <table className="w-full border-separate border-spacing-y-4">
          <thead>
            <tr className="text-zinc-500 text-[10px] font-black uppercase tracking-widest text-left">
              <th className="px-6 py-2">Membro</th>
              <th className="px-6 py-2">Cargo</th>
              <th className="px-6 py-2">Tribo</th>
              <th className="px-6 py-2">Pontos</th>
              <th className="px-6 py-2 text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.uid} className="bg-zinc-900 shadow-xl rounded-2xl group transition-transform hover:scale-[1.01]">
                <td className="px-6 py-4 rounded-l-2xl border-l-4 border-primary">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center text-primary font-black">
                      {user.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-black text-white uppercase italic">{user.name}</p>
                      <p className="text-[10px] text-zinc-500 font-bold">{user.email}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <select 
                    value={user.role}
                    onChange={(e) => handleUpdateRole(user.uid, e.target.value)}
                    className="bg-black border-2 border-zinc-800 rounded-lg px-3 py-2 text-xs font-black uppercase text-primary focus:border-primary outline-none"
                  >
                    <option value="participant">Participante</option>
                    <option value="leader">Líder</option>
                    <option value="admin">Administrador</option>
                  </select>
                </td>
                <td className="px-6 py-4">
                  <select 
                    value={user.groupId}
                    onChange={(e) => handleUpdateGroup(user.uid, e.target.value)}
                    className="bg-black border-2 border-zinc-800 rounded-lg px-3 py-2 text-xs font-black uppercase text-white focus:border-primary outline-none"
                  >
                    {groups.map(g => (
                      <option key={g.id} value={g.id}>{g.name}</option>
                    ))}
                  </select>
                </td>
                <td className="px-6 py-4">
                  <p className="text-xl font-black text-primary italic">{user.totalPoints}pts</p>
                </td>
                <td className="px-6 py-4 rounded-r-2xl text-right">
                  <button 
                    onClick={() => handleDeleteUser(user.uid)}
                    className="p-2 text-zinc-500 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={20} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
