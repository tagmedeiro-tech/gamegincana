/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { UserPlus, Shield, Users, Loader2, Landmark, Trophy, Cross } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAppTheme } from '../hooks/useAppTheme';

export default function Register() {
  const theme = useAppTheme();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const getLogoIcon = () => {
    switch (theme.logoType) {
      case 'shield': return <Shield size={48} className="text-black" />;
      case 'trophy': return <Trophy size={48} className="text-black" />;
      case 'cross': return <Cross size={48} className="text-black" />;
      default: return <Landmark size={48} className="text-black" />;
    }
  };
  const role = searchParams.get('role') || 'participant';
  const groupIdFromUrl = searchParams.get('groupId');

  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    password: '',
    groupName: groupIdFromUrl || '',
  });

  const [loading, setLoading] = React.useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // 1. Create Auth User
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            full_name: formData.name,
          }
        }
      });

      if (authError) throw authError;
      if (!authData.user) throw new Error("Erro ao criar usuário");

      // 2. Create Profile in 'profiles' table
      const { error: profileError } = await supabase
        .from('profiles')
        .insert([{
          id: authData.user.id,
          name: formData.name,
          email: formData.email,
          role: role,
          groupId: formData.groupName || 'leoes-juda',
          totalPoints: 0,
          achievements: []
        }]);

      if (profileError) throw profileError;

      alert(`Cadastro realizado com sucesso! Bem-vindo à Tribo.`);
      navigate('/');
    } catch (error: any) {
      console.error("Register error:", error);
      alert(`Erro no cadastro: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-6 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="card-bold max-w-md w-full !bg-zinc-900 border-primary"
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 bg-primary rounded-2xl flex items-center justify-center shadow-[0_0_30px_var(--color-primary-dark)]">
              {getLogoIcon()}
            </div>
          </div>
          <h2 className="text-4xl font-black italic tracking-tighter text-white leading-none uppercase">
            {role === 'leader' ? 'Cadastro de Líder' : `Entrar na ${theme.appName.split(' ')[0]}`}
          </h2>
          <p className="text-zinc-500 font-bold mt-2 italic uppercase text-[10px] tracking-widest">
            {theme.churchName} • {theme.appName}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-primary mb-2">Seu Nome Completo</label>
            <input 
              required
              type="text"
              placeholder="Ex: João Silva"
              className="w-full bg-black border-4 border-zinc-800 focus:border-primary rounded-xl px-4 py-3 font-bold text-white focus:outline-none focus:scale-[1.02] transition-all"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-primary mb-2">Seu Melhor E-mail</label>
            <input 
              required
              type="email"
              placeholder="joao@exemplo.com"
              className="w-full bg-black border-4 border-zinc-800 focus:border-primary rounded-xl px-4 py-3 font-bold text-white focus:outline-none focus:scale-[1.02] transition-all"
              value={formData.email}
              onChange={e => setFormData({...formData, email: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-primary mb-2">Crie sua Senha</label>
            <input 
              required
              type="password"
              placeholder="••••••••"
              className="w-full bg-black border-4 border-zinc-800 focus:border-primary rounded-xl px-4 py-3 font-bold text-white focus:outline-none focus:scale-[1.02] transition-all"
              value={formData.password}
              onChange={e => setFormData({...formData, password: e.target.value})}
            />
          </div>

          {role === 'participant' && (
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-primary mb-2">Sua Tribo</label>
              <select 
                className="w-full bg-black border-4 border-zinc-800 focus:border-primary rounded-xl px-4 py-3 font-bold text-white focus:outline-none focus:scale-[1.02] transition-all appearance-none cursor-pointer"
                value={formData.groupName}
                onChange={e => setFormData({...formData, groupName: e.target.value})}
              >
                <option value="">Selecione uma tribo...</option>
                <option value="leões">Leões de Judá</option>
                <option value="águias">Águias de Fogo</option>
                <option value="gad">Tribo de Gad</option>
              </select>
            </div>
          )}

          <button 
            type="submit" 
            disabled={loading}
            className="w-full btn-primary flex items-center justify-center gap-3 py-4 text-xl disabled:opacity-50 disabled:scale-100"
          >
            {loading ? (
              <Loader2 className="animate-spin" size={24} />
            ) : (
              <>SOU TRIBO <UserPlus size={24} /></>
            )}
          </button>
        </form>

        <p className="text-center text-[10px] font-black uppercase text-slate-400 mt-8 tracking-[0.2em]">
          Dúvidas? Procure o Pr. Mateus Silva
        </p>
      </motion.div>
    </div>
  );
}
