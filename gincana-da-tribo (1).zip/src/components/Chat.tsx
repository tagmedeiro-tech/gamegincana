/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { ChatMessage } from '../types';
import { Send } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ChatProps {
  groupId: string;
}

export default function Chat({ groupId }: ChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setCurrentUser(user);
    });
  }, []);

  useEffect(() => {
    if (!groupId) return;

    const fetchMessages = async () => {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('groupId', groupId)
        .order('created_at', { ascending: true })
        .limit(50);
      
      if (!error) {
        setMessages(data.map(m => ({
          id: m.id,
          senderId: m.senderId,
          senderName: m.senderName,
          text: m.text,
          groupId: m.groupId,
          timestamp: m.created_at
        })) as any);
      }
      setLoading(false);
      scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    fetchMessages();

    const channel = supabase
      .channel(`chat:${groupId}`)
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'messages', 
        filter: `groupId=eq.${groupId}` 
      }, (payload) => {
        setMessages(prev => [...prev, {
          id: payload.new.id,
          senderId: payload.new.senderId,
          senderName: payload.new.senderName,
          text: payload.new.text,
          groupId: payload.new.groupId,
          timestamp: payload.new.created_at
        } as any]);
        
        setTimeout(() => {
          scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [groupId]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !currentUser) return;

    try {
      const { error } = await supabase
        .from('messages')
        .insert([{
          senderId: currentUser.id,
          senderName: currentUser.user_metadata?.full_name || currentUser.email?.split('@')[0] || 'Anônimo',
          text: newMessage,
          groupId: groupId
        }]);
      
      if (error) throw error;
      setNewMessage('');
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  return (
    <div className="flex flex-col h-[500px] bg-zinc-900 rounded-3xl border-4 border-primary overflow-hidden shadow-2xl">
      <div className="bg-primary p-4 flex items-center justify-between">
        <h3 className="text-black font-black uppercase italic tracking-tighter flex items-center gap-2">
          Mural da Tribo
        </h3>
        <div className="flex gap-1">
          <div className="w-2 h-2 rounded-full bg-black animate-pulse"></div>
          <div className="w-2 h-2 rounded-full bg-black animate-pulse delay-75"></div>
          <div className="w-2 h-2 rounded-full bg-black animate-pulse delay-150"></div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth text-primary-content">
        {messages.length === 0 && !loading && (
          <div className="flex items-center justify-center h-full text-zinc-500 font-bold italic">
            Nenhuma mensagem ainda. Comece a conversa!
          </div>
        )}
        
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <AnimatePresence>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                className={`flex flex-col ${msg.senderId === currentUser?.id ? 'items-end' : 'items-start'}`}
              >
                <div className={`max-w-[85%] rounded-2xl p-4 shadow-lg ${
                  msg.senderId === currentUser?.id 
                    ? 'bg-primary text-black rounded-tr-xs' 
                    : 'bg-zinc-800 text-white rounded-tl-xs'
                }`}>
                  <div className="flex items-center justify-between mb-1 gap-4">
                    <p className={`text-[9px] font-black uppercase tracking-widest ${
                      msg.senderId === currentUser?.id ? 'text-black/60' : 'text-primary'
                    }`}>
                      {msg.senderName}
                    </p>
                  </div>
                  <p className="font-bold text-sm leading-tight break-words">{msg.text}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
        <div ref={scrollRef} />
      </div>

      <form onSubmit={handleSendMessage} className="p-4 bg-zinc-900 border-t-2 border-zinc-800 flex gap-2">
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Escreva algo para a tribo..."
          className="flex-1 bg-black border-2 border-zinc-800 rounded-xl px-4 py-3 text-white font-bold focus:border-primary outline-none transition-all placeholder:text-zinc-600"
        />
        <button
          type="submit"
          disabled={!newMessage.trim()}
          className="bg-primary text-black p-4 rounded-xl hover:scale-105 active:scale-95 transition-all shadow-[0_0_15px_rgba(251,191,36,0.2)] disabled:opacity-50 disabled:scale-100"
        >
          <Send size={20} />
        </button>
      </form>
    </div>
  );
}
