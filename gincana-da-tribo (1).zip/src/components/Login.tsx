/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { LogIn, Loader2, Landmark, Mail, Lock, Shield, Trophy, Cross } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAppTheme } from '../hooks/useAppTheme';

export default function Login() {
  const theme = useAppTheme();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const getLogoIcon = () => {
    switch (theme.logoType) {
      case 'shield': return <Shield size={48} className="text-black" />;
      case 'trophy': return <Trophy size={48} className="text-black" />;
      case 'cross': return <Cross size={48} className="text-black" />;
      default: return <Landmark size={48} className="text-black" />;
    }
  };

  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password,
      });
      
      if (error) throw error;
      navigate('/');
    } catch (error: any) {
      console.error("Login error:", error);
      alert(`Erro no login: ${error.message || 'Credenciais inválidas'}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-6 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="card-bold max-w-md w-full !bg-zinc-900 border-primary"
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 bg-primary rounded-2xl flex items-center justify-center shadow-[0_0_30px_var(--color-primary-dark)]">
              {getLogoIcon()}
            </div>
          </div>
          <h2 className="text-4xl font-black italic tracking-tighter text-white leading-none uppercase">
            Acesso à {theme.appName.split(' ')[0]}
          </h2>
          <p className="text-zinc-500 font-bold mt-2 italic uppercase text-[10px] tracking-widest">
            {theme.churchName} • {theme.appName}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-primary mb-2 flex items-center gap-2">
              <Mail size={12} /> Email
            </label>
            <input 
              required
              type="email"
              placeholder="seu@email.com"
              className="w-full bg-black border-4 border-zinc-800 focus:border-primary rounded-xl px-4 py-3 font-bold text-white focus:outline-none focus:scale-[1.02] transition-all"
              value={formData.email}
              onChange={e => setFormData({...formData, email: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-[10px] font-black uppercase tracking-widest text-primary mb-2 flex items-center gap-2">
              <Lock size={12} /> Senha
            </label>
            <input 
              required
              type="password"
              placeholder="••••••••"
              className="w-full bg-black border-4 border-zinc-800 focus:border-primary rounded-xl px-4 py-3 font-bold text-white focus:outline-none focus:scale-[1.02] transition-all"
              value={formData.password}
              onChange={e => setFormData({...formData, password: e.target.value})}
            />
          </div>

          <button 
            type="submit" 
            disabled={loading}
            className="w-full btn-primary flex items-center justify-center gap-3 py-4 text-xl disabled:opacity-50"
          >
            {loading ? (
              <Loader2 className="animate-spin" size={24} />
            ) : (
              <>ENTRAR NA BATALHA <LogIn size={24} /></>
            )}
          </button>
        </form>

        <div className="mt-8 text-center pt-6 border-t-2 border-zinc-800">
          <p className="text-zinc-500 font-bold text-xs uppercase">Ainda não tem uma tribo?</p>
          <Link 
            to="/register" 
            className="text-primary font-black uppercase italic tracking-tighter hover:underline mt-2 inline-block"
          >
            Cadastre-se Agora
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
