/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Activity } from '../types';
import { Target, Plus, Trash2, Edit3 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function AdminActivities() {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState<Partial<Activity>>({
    title: '',
    description: '',
    points: 10,
    category: 'ESPIRITUAL',
    type: 'presencial',
    status: 'active'
  });

  useEffect(() => {
    fetchActivities();
  }, []);

  const fetchActivities = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('activities')
        .select('*');
      
      if (!error) {
        setActivities(data as Activity[]);
      }
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = editingId || `act-${Date.now()}`;
    try {
      const payload = {
        ...formData,
        id,
        updatedAt: new Date().toISOString()
      };

      const { error } = await supabase
        .from('activities')
        .upsert([payload]);
      
      if (error) throw error;

      setFormData({ title: '', description: '', points: 10, category: 'ESPIRITUAL', type: 'presencial', status: 'active' });
      setShowForm(false);
      setEditingId(null);
      fetchActivities();
    } catch (error) {
      alert("Erro ao salvar atividade");
    }
  };

  const handleEdit = (act: Activity) => {
    setFormData(act);
    setEditingId(act.id);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Excluir esta tarefa?")) return;
    try {
      const { error } = await supabase
        .from('activities')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      setActivities(activities.filter(a => a.id !== id));
    } catch (error) {
      alert("Erro ao excluir");
    }
  };

  if (loading) return <div className="flex justify-center p-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black uppercase italic tracking-tighter text-primary">Gerenciar Tarefas</h2>
          <p className="text-zinc-500 font-bold italic">Crie desafios para os membros marcarem pontos</p>
        </div>
        <button 
          onClick={() => { setShowForm(!showForm); setEditingId(null); }}
          className="btn-primary flex items-center gap-2"
        >
          NOVA TAREFA <Plus size={20} />
        </button>
      </header>

      <AnimatePresence>
        {showForm && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="card-bold border-primary bg-black mb-8"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Título da Atividade</label>
                  <input 
                    type="text" required
                    value={formData.title}
                    onChange={e => setFormData({...formData, title: e.target.value})}
                    placeholder="Ex: Trazer 1 quilo de alimento"
                    className="w-full bg-zinc-900 border-2 border-zinc-800 focus:border-primary p-3 rounded-xl text-white font-bold outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Pontos</label>
                  <input 
                    type="number" required
                    value={formData.points}
                    onChange={e => setFormData({...formData, points: parseInt(e.target.value)})}
                    className="w-full bg-zinc-900 border-2 border-zinc-800 focus:border-primary p-3 rounded-xl text-white font-bold outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Descrição</label>
                <textarea 
                  rows={2}
                  value={formData.description}
                  onChange={e => setFormData({...formData, description: e.target.value})}
                  className="w-full bg-zinc-900 border-2 border-zinc-800 focus:border-primary p-3 rounded-xl text-white font-bold outline-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Categoria</label>
                  <select 
                    value={formData.category}
                    onChange={e => setFormData({...formData, category: e.target.value})}
                    className="w-full bg-zinc-900 border-2 border-zinc-800 focus:border-primary p-3 rounded-xl text-white font-bold outline-none"
                  >
                    <option value="ESPIRITUAL">Espiritual</option>
                    <option value="AÇÃO SOCIAL">Ação Social</option>
                    <option value="CRIATIVIDADE">Criatividade</option>
                    <option value="EVENTO">Evento</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Tipo</label>
                  <select 
                    value={formData.type}
                    onChange={e => setFormData({...formData, type: e.target.value as any})}
                    className="w-full bg-zinc-900 border-2 border-zinc-800 focus:border-primary p-3 rounded-xl text-white font-bold outline-none"
                  >
                    <option value="presencial">Presencial</option>
                    <option value="online">Online</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Status</label>
                  <select 
                     value={formData.status}
                     onChange={e => setFormData({...formData, status: e.target.value as any})}
                     className="w-full bg-zinc-900 border-2 border-zinc-800 focus:border-primary p-3 rounded-xl text-white font-bold outline-none"
                  >
                    <option value="active">Ativa</option>
                    <option value="archived">Arquivada</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-4">
                <button type="submit" className="flex-1 btn-primary py-4">
                  {editingId ? 'ATUALIZAR TAREFA' : 'CRIAR TAREFA'}
                </button>
                <button type="button" onClick={() => setShowForm(false)} className="px-8 bg-zinc-800 text-white rounded-full font-black uppercase text-xs">Cancelar</button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 gap-4">
        {activities.map((act) => (
          <div key={act.id} className="card-bold bg-zinc-900 border-primary py-4 px-6 flex items-center justify-between group transition-all hover:border-white">
            <div className="flex items-center gap-6">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black italic text-xl ${act.status === 'active' ? 'bg-primary text-black' : 'bg-zinc-800 text-zinc-500'}`}>
                {act.points}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase text-zinc-500 tracking-widest">{act.category}</span>
                  {act.status === 'archived' && <span className="text-[8px] bg-red-500 text-white px-2 py-0.5 rounded-full font-black uppercase">Arquivada</span>}
                </div>
                <h3 className="text-xl font-black text-white uppercase italic tracking-tighter">{act.title}</h3>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button 
                onClick={() => handleEdit(act)}
                className="p-3 bg-zinc-800 text-zinc-400 rounded-xl hover:text-primary hover:bg-black transition-all"
              >
                <Edit3 size={18} />
              </button>
              <button 
                onClick={() => handleDelete(act.id)}
                className="p-3 bg-zinc-800 text-zinc-400 rounded-xl hover:text-red-500 hover:bg-black transition-all"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
