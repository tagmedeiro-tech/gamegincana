/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Group, UserProfile } from '../types';
import { Users, Plus, Trash2, Crown, Shield } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function AdminGroups() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newGroup, setNewGroup] = useState({ name: '', leaderId: '' });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: groupsData, error: groupsError } = await supabase
        .from('groups')
        .select('*');
      
      const { data: usersData, error: usersError } = await supabase
        .from('profiles')
        .select('*');
      
      if (!groupsError) setGroups(groupsData as Group[]);
      if (!usersError) setUsers(usersData.map(u => ({ uid: u.id, ...u }) as UserProfile));
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroup.name) return;

    try {
      const id = newGroup.name.toLowerCase().replace(/\s+/g, '-');
      const { error } = await supabase
        .from('groups')
        .insert([{
          id,
          name: newGroup.name,
          leaderId: newGroup.leaderId || null,
          totalPoints: 0,
          memberCount: 0
        }]);
      
      if (error) throw error;
      
      // If leader assigned, update their role to leader
      if (newGroup.leaderId) {
        await supabase
          .from('profiles')
          .update({ 
            role: 'leader',
            groupId: id
          })
          .eq('id', newGroup.leaderId);
      }

      setNewGroup({ name: '', leaderId: '' });
      setShowAddForm(false);
      fetchData();
    } catch (error) {
      alert("Erro ao criar grupo");
    }
  };

  const handleDeleteGroup = async (groupId: string) => {
    if (!confirm("Tem certeza que deseja excluir esta tribo? Isso NÃO excluirá os membros, mas eles ficarão sem grupo.")) return;
    try {
      const { error } = await supabase
        .from('groups')
        .delete()
        .eq('id', groupId);
      
      if (error) throw error;
      setGroups(groups.filter(g => g.id !== groupId));
    } catch (error) {
      alert("Erro ao excluir grupo");
    }
  };

  const handleUpdateLeader = async (groupId: string, leaderId: string) => {
    try {
      const { error } = await supabase
        .from('groups')
        .update({ leaderId: leaderId || null })
        .eq('id', groupId);
      
      if (error) throw error;

      // Update new leader role
      if (leaderId) {
        await supabase
          .from('profiles')
          .update({ role: 'leader' })
          .eq('id', leaderId);
      }
      setGroups(groups.map(g => g.id === groupId ? { ...g, leaderId } : g));
    } catch (error) {
      alert("Erro ao atualizar líder");
    }
  };

  if (loading) return <div className="flex justify-center p-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;

  return (
    <div className="space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black uppercase italic tracking-tighter text-primary">Gerenciar Tribos</h2>
          <p className="text-zinc-500 font-bold italic">Crie e administre as equipes da gincana</p>
        </div>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="btn-primary flex items-center gap-2"
        >
          NOVA TRIBO <Plus size={20} />
        </button>
      </header>

      <AnimatePresence>
        {showAddForm && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="card-bold border-primary bg-black"
          >
            <form onSubmit={handleCreateGroup} className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Nome da Tribo</label>
                <input 
                  type="text"
                  required
                  placeholder="Ex: Leões de Judá"
                  value={newGroup.name}
                  onChange={e => setNewGroup({...newGroup, name: e.target.value})}
                  className="w-full bg-zinc-900 border-2 border-zinc-800 focus:border-primary p-3 rounded-xl text-white font-bold outline-none"
                />
              </div>
              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-2">Líder (Opcional)</label>
                <select 
                  value={newGroup.leaderId}
                  onChange={e => setNewGroup({...newGroup, leaderId: e.target.value})}
                  className="w-full bg-zinc-900 border-2 border-zinc-800 focus:border-primary p-3 rounded-xl text-white font-bold outline-none"
                >
                  <option value="">Selecione um líder...</option>
                  {users.map(u => (
                    <option key={u.uid} value={u.uid}>{u.name}</option>
                  ))}
                </select>
              </div>
              <div className="flex gap-2">
                <button type="submit" className="flex-1 btn-primary py-3">CRIAR AGORA</button>
                <button type="button" onClick={() => setShowAddForm(false)} className="px-6 py-3 bg-zinc-800 text-white rounded-full font-black uppercase text-xs">Cancelar</button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {groups.map((group) => (
          <div key={group.id} className="card-bold bg-zinc-900 border-primary relative overflow-hidden group">
            <div className="flex items-start justify-between relative z-10">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-black rounded-2xl flex items-center justify-center text-primary border-2 border-primary/20">
                  <Shield size={32} />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white uppercase italic italic tracking-tighter">{group.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Crown size={14} className="text-primary" />
                    <select 
                      value={group.leaderId}
                      onChange={(e) => handleUpdateLeader(group.id, e.target.value)}
                      className="bg-transparent border-none p-0 text-xs font-black uppercase text-primary outline-none cursor-pointer"
                    >
                      <option value="" className="bg-zinc-900">Sem Líder</option>
                      {users.map(u => (
                        <option key={u.uid} value={u.uid} className="bg-zinc-900">{u.name}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => handleDeleteGroup(group.id)}
                className="p-2 text-zinc-700 hover:text-red-500 transition-colors"
              >
                <Trash2 size={20} />
              </button>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-4 relative z-10">
              <div className="bg-black/40 p-4 rounded-xl border-l-4 border-primary">
                <p className="text-[10px] font-black uppercase text-zinc-500">Membros</p>
                <p className="text-2xl font-black text-white italic">{group.memberCount}</p>
              </div>
              <div className="bg-black/40 p-4 rounded-xl border-l-4 border-primary">
                <p className="text-[10px] font-black uppercase text-zinc-500">Pontuação Total</p>
                <p className="text-2xl font-black text-primary italic">{group.totalPoints}pts</p>
              </div>
            </div>

            <div className="absolute -right-8 -bottom-8 opacity-5 transform group-hover:scale-110 transition-transform">
              <Shield size={160} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
