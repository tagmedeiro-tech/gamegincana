/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import AdminUsers from './AdminUsers';
import AdminGroups from './AdminGroups';
import AdminActivities from './AdminActivities';
import AdminSettings from './AdminSettings';
import { Link as LinkIcon, Users, UserCog, Target, FileText, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type AdminTab = 'users' | 'groups' | 'tasks' | 'settings';

export default function AdminDashboard() {
  const [activeSubTab, setActiveSubTab] = useState<AdminTab>('users');

  const menuItems = [
    { id: 'users', label: 'Membros', icon: UserCog },
    { id: 'groups', label: 'Tribos', icon: Users },
    { id: 'tasks', label: 'Tarefas', icon: Target },
    { id: 'settings', label: 'Aparência', icon: Settings },
  ];

  return (
    <div className="space-y-8 pb-12">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-6xl font-black tracking-tight leading-none uppercase text-white">Painel Admin</h2>
          <p className="text-zinc-500 font-medium mt-2 italic uppercase tracking-widest text-[10px]">Gestão Suprema da Gincana TRIBO IDE</p>
        </div>
      </header>

      {/* Admin Sub-Navigation */}
      <div className="flex flex-wrap gap-4 border-b-4 border-zinc-900 pb-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveSubTab(item.id as AdminTab)}
            className={`flex items-center gap-2 px-6 py-4 rounded-t-2xl font-black uppercase italic tracking-tighter transition-all ${
              activeSubTab === item.id 
                ? 'bg-zinc-900 text-primary border-t-4 border-l-4 border-r-4 border-primary' 
                : 'text-zinc-500 hover:text-white'
            }`}
          >
            <item.icon size={20} />
            {item.label}
          </button>
        ))}
      </div>

      <motion.div
        key={activeSubTab}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
      >
        {activeSubTab === 'users' && <AdminUsers />}
        {activeSubTab === 'groups' && <AdminGroups />}
        {activeSubTab === 'tasks' && <AdminActivities />}
        {activeSubTab === 'settings' && <AdminSettings />}
      </motion.div>
    </div>
  );
}
