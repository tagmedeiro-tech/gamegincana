/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Trophy, Landmark, Shield, Cross } from 'lucide-react';
import AchievementList from './AchievementList';
import { useAppTheme } from '../hooks/useAppTheme';
import { supabase } from '../lib/supabase';
import { Group, Activity } from '../types';

export default function Dashboard() {
  const theme = useAppTheme();
  const [groups, setGroups] = useState<Group[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const { data: groupsData } = await supabase
        .from('groups')
        .select('*')
        .order('totalPoints', { ascending: false });
      
      const { data: activitiesData } = await supabase
        .from('activities')
        .select('*')
        .eq('status', 'active')
        .limit(3);
      
      if (groupsData) setGroups(groupsData as Group[]);
      if (activitiesData) setActivities(activitiesData as Activity[]);
      setLoading(false);
    };

    fetchData();
  }, []);

  const getLogoIcon = () => {
    switch (theme.logoType) {
      case 'shield': return <Shield size={32} className="text-black" />;
      case 'trophy': return <Trophy size={32} className="text-black" />;
      case 'cross': return <Cross size={32} className="text-black" />;
      default: return <Landmark size={32} className="text-black" />;
    }
  };

  if (loading) return <div className="flex justify-center p-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;

  const topThree = groups.slice(0, 3);
  const labels = ['Líder Atual', 'Vice-Líder', 'Terceiro Lugar'];

  return (
    <div className="space-y-8 text-primary-content">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center shadow-[0_0_20px_var(--color-primary-dark)] shrink-0">
            {getLogoIcon()}
          </div>
          <div className="text-primary-content">
            <h2 className="text-5xl font-black tracking-tight leading-none uppercase text-white">Dashboard</h2>
            <p className="text-zinc-500 font-medium mt-1 italic">{theme.churchName} — Gincana {theme.appName}</p>
          </div>
        </div>
        <div className="text-right bg-zinc-900 px-6 py-3 rounded-2xl border-2 border-primary/20">
          <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500 mb-1">Status da Temporada</p>
          <p className="text-xl font-black text-primary uppercase italic">Ativa</p>
        </div>
      </header>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {topThree.map((group, i) => (
          <motion.div
            key={group.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className={`${i === 0 ? 'card-yellow' : 'card-bold'} h-48 relative overflow-hidden`}
          >
            <span className={`text-8xl font-black absolute -right-4 -bottom-6 opacity-10 ${i === 0 ? 'text-black' : 'text-primary'}`}>
              0{i + 1}
            </span>
            <p className={`text-xs font-bold uppercase tracking-widest ${i === 0 ? 'text-black/60' : 'text-zinc-500'}`}>
              {labels[i]}
            </p>
            <div>
              <p className={`text-3xl font-black leading-tight uppercase mt-2 ${i === 0 ? 'text-black' : 'text-white'}`}>
                {group.name.split(' ').map((w, idx) => <span key={idx}>{w}<br/></span>)}
              </p>
              <p className={`text-sm mt-2 font-bold ${i === 0 ? 'text-black/80' : 'text-primary'}`}>
                {group.totalPoints} Pontos
              </p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        {/* Weekly Activities */}
        <div className="lg:col-span-3 card-bold flex flex-col bg-zinc-900 border-primary">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-xl font-black uppercase tracking-tight italic text-primary">Atividades</h3>
            <span className="px-4 py-1 bg-primary text-black text-[10px] font-black rounded-full">
              DESTAQUES
            </span>
          </div>
          
          <div className="space-y-4">
            {activities.map((activity, i) => (
              <div key={activity.id} className={`flex items-center p-4 bg-black/40 rounded-xl border-l-4 ${i === 0 ? 'border-primary' : 'border-zinc-800'}`}>
                <div className="flex-1">
                  <p className={`text-[9px] font-bold ${i === 0 ? 'text-primary' : 'text-zinc-500'} mb-1 uppercase tracking-widest`}>{activity.category}</p>
                  <p className="font-black text-white">{activity.title}</p>
                </div>
                <div className="text-right">
                  <p className={`text-xl font-black ${i === 0 ? 'text-primary' : 'text-white'}`}>+{activity.points}pts</p>
                  <p className="text-[10px] text-zinc-600 font-bold uppercase">{activity.type}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Achievements Section */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          <div className="card-bold !bg-zinc-900 !border-4 !border-primary">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-black uppercase tracking-tight italic text-primary">Suas Conquistas</h3>
              <Trophy className="text-primary" size={24} />
            </div>
            <AchievementList />
          </div>

          <div className="h-24 bg-zinc-900 text-white p-4 rounded-3xl flex items-center justify-between px-6 border-4 border-primary shadow-[4px_4px_0px_0px_rgba(251,191,36,1)]">
             <div>
                <p className="text-[10px] font-bold text-zinc-500 uppercase">Status da Meta</p>
                <p className="font-bold text-primary italic uppercase">Faltam 45 pontos para subir</p>
             </div>
             <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                <span className="text-2xl text-black">🚀</span>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
