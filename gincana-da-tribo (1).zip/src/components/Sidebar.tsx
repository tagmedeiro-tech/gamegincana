/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Trophy, Users, CheckSquare, Settings, Menu, X, Landmark, LogOut, Shield, Cross } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '../lib/supabase';
import { useAppTheme } from '../hooks/useAppTheme';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userRole: string;
}

export default function Sidebar({ activeTab, setActiveTab, userRole }: SidebarProps) {
  const [isOpen, setIsOpen] = React.useState(false);
  const theme = useAppTheme();

  const getLogoIcon = () => {
    switch (theme.logoType) {
      case 'shield': return <Shield size={48} className="text-black" />;
      case 'trophy': return <Trophy size={48} className="text-black" />;
      case 'cross': return <Cross size={48} className="text-black" />;
      default: return <Landmark size={48} className="text-black" />;
    }
  };

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Trophy },
    { id: 'activities', label: 'Atividades', icon: CheckSquare },
    { id: 'group', label: 'Meu Grupo', icon: Users },
  ];

  if (userRole === 'admin') {
    menuItems.push({ id: 'admin', label: 'Painel Admin', icon: Settings });
    menuItems.push({ id: 'links', label: 'Links Convite', icon: Landmark });
  }

  return (
    <>
      {/* Mobile Toggle */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="p-2 bg-primary rounded-lg text-black shadow-lg"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Sidebar */}
      <AnimatePresence>
        {(isOpen || window.innerWidth >= 1024) && (
          <motion.aside
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            className={`fixed inset-y-0 left-0 z-40 w-64 bg-black border-r-4 border-primary p-6 flex flex-col transition-all duration-300 ${
              isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
            }`}
          >
            {/* Church Branding Logo Section */}
            <div className="mb-12 flex flex-col items-center">
              <div className="w-20 h-20 bg-primary rounded-2xl flex items-center justify-center shadow-[0_0_30px_var(--color-primary-dark)] mb-4 rotate-3 transform hover:rotate-0 transition-all duration-500">
                {getLogoIcon()}
              </div>
              <div className="text-center">
                <h1 className="text-2xl font-black italic tracking-tighter leading-none text-white uppercase">
                  {theme.appName.split(' ')[0]}<span className="text-primary block text-4xl">{theme.appName.split(' ')[1] || ''}</span>
                </h1>
                <p className="text-[8px] font-black tracking-[0.4em] text-zinc-500 uppercase mt-2">{theme.churchName}</p>
              </div>
              <div className="h-1 w-24 bg-primary/20 mt-6 rounded-full overflow-hidden">
                <div className="h-full w-1/2 bg-primary animate-[shimmer_2s_infinite]"></div>
              </div>
            </div>

            <nav className="flex-1 space-y-6">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsOpen(false);
                  }}
                  className={`sidebar-link w-full text-left ${
                    activeTab === item.id 
                      ? 'text-primary opacity-100' 
                      : 'text-white opacity-60 hover:opacity-100'
                  }`}
                >
                  <span className="text-xl">{activeTab === item.id ? '●' : '○'}</span>
                  <span>{item.label}</span>
                </button>
              ))}
            </nav>

    <div className="mt-auto space-y-4">
              <div className="p-4 bg-zinc-900 rounded-xl border-l-4 border-primary">
                <p className="text-[10px] uppercase tracking-widest font-bold text-zinc-500 mb-1">Status</p>
                <p className="text-sm font-bold text-white">Logado como {userRole}</p>
              </div>
              <button 
                onClick={() => supabase.auth.signOut()}
                className="w-full flex items-center justify-center gap-2 p-3 bg-red-600/20 hover:bg-red-600 text-red-500 hover:text-white rounded-xl font-black uppercase text-[10px] tracking-widest transition-all"
              >
                <LogOut size={16} /> SAIR DO SISTEMA
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>
    </>
  );
}
