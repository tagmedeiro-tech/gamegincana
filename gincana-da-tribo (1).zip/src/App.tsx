/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Activities from './components/Activities';
import Register from './components/Register';
import Chat from './components/Chat';
import Login from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import { motion, AnimatePresence } from 'motion/react';
import { Copy, Check, Link as LinkIcon, Share2, MessageSquare, Landmark, ShieldAlert } from 'lucide-react';
import { supabase } from './lib/supabase';
import { UserProfile } from './types';
import { useAppTheme } from './hooks/useAppTheme';
import { User } from '@supabase/supabase-js';

function AdminLinks() {
  const [copied, setCopied] = React.useState<string | null>(null);
  const baseUrl = window.location.origin;

  const links = [
    { label: 'Link para Membros', url: `${baseUrl}/register?role=participant`, color: 'bg-primary' },
    { label: 'Link para Líderes', url: `${baseUrl}/register?role=leader`, color: 'bg-accent text-primary' },
  ];

  const copyToClipboard = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="space-y-8">
      <header className="flex items-center gap-6 mb-12">
        <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center shadow-[0_0_20px_rgba(251,191,36,0.3)]">
          <Landmark size={32} className="text-black" />
        </div>
        <div>
          <h2 className="text-4xl font-black italic tracking-tighter text-white leading-none uppercase">Gerar Links de Cadastro</h2>
          <p className="text-zinc-500 font-bold mt-2 italic">Igreja do Evangelho • TRIBO IDE</p>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {links.map((link, i) => (
          <div key={i} className="card-bold bg-zinc-900 border-primary p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className={`p-3 rounded-lg bg-primary text-black`}>
                <LinkIcon size={24} />
              </div>
              <h3 className="text-xl font-black uppercase italic text-primary">{link.label}</h3>
            </div>
            
            <div className="bg-black border-2 border-dashed border-zinc-800 rounded-xl p-4 mb-6 break-all font-mono text-xs text-zinc-500">
              {link.url}
            </div>

            <button 
              onClick={() => copyToClipboard(link.url, link.label)}
              className={`w-full flex items-center justify-center gap-2 py-4 rounded-full font-black uppercase tracking-tighter transition-all ${
                copied === link.label ? 'bg-green-600 text-white shadow-[0_0_20px_rgba(22,163,74,0.3)]' : 'btn-primary'
              }`}
            >
              {copied === link.label ? (
                <>COPIADO! <Check size={20} /></>
              ) : (
                <>COPIAR LINK <Copy size={20} /></>
              )}
            </button>
          </div>
        ))}
      </div>

      <div className="card-bold bg-primary text-black p-8 border-transparent">
        <div className="flex items-center gap-4 mb-4">
          <Share2 className="text-black" size={32} />
          <h3 className="text-2xl font-black italic uppercase tracking-tighter">Dica do Admin</h3>
        </div>
        <p className="font-bold leading-relaxed italic">
          Os links acima facilitam o cadastro. Quando um líder se cadastra, ele ganha permissões automáticas para validar as tarefas da sua tribo!
        </p>
      </div>
    </div>
  );
}

function MainLayout() {
  const [activeTab, setActiveTab] = React.useState('dashboard');
  const theme = useAppTheme();
  const [userRole, setUserRole] = React.useState('admin'); // Mock role for UI
  const [currentUser, setCurrentUser] = React.useState<User | null>(null);
  const [userProfile, setUserProfile] = React.useState<UserProfile | null>(null);

  React.useEffect(() => {
    const checkUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user || null;
      setCurrentUser(user);
      
      if (user) {
        try {
          const { data: profile, error } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', user.id)
            .single();
          
          if (profile && !error) {
            setUserProfile(profile as UserProfile);
            setUserRole(profile.role);
          }
        } catch (error) {
          console.error("Error fetching profile:", error);
        }
      } else {
        setUserProfile(null);
        setUserRole('participant');
        if (window.location.pathname === '/') {
          window.location.href = '/login';
        }
      }
    };

    checkUser();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      const user = session?.user || null;
      setCurrentUser(user);
      
      if (user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
        
        if (profile) {
          setUserProfile(profile as UserProfile);
          setUserRole(profile.role);
        }
      } else {
        setUserProfile(null);
        setUserRole('participant');
        if (window.location.pathname === '/') {
          window.location.href = '/login';
        }
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const promoteToAdmin = async () => {
    if (!currentUser) return;
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ role: 'admin' })
        .eq('id', currentUser.id);
      
      if (error) throw error;
      alert("Promovido a Admin! Recarregue a página.");
    } catch (e) {
      alert("Erro ao promover");
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'activities':
        return <Activities />;
      case 'group':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1 space-y-6">
              <div className="card-bold bg-zinc-900 border-primary">
                <h2 className="text-3xl font-black mb-2 text-primary uppercase italic tracking-tighter leading-none">
                  {userProfile?.groupId ? `Tribo #${userProfile.groupId}` : 'Guerreiros da Fé'}
                </h2>
                <div className="h-1 w-16 bg-primary mb-4"></div>
                <p className="text-slate-500 font-bold italic mb-6">Informações e mural da sua tribo.</p>
                
                <div className="space-y-4">
                  <div className="p-4 bg-black rounded-xl border-l-4 border-primary">
                    <p className="text-[10px] font-black uppercase text-zinc-500">Membros Conectados</p>
                    <p className="text-xl font-black text-white italic">12 Guerreiros</p>
                  </div>
                  <div className="p-4 bg-black rounded-xl border-l-4 border-primary">
                    <p className="text-[10px] font-black uppercase text-zinc-500">Ranking da Tribo</p>
                    <p className="text-xl font-black text-white italic">2º Lugar</p>
                  </div>
                </div>
              </div>

              <div className="card-bold bg-primary text-black p-6">
                <div className="flex items-center gap-2 mb-2">
                  <MessageSquare size={20} />
                  <p className="text-xs font-black uppercase">Dica da Tribo</p>
                </div>
                <p className="font-bold text-sm italic leading-tight">
                  "O ferro com o ferro se afia; assim, o homem afia o rosto do seu amigo." Prosperem juntos!
                </p>
              </div>
            </div>

            <div className="lg:col-span-2">
              <Chat groupId={userProfile?.groupId || 'leoes-juda'} />
            </div>
          </div>
        );
      case 'admin':
        return <AdminDashboard />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[--color-bg-light] flex selection:bg-accent selection:text-primary">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} userRole={userRole} />
      
      <main className="flex-1 lg:ml-64 p-8 pt-20 lg:pt-8 overflow-y-auto h-screen custom-scrollbar relative">
        {/* Dev Tools / Admin Access */}
        {!userProfile && currentUser && (
           <div className="absolute top-2 right-2 z-50">
              <button 
                onClick={promoteToAdmin}
                className="flex items-center gap-2 text-zinc-900 hover:text-primary text-[8px] uppercase font-black transition-colors bg-black/50 p-2 rounded"
              >
                <ShieldAlert size={12} /> DEV: VIRAR ADMIN PARA TESTAR
              </button>
           </div>
        )}

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Global Theme Styles for transitions */}
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #000000;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #FBBF24;
          border-radius: 0px;
          border: 2px solid #000000;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #B45309;
        }
      `}</style>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainLayout />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </BrowserRouter>
  );
}

